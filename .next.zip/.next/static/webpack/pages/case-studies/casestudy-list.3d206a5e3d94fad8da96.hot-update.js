self["webpackHotUpdate_N_E"]("pages/case-studies/casestudy-list",{

/***/ "./components/header/index.jsx":
/*!*************************************!*\
  !*** ./components/header/index.jsx ***!
  \*************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Header; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _dropdown_index_jsx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../dropdown/index.jsx */ "./components/dropdown/index.jsx");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_11__);
/* module decorator */ module = __webpack_require__.hmd(module);







var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\components\\header\\index.jsx";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

 // import { HashLink as Link } from 'react-router-hash-link';
// import { NavHashLink as Link } from 'react-router-hash-link';






var Header = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__.default)(Header, _Component);

  var _super = _createSuper(Header);

  function Header(props) {
    var _this;

    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__.default)(this, Header);

    _this = _super.call(this, props);

    if (false) {}

    _this.state = {};
    _this.HomePage = _this.HomePage.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    _this.AboutusPage = _this.AboutusPage.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    _this.ServicePage = _this.ServicePage.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    _this.WordpressPage = _this.WordpressPage.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    _this.ShopifyPage = _this.ShopifyPage.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    _this.Blog = _this.Blog.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    _this.CareersPage = _this.CareersPage.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    _this.ContactusPage = _this.ContactusPage.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    _this.filemakerPage = _this.filemakerPage.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    _this.ErrorPage = _this.ErrorPage.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__.default)(_this));
    return _this;
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__.default)(Header, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.menuToggle(); // window.addEventListener("resize", this.menuToggle);

      if (true) {
        jquery__WEBPACK_IMPORTED_MODULE_11___default()(window).scroll(function () {
          var scroll = jquery__WEBPACK_IMPORTED_MODULE_11___default()(window).scrollTop();

          if (scroll >= 74) {
            jquery__WEBPACK_IMPORTED_MODULE_11___default()('.header-container').addClass('sticky');
            jquery__WEBPACK_IMPORTED_MODULE_11___default()('.service-bg').addClass('fixed');
          } else {
            jquery__WEBPACK_IMPORTED_MODULE_11___default()('.header-container').removeClass('sticky');
            jquery__WEBPACK_IMPORTED_MODULE_11___default()('.service-bg').removeClass('fixed');
          }
        });
      }

      ;
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {// window.removeEventListener("resize", this.menuToggle);
    } //menu toggle on mobile

  }, {
    key: "menuToggle",
    value: function menuToggle() {
      if (jquery__WEBPACK_IMPORTED_MODULE_11___default()(".navbar-light .navbar-toggler").is(":visible")) {
        jquery__WEBPACK_IMPORTED_MODULE_11___default()(".navbar-light .navbar-nav .nav-item > i").click(function () {
          jquery__WEBPACK_IMPORTED_MODULE_11___default()(this).siblings('.submenu').slideToggle();
        });
      }
    }
  }, {
    key: "HomePage",
    value: function HomePage() {
      this.props.history.push('/');
    }
  }, {
    key: "AboutusPage",
    value: function AboutusPage() {
      this.props.history.push('/about-us');
    }
  }, {
    key: "ServicePage",
    value: function ServicePage() {
      this.props.history.push('/sevices');
    }
  }, {
    key: "WordpressPage",
    value: function WordpressPage() {
      this.props.history.push('/wordpress');
    }
  }, {
    key: "ShopifyPage",
    value: function ShopifyPage() {
      this.props.history.push('/shopify');
    }
  }, {
    key: "Blog",
    value: function Blog() {
      this.props.history.push('/blog');
    }
  }, {
    key: "CareersPage",
    value: function CareersPage() {
      this.props.history.push('careers');
    }
  }, {
    key: "ContactusPage",
    value: function ContactusPage() {
      this.props.history.push('/contact-us');
    }
  }, {
    key: "filemakerPage",
    value: function filemakerPage() {
      this.props.history.push('/filemaker');
    }
  }, {
    key: "filemakerPage",
    value: function filemakerPage() {
      this.props.history.push('/case-studies/casestudy-list');
    }
  }, {
    key: "ErrorPage",
    value: function ErrorPage() {
      this.props.history.push('/error');
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          title = _this$props.title,
          description = _this$props.description,
          keywords = _this$props.keywords;
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("header", {
        className: "header-container ",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_9___default()), {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("title", {
            children: title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 109,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
            name: "description",
            content: description
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 110,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
            property: "og:type",
            content: keywords
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 111,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
            property: "og:title",
            content: title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 112,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
            property: "og:description",
            content: description
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 113,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
            property: "og:site_name",
            content: "hashtag"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 114,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
            property: "twitter:card",
            content: "summary"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 115,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
            property: "twitter:creator",
            content: "twitter"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 116,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
            property: "twitter:title",
            content: "title"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 117,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
            property: "twitter:description",
            content: description
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 118,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 108,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "container ",
          id: "main-section",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("nav", {
            className: "navbar navbar-expand-lg navbar-light bg-light px-5",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
              className: "navbar-toggler",
              type: "button",
              "data-toggle": "collapse",
              "data-target": "#navbarTogglerDemo03",
              "aria-controls": "navbarTogglerDemo03",
              "aria-expanded": "false",
              "aria-label": "Toggle navigation",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                className: "navbar-toggler-icon"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 131,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 122,
              columnNumber: 13
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              id: "menu-container"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 134,
              columnNumber: 13
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
              href: "/",
              className: "navbar-brand",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
                id: "logo",
                className: "logo",
                src: "/hashtag-new-logo-header.svg",
                alt: "logo"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 136,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 135,
              columnNumber: 13
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "mob-top-email d-block d-sm-none",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                href: "mailto:info@hashtag-ca.com",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
                  src: "/images/mob-top-email.svg",
                  alt: "email"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 146,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 145,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 144,
              columnNumber: 13
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "collapse navbar-collapse header-menu",
              id: "navbarTogglerDemo03",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                className: "navbar-nav mr-auto mt-2 mt-lg-0",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                  className: "nav-item",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: "/about-us",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                      className: "nav-link",
                      activeclassName: "active",
                      children: [" ", "About Us ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                        className: "sr-only",
                        children: "(current)"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 162,
                        columnNumber: 32
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 160,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 156,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 155,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                  className: "nav-item",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: "/sevices",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                      className: "nav-link",
                      activeclassName: "active",
                      children: ["services", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                        className: "fa fa-angle-down",
                        "aria-hidden": "true"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 175,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 172,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 168,
                    columnNumber: 19
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                    className: "fa fa-angle-down",
                    "aria-hidden": "true"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 178,
                    columnNumber: 19
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                    className: "submenu",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "row m-0",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "col-md-6 p-0",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                            href: "/sevices/wordpress-development",
                            children: "Wordpress Development"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 183,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 182,
                          columnNumber: 25
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                            href: "/sevices/blockchain-development",
                            children: "Blockchain Development"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 188,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 187,
                          columnNumber: 25
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                            href: "/sevices/design-and-prototyping",
                            children: "Design and Prototyping"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 193,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 192,
                          columnNumber: 25
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 181,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "col-md-6 p-0",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                            href: "/sevices/filemaker",
                            children: "FileMaker Pro Development"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 201,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 200,
                          columnNumber: 25
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                            href: "/sevices/ui-development",
                            children: "UI Development"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 206,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 205,
                          columnNumber: 25
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                            href: "/sevices/database-and-backend",
                            children: "DB & Backend Development"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 211,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 210,
                          columnNumber: 25
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 198,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 180,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 179,
                    columnNumber: 19
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 167,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                  className: "nav-item",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: "/shopify",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                      className: "nav-link",
                      activeclassName: "active",
                      children: [" ", "Shopify ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                        className: "sr-only",
                        children: "(current)"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 228,
                        columnNumber: 27
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 226,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 222,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 221,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                  className: "nav-item",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: "/blog",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                      className: "nav-link",
                      activeclassName: "active",
                      children: [" ", "Blog ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                        className: "sr-only",
                        children: "(current)"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 240,
                        columnNumber: 24
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 238,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 234,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 233,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                  className: "nav-item",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: "/careers",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                      className: "nav-link",
                      activeclassName: "active",
                      children: [" ", "Careers ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                        className: "sr-only",
                        children: "(current)"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 252,
                        columnNumber: 27
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 250,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 246,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 245,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                  className: "nav-item",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: "/case-studies/casestudy-list",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                      className: "nav-link",
                      activeclassName: "active",
                      children: [" ", "Case studies ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                        className: "sr-only",
                        children: "(current)"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 264,
                        columnNumber: 32
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 262,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 258,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 257,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                  className: "nav-item",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: "/contact-us",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                      className: "nav-link",
                      activeclassName: "active",
                      children: [" ", "Contact Us ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                        className: "sr-only",
                        children: "(current)"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 276,
                        columnNumber: 30
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 274,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 270,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 269,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 154,
                columnNumber: 15
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "form-inline my-2 my-lg-0",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                  className: "btn-transparent btn-header-1 btn btn-outline-success my-2 my-sm-0",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: "/",
                    className: "en-link",
                    children: "En"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 284,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 283,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                  href: "/contact-us",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                    className: "speak-btn btn-header-2 btn-white btn btn-outline-success my-2 my-sm-0",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                      href: "/contact-us",
                      children: "Let's Speak"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 290,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 289,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 288,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 282,
                columnNumber: 15
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 150,
              columnNumber: 13
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 121,
            columnNumber: 11
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 120,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 107,
        columnNumber: 7
      }, this);
    }
  }]);

  return Header;
}(react__WEBPACK_IMPORTED_MODULE_7__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9oZWFkZXIvaW5kZXguanN4Il0sIm5hbWVzIjpbIkhlYWRlciIsInByb3BzIiwic3RhdGUiLCJIb21lUGFnZSIsImJpbmQiLCJBYm91dHVzUGFnZSIsIlNlcnZpY2VQYWdlIiwiV29yZHByZXNzUGFnZSIsIlNob3BpZnlQYWdlIiwiQmxvZyIsIkNhcmVlcnNQYWdlIiwiQ29udGFjdHVzUGFnZSIsImZpbGVtYWtlclBhZ2UiLCJFcnJvclBhZ2UiLCJtZW51VG9nZ2xlIiwiJCIsIndpbmRvdyIsInNjcm9sbCIsInNjcm9sbFRvcCIsImFkZENsYXNzIiwicmVtb3ZlQ2xhc3MiLCJpcyIsImNsaWNrIiwic2libGluZ3MiLCJzbGlkZVRvZ2dsZSIsImhpc3RvcnkiLCJwdXNoIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImtleXdvcmRzIiwiQ29tcG9uZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0lBRXFCQSxNOzs7OztBQUVyQixrQkFBWUMsS0FBWixFQUFtQjtBQUFBOztBQUFBOztBQUNqQiw4QkFBTUEsS0FBTjs7QUFDQSxlQUFtQyxFQUVsQzs7QUFDQyxVQUFLQyxLQUFMLEdBQWEsRUFBYjtBQUVBLFVBQUtDLFFBQUwsR0FBZ0IsTUFBS0EsUUFBTCxDQUFjQyxJQUFkLHlJQUFoQjtBQUNBLFVBQUtDLFdBQUwsR0FBbUIsTUFBS0EsV0FBTCxDQUFpQkQsSUFBakIseUlBQW5CO0FBQ0EsVUFBS0UsV0FBTCxHQUFtQixNQUFLQSxXQUFMLENBQWlCRixJQUFqQix5SUFBbkI7QUFDQSxVQUFLRyxhQUFMLEdBQXFCLE1BQUtBLGFBQUwsQ0FBbUJILElBQW5CLHlJQUFyQjtBQUNBLFVBQUtJLFdBQUwsR0FBbUIsTUFBS0EsV0FBTCxDQUFpQkosSUFBakIseUlBQW5CO0FBQ0EsVUFBS0ssSUFBTCxHQUFZLE1BQUtBLElBQUwsQ0FBVUwsSUFBVix5SUFBWjtBQUNBLFVBQUtNLFdBQUwsR0FBbUIsTUFBS0EsV0FBTCxDQUFpQk4sSUFBakIseUlBQW5CO0FBQ0EsVUFBS08sYUFBTCxHQUFxQixNQUFLQSxhQUFMLENBQW1CUCxJQUFuQix5SUFBckI7QUFDQSxVQUFLUSxhQUFMLEdBQXFCLE1BQUtBLGFBQUwsQ0FBbUJSLElBQW5CLHlJQUFyQjtBQUNBLFVBQUtTLFNBQUwsR0FBa0IsTUFBS0EsU0FBTCxDQUFlVCxJQUFmLHlJQUFsQjtBQWhCZTtBQWlCaEI7Ozs7d0NBRW1CO0FBQ2xCLFdBQUtVLFVBQUwsR0FEa0IsQ0FFbEI7O0FBRUEsZ0JBQWlDO0FBQy9CQyxzREFBQyxDQUFDQyxNQUFELENBQUQsQ0FBVUMsTUFBVixDQUFpQixZQUFZO0FBQzNCLGNBQUlBLE1BQU0sR0FBR0YsOENBQUMsQ0FBQ0MsTUFBRCxDQUFELENBQVVFLFNBQVYsRUFBYjs7QUFFQSxjQUFJRCxNQUFNLElBQUksRUFBZCxFQUFrQjtBQUNoQkYsMERBQUMsQ0FBQyxtQkFBRCxDQUFELENBQXVCSSxRQUF2QixDQUFnQyxRQUFoQztBQUNBSiwwREFBQyxDQUFDLGFBQUQsQ0FBRCxDQUFpQkksUUFBakIsQ0FBMEIsT0FBMUI7QUFDRCxXQUhELE1BR087QUFDTEosMERBQUMsQ0FBQyxtQkFBRCxDQUFELENBQXVCSyxXQUF2QixDQUFtQyxRQUFuQztBQUNBTCwwREFBQyxDQUFDLGFBQUQsQ0FBRCxDQUFpQkssV0FBakIsQ0FBNkIsT0FBN0I7QUFDRDtBQUVGLFNBWEQ7QUFZRDs7QUFBQTtBQUdGOzs7MkNBRXNCLENBQ3JCO0FBQ0QsSyxDQUVEOzs7O2lDQUNZO0FBQ1YsVUFBR0wsOENBQUMsQ0FBQywrQkFBRCxDQUFELENBQW1DTSxFQUFuQyxDQUFzQyxVQUF0QyxDQUFILEVBQXNEO0FBQ3BETixzREFBQyxDQUFDLHlDQUFELENBQUQsQ0FBNkNPLEtBQTdDLENBQW1ELFlBQVU7QUFDM0RQLHdEQUFDLENBQUMsSUFBRCxDQUFELENBQVFRLFFBQVIsQ0FBaUIsVUFBakIsRUFBNkJDLFdBQTdCO0FBQ0QsU0FGRDtBQUdEO0FBQ0Y7OzsrQkFFVTtBQUNULFdBQUt2QixLQUFMLENBQVd3QixPQUFYLENBQW1CQyxJQUFuQixDQUF3QixHQUF4QjtBQUNEOzs7a0NBQ2E7QUFDWixXQUFLekIsS0FBTCxDQUFXd0IsT0FBWCxDQUFtQkMsSUFBbkIsQ0FBd0IsV0FBeEI7QUFDRDs7O2tDQUVjO0FBQ2IsV0FBS3pCLEtBQUwsQ0FBV3dCLE9BQVgsQ0FBbUJDLElBQW5CLENBQXdCLFVBQXhCO0FBQ0Q7OztvQ0FDZTtBQUNkLFdBQUt6QixLQUFMLENBQVd3QixPQUFYLENBQW1CQyxJQUFuQixDQUF3QixZQUF4QjtBQUNEOzs7a0NBQ2E7QUFDWixXQUFLekIsS0FBTCxDQUFXd0IsT0FBWCxDQUFtQkMsSUFBbkIsQ0FBd0IsVUFBeEI7QUFDRDs7OzJCQUVPO0FBQ04sV0FBS3pCLEtBQUwsQ0FBV3dCLE9BQVgsQ0FBbUJDLElBQW5CLENBQXdCLE9BQXhCO0FBQ0Q7OztrQ0FFYTtBQUNaLFdBQUt6QixLQUFMLENBQVd3QixPQUFYLENBQW1CQyxJQUFuQixDQUF3QixTQUF4QjtBQUNEOzs7b0NBQ2U7QUFDZCxXQUFLekIsS0FBTCxDQUFXd0IsT0FBWCxDQUFtQkMsSUFBbkIsQ0FBd0IsYUFBeEI7QUFDRDs7O29DQUVlO0FBQ2QsV0FBS3pCLEtBQUwsQ0FBV3dCLE9BQVgsQ0FBbUJDLElBQW5CLENBQXdCLFlBQXhCO0FBQ0Q7OztvQ0FDZTtBQUNkLFdBQUt6QixLQUFMLENBQVd3QixPQUFYLENBQW1CQyxJQUFuQixDQUF3Qiw4QkFBeEI7QUFDRDs7O2dDQUNXO0FBQ1YsV0FBS3pCLEtBQUwsQ0FBV3dCLE9BQVgsQ0FBbUJDLElBQW5CLENBQXdCLFFBQXhCO0FBQ0Q7Ozs2QkFFUTtBQUFBLHdCQUNnQyxLQUFLekIsS0FEckM7QUFBQSxVQUNBMEIsS0FEQSxlQUNBQSxLQURBO0FBQUEsVUFDT0MsV0FEUCxlQUNPQSxXQURQO0FBQUEsVUFDb0JDLFFBRHBCLGVBQ29CQSxRQURwQjtBQUVQLDBCQUNFO0FBQVEsaUJBQVMsRUFBQyxtQkFBbEI7QUFBQSxnQ0FDRSw4REFBQyxrREFBRDtBQUFBLGtDQUNFO0FBQUEsc0JBQVFGO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQU0sZ0JBQUksRUFBQyxhQUFYO0FBQXlCLG1CQUFPLEVBQUVDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkYsZUFHRTtBQUFNLG9CQUFRLEVBQUMsU0FBZjtBQUF5QixtQkFBTyxFQUFFQztBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUhGLGVBSUU7QUFBTSxvQkFBUSxFQUFDLFVBQWY7QUFBMEIsbUJBQU8sRUFBRUY7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFKRixlQUtFO0FBQU0sb0JBQVEsRUFBQyxnQkFBZjtBQUFnQyxtQkFBTyxFQUFFQztBQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUxGLGVBTUU7QUFBTSxvQkFBUSxFQUFDLGNBQWY7QUFBOEIsbUJBQU8sRUFBQztBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU5GLGVBT0U7QUFBTSxvQkFBUSxFQUFDLGNBQWY7QUFBOEIsbUJBQU8sRUFBQztBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVBGLGVBUUU7QUFBTSxvQkFBUSxFQUFDLGlCQUFmO0FBQWlDLG1CQUFPLEVBQUM7QUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFSRixlQVNFO0FBQU0sb0JBQVEsRUFBQyxlQUFmO0FBQStCLG1CQUFPLEVBQUM7QUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFURixlQVVFO0FBQU0sb0JBQVEsRUFBQyxxQkFBZjtBQUFxQyxtQkFBTyxFQUFFQTtBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQWFFO0FBQUssbUJBQVMsRUFBQyxZQUFmO0FBQTRCLFlBQUUsRUFBQyxjQUEvQjtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxvREFBZjtBQUFBLG9DQUNFO0FBQ0UsdUJBQVMsRUFBQyxnQkFEWjtBQUVFLGtCQUFJLEVBQUMsUUFGUDtBQUdFLDZCQUFZLFVBSGQ7QUFJRSw2QkFBWSxzQkFKZDtBQUtFLCtCQUFjLHFCQUxoQjtBQU1FLCtCQUFjLE9BTmhCO0FBT0UsNEJBQVcsbUJBUGI7QUFBQSxxQ0FTRTtBQUFNLHlCQUFTLEVBQUM7QUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFhRTtBQUFLLGdCQUFFLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWJGLGVBY0UsOERBQUMsa0RBQUQ7QUFBTSxrQkFBSSxFQUFDLEdBQVg7QUFBZSx1QkFBUyxFQUFDLGNBQXpCO0FBQUEscUNBQ0U7QUFDRSxrQkFBRSxFQUFDLE1BREw7QUFFRSx5QkFBUyxFQUFDLE1BRlo7QUFHRSxtQkFBRyxFQUFDLDhCQUhOO0FBSUUsbUJBQUcsRUFBQztBQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWRGLGVBdUJFO0FBQUssdUJBQVMsRUFBQyxpQ0FBZjtBQUFBLHFDQUNFO0FBQUcsb0JBQUksRUFBQyw0QkFBUjtBQUFBLHVDQUNFO0FBQUsscUJBQUcsRUFBQywyQkFBVDtBQUFxQyxxQkFBRyxFQUFDO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkF2QkYsZUE2QkU7QUFDRSx1QkFBUyxFQUFDLHNDQURaO0FBRUUsZ0JBQUUsRUFBQyxxQkFGTDtBQUFBLHNDQUlFO0FBQUsseUJBQVMsRUFBQyxpQ0FBZjtBQUFBLHdDQUNFO0FBQUksMkJBQVMsRUFBQyxVQUFkO0FBQUEseUNBQ0UsOERBQUMsa0RBQUQ7QUFDRSx3QkFBSSxFQUFDLFdBRFA7QUFBQSwyQ0FJRTtBQUFLLCtCQUFTLEVBQUMsVUFBZjtBQUEyQixxQ0FBZSxFQUFDLFFBQTNDO0FBQUEsaUNBQ0csR0FESCw0QkFFVztBQUFNLGlDQUFTLEVBQUMsU0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFhRTtBQUFJLDJCQUFTLEVBQUMsVUFBZDtBQUFBLDBDQUNFLDhEQUFDLGtEQUFEO0FBQ0Usd0JBQUksRUFBQyxVQURQO0FBQUEsMkNBSUU7QUFBSSwrQkFBUyxFQUFDLFVBQWQ7QUFDSyxxQ0FBZSxFQUFDLFFBRHJCO0FBQUEsMERBR0U7QUFBRyxpQ0FBUyxFQUFDLGtCQUFiO0FBQWdDLHVDQUFZO0FBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFERixlQVdFO0FBQUcsNkJBQVMsRUFBQyxrQkFBYjtBQUFnQyxtQ0FBWTtBQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVhGLGVBWUU7QUFBSSw2QkFBUyxFQUFDLFNBQWQ7QUFBQSwyQ0FDRTtBQUFLLCtCQUFTLEVBQUMsU0FBZjtBQUFBLDhDQUNFO0FBQUssaUNBQVMsRUFBQyxjQUFmO0FBQUEsZ0RBQ0U7QUFBQSxpREFDRSw4REFBQyxrREFBRDtBQUFNLGdDQUFJLEVBQUMsZ0NBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBTUU7QUFBQSxpREFDRSw4REFBQyxrREFBRDtBQUFNLGdDQUFJLEVBQUMsaUNBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQU5GLGVBV0U7QUFBQSxpREFDRSw4REFBQyxrREFBRDtBQUFNLGdDQUFJLEVBQUMsaUNBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFERixlQWtCRTtBQUFLLGlDQUFTLEVBQUMsY0FBZjtBQUFBLGdEQUVFO0FBQUEsaURBQ0UsOERBQUMsa0RBQUQ7QUFBTSxnQ0FBSSxFQUFDLG9CQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FGRixlQU9FO0FBQUEsaURBQ0UsOERBQUMsa0RBQUQ7QUFBTSxnQ0FBSSxFQUFDLHlCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FQRixlQVlFO0FBQUEsaURBQ0UsOERBQUMsa0RBQUQ7QUFBTSxnQ0FBSSxFQUFDLCtCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWJGLGVBbUVFO0FBQUksMkJBQVMsRUFBQyxVQUFkO0FBQUEseUNBQ0UsOERBQUMsa0RBQUQ7QUFDRSx3QkFBSSxFQUFDLFVBRFA7QUFBQSwyQ0FJQTtBQUFLLCtCQUFTLEVBQUMsVUFBZjtBQUEyQixxQ0FBZSxFQUFDLFFBQTNDO0FBQUEsaUNBQ0MsR0FERCwyQkFFUTtBQUFNLGlDQUFTLEVBQUMsU0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBbkVGLGVBK0VFO0FBQUksMkJBQVMsRUFBQyxVQUFkO0FBQUEseUNBQ0UsOERBQUMsa0RBQUQ7QUFDRSx3QkFBSSxFQUFDLE9BRFA7QUFBQSwyQ0FJQTtBQUFLLCtCQUFTLEVBQUMsVUFBZjtBQUEyQixxQ0FBZSxFQUFDLFFBQTNDO0FBQUEsaUNBQ0MsR0FERCx3QkFFSztBQUFNLGlDQUFTLEVBQUMsU0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBL0VGLGVBMkZFO0FBQUksMkJBQVMsRUFBQyxVQUFkO0FBQUEseUNBQ0UsOERBQUMsa0RBQUQ7QUFDRSx3QkFBSSxFQUFDLFVBRFA7QUFBQSwyQ0FJQTtBQUFLLCtCQUFTLEVBQUMsVUFBZjtBQUEyQixxQ0FBZSxFQUFDLFFBQTNDO0FBQUEsaUNBQ0MsR0FERCwyQkFFUTtBQUFNLGlDQUFTLEVBQUMsU0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBM0ZGLGVBdUdFO0FBQUksMkJBQVMsRUFBQyxVQUFkO0FBQUEseUNBQ0UsOERBQUMsa0RBQUQ7QUFDRSx3QkFBSSxFQUFDLDhCQURQO0FBQUEsMkNBSUE7QUFBSywrQkFBUyxFQUFDLFVBQWY7QUFBMkIscUNBQWUsRUFBQyxRQUEzQztBQUFBLGlDQUNDLEdBREQsZ0NBRWE7QUFBTSxpQ0FBUyxFQUFDLFNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUZiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXZHRixlQW1IRTtBQUFJLDJCQUFTLEVBQUMsVUFBZDtBQUFBLHlDQUNFLDhEQUFDLGtEQUFEO0FBQ0Usd0JBQUksRUFBQyxhQURQO0FBQUEsMkNBSUE7QUFBSywrQkFBUyxFQUFDLFVBQWY7QUFBMkIscUNBQWUsRUFBQyxRQUEzQztBQUFBLGlDQUNDLEdBREQsOEJBRVc7QUFBTSxpQ0FBUyxFQUFDLFNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQW5IRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBSkYsZUFvSUU7QUFBSyx5QkFBUyxFQUFDLDBCQUFmO0FBQUEsd0NBQ0U7QUFBUSwyQkFBUyxFQUFDLG1FQUFsQjtBQUFBLHlDQUNFLDhEQUFDLGtEQUFEO0FBQU0sd0JBQUksRUFBQyxHQUFYO0FBQWUsNkJBQVMsRUFBQyxTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFNRSw4REFBQyxrREFBRDtBQUFNLHNCQUFJLEVBQUMsYUFBWDtBQUFBLHlDQUNFO0FBQVEsNkJBQVMsRUFBQyx1RUFBbEI7QUFBQSwyQ0FDRSw4REFBQyxrREFBRDtBQUFNLDBCQUFJLEVBQUMsYUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFwSUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGO0FBaU1EOzs7O0VBalNpQ0UsNEMiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvY2FzZS1zdHVkaWVzL2Nhc2VzdHVkeS1saXN0LjNkMjA2YTVlM2Q5NGZhZDhkYTk2LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xyXG4vLyBpbXBvcnQgeyBIYXNoTGluayBhcyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWhhc2gtbGluayc7XHJcbi8vIGltcG9ydCB7IE5hdkhhc2hMaW5rIGFzIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItaGFzaC1saW5rJztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XHJcblxyXG5pbXBvcnQgRHJvcGRvd24gZnJvbSAnLi4vZHJvcGRvd24vaW5kZXguanN4JztcclxuaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEhlYWRlciBleHRlbmRzIENvbXBvbmVudCB7XHJcblxyXG5jb25zdHJ1Y3Rvcihwcm9wcykgeyAgICBcclxuICBzdXBlcihwcm9wcylcclxuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgZ2xvYmFsLndpbmRvdyA9IHt9O1xyXG4gIH1cclxuICAgIHRoaXMuc3RhdGUgPSB7XHJcbiAgICB9XHJcbiAgICB0aGlzLkhvbWVQYWdlID0gdGhpcy5Ib21lUGFnZS5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5BYm91dHVzUGFnZSA9IHRoaXMuQWJvdXR1c1BhZ2UuYmluZCh0aGlzKTtcclxuICAgIHRoaXMuU2VydmljZVBhZ2UgPSB0aGlzLlNlcnZpY2VQYWdlLmJpbmQodGhpcyk7XHJcbiAgICB0aGlzLldvcmRwcmVzc1BhZ2UgPSB0aGlzLldvcmRwcmVzc1BhZ2UuYmluZCh0aGlzKTtcclxuICAgIHRoaXMuU2hvcGlmeVBhZ2UgPSB0aGlzLlNob3BpZnlQYWdlLmJpbmQodGhpcyk7XHJcbiAgICB0aGlzLkJsb2cgPSB0aGlzLkJsb2cuYmluZCh0aGlzKTtcclxuICAgIHRoaXMuQ2FyZWVyc1BhZ2UgPSB0aGlzLkNhcmVlcnNQYWdlLmJpbmQodGhpcyk7XHJcbiAgICB0aGlzLkNvbnRhY3R1c1BhZ2UgPSB0aGlzLkNvbnRhY3R1c1BhZ2UuYmluZCh0aGlzKTtcclxuICAgIHRoaXMuZmlsZW1ha2VyUGFnZSA9IHRoaXMuZmlsZW1ha2VyUGFnZS5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5FcnJvclBhZ2UgID0gdGhpcy5FcnJvclBhZ2UuYmluZCh0aGlzKTtcclxuICB9XHJcblxyXG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xyXG4gICAgdGhpcy5tZW51VG9nZ2xlKCk7XHJcbiAgICAvLyB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCB0aGlzLm1lbnVUb2dnbGUpO1xyXG5cclxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgJCh3aW5kb3cpLnNjcm9sbChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIHNjcm9sbCA9ICQod2luZG93KS5zY3JvbGxUb3AoKTtcclxuXHJcbiAgICAgICAgaWYgKHNjcm9sbCA+PSA3NCkge1xyXG4gICAgICAgICAgJCgnLmhlYWRlci1jb250YWluZXInKS5hZGRDbGFzcygnc3RpY2t5Jyk7XHJcbiAgICAgICAgICAkKCcuc2VydmljZS1iZycpLmFkZENsYXNzKCdmaXhlZCcpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAkKCcuaGVhZGVyLWNvbnRhaW5lcicpLnJlbW92ZUNsYXNzKCdzdGlja3knKTtcclxuICAgICAgICAgICQoJy5zZXJ2aWNlLWJnJykucmVtb3ZlQ2xhc3MoJ2ZpeGVkJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgfSlcclxuICAgIH07XHJcblxyXG5cclxuICB9XHJcblxyXG4gIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xyXG4gICAgLy8gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgdGhpcy5tZW51VG9nZ2xlKTtcclxuICB9XHJcblxyXG4gIC8vbWVudSB0b2dnbGUgb24gbW9iaWxlXHJcbiAgbWVudVRvZ2dsZSgpe1xyXG4gICAgaWYoJChcIi5uYXZiYXItbGlnaHQgLm5hdmJhci10b2dnbGVyXCIpLmlzKFwiOnZpc2libGVcIikpIHsgXHJcbiAgICAgICQoXCIubmF2YmFyLWxpZ2h0IC5uYXZiYXItbmF2IC5uYXYtaXRlbSA+IGlcIikuY2xpY2soZnVuY3Rpb24oKXtcclxuICAgICAgICAkKHRoaXMpLnNpYmxpbmdzKCcuc3VibWVudScpLnNsaWRlVG9nZ2xlKCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgSG9tZVBhZ2UoKSB7XHJcbiAgICB0aGlzLnByb3BzLmhpc3RvcnkucHVzaCgnLycpO1xyXG4gIH1cclxuICBBYm91dHVzUGFnZSgpIHtcclxuICAgIHRoaXMucHJvcHMuaGlzdG9yeS5wdXNoKCcvYWJvdXQtdXMnKTtcclxuICB9XHJcbiAgXHJcbiAgIFNlcnZpY2VQYWdlKCkge1xyXG4gICAgdGhpcy5wcm9wcy5oaXN0b3J5LnB1c2goJy9zZXZpY2VzJyk7XHJcbiAgfVxyXG4gIFdvcmRwcmVzc1BhZ2UoKSB7XHJcbiAgICB0aGlzLnByb3BzLmhpc3RvcnkucHVzaCgnL3dvcmRwcmVzcycpO1xyXG4gIH1cclxuICBTaG9waWZ5UGFnZSgpIHtcclxuICAgIHRoaXMucHJvcHMuaGlzdG9yeS5wdXNoKCcvc2hvcGlmeScpO1xyXG4gIH1cclxuICBcclxuICAgQmxvZygpIHtcclxuICAgIHRoaXMucHJvcHMuaGlzdG9yeS5wdXNoKCcvYmxvZycpO1xyXG4gIH1cclxuXHJcbiAgQ2FyZWVyc1BhZ2UoKSB7XHJcbiAgICB0aGlzLnByb3BzLmhpc3RvcnkucHVzaCgnY2FyZWVycycpO1xyXG4gIH1cclxuICBDb250YWN0dXNQYWdlKCkge1xyXG4gICAgdGhpcy5wcm9wcy5oaXN0b3J5LnB1c2goJy9jb250YWN0LXVzJyk7XHJcbiAgfVxyXG4gIFxyXG4gIGZpbGVtYWtlclBhZ2UoKSB7XHJcbiAgICB0aGlzLnByb3BzLmhpc3RvcnkucHVzaCgnL2ZpbGVtYWtlcicpO1xyXG4gIH1cclxuICBmaWxlbWFrZXJQYWdlKCkge1xyXG4gICAgdGhpcy5wcm9wcy5oaXN0b3J5LnB1c2goJy9jYXNlLXN0dWRpZXMvY2FzZXN0dWR5LWxpc3QnKTtcclxuICB9XHJcbiAgRXJyb3JQYWdlKCkge1xyXG4gICAgdGhpcy5wcm9wcy5oaXN0b3J5LnB1c2goJy9lcnJvcicpO1xyXG4gIH1cclxuXHJcbiAgcmVuZGVyKCkge1xyXG4gICAgY29uc3Qge3RpdGxlLCBkZXNjcmlwdGlvbiwga2V5d29yZHN9ID0gdGhpcy5wcm9wc1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJoZWFkZXItY29udGFpbmVyIFwiPlxyXG4gICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgPHRpdGxlPnt0aXRsZX08L3RpdGxlPlxyXG4gICAgICAgICAgPG1ldGEgbmFtZT1cImRlc2NyaXB0aW9uXCIgY29udGVudD17ZGVzY3JpcHRpb259IC8+XHJcbiAgICAgICAgICA8bWV0YSBwcm9wZXJ0eT1cIm9nOnR5cGVcIiBjb250ZW50PXtrZXl3b3Jkc30gLz5cclxuICAgICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6dGl0bGVcIiBjb250ZW50PXt0aXRsZX0gLz5cclxuICAgICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6ZGVzY3JpcHRpb25cIiBjb250ZW50PXtkZXNjcmlwdGlvbn0gLz5cclxuICAgICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6c2l0ZV9uYW1lXCIgY29udGVudD0naGFzaHRhZycgLz5cclxuICAgICAgICAgIDxtZXRhIHByb3BlcnR5PVwidHdpdHRlcjpjYXJkXCIgY29udGVudD1cInN1bW1hcnlcIiAvPlxyXG4gICAgICAgICAgPG1ldGEgcHJvcGVydHk9XCJ0d2l0dGVyOmNyZWF0b3JcIiBjb250ZW50PSd0d2l0dGVyJyAvPlxyXG4gICAgICAgICAgPG1ldGEgcHJvcGVydHk9XCJ0d2l0dGVyOnRpdGxlXCIgY29udGVudD0ndGl0bGUnIC8+XHJcbiAgICAgICAgICA8bWV0YSBwcm9wZXJ0eT1cInR3aXR0ZXI6ZGVzY3JpcHRpb25cIiBjb250ZW50PXtkZXNjcmlwdGlvbiB9Lz5cclxuICAgICAgICA8L0hlYWQ+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgXCIgaWQ9XCJtYWluLXNlY3Rpb25cIj5cclxuICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwibmF2YmFyIG5hdmJhci1leHBhbmQtbGcgbmF2YmFyLWxpZ2h0IGJnLWxpZ2h0IHB4LTVcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm5hdmJhci10b2dnbGVyXCJcclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBkYXRhLXRvZ2dsZT1cImNvbGxhcHNlXCJcclxuICAgICAgICAgICAgICBkYXRhLXRhcmdldD1cIiNuYXZiYXJUb2dnbGVyRGVtbzAzXCJcclxuICAgICAgICAgICAgICBhcmlhLWNvbnRyb2xzPVwibmF2YmFyVG9nZ2xlckRlbW8wM1wiXHJcbiAgICAgICAgICAgICAgYXJpYS1leHBhbmRlZD1cImZhbHNlXCJcclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiVG9nZ2xlIG5hdmlnYXRpb25cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibmF2YmFyLXRvZ2dsZXItaWNvblwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGlkPVwibWVudS1jb250YWluZXJcIj48L2Rpdj5cclxuICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9cIiBjbGFzc05hbWU9XCJuYXZiYXItYnJhbmRcIj5cclxuICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICBpZD1cImxvZ29cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibG9nb1wiXHJcbiAgICAgICAgICAgICAgICBzcmM9XCIvaGFzaHRhZy1uZXctbG9nby1oZWFkZXIuc3ZnXCJcclxuICAgICAgICAgICAgICAgIGFsdD1cImxvZ29cIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9iLXRvcC1lbWFpbCBkLWJsb2NrIGQtc20tbm9uZVwiPlxyXG4gICAgICAgICAgICAgIDxhIGhyZWY9XCJtYWlsdG86aW5mb0BoYXNodGFnLWNhLmNvbVwiPlxyXG4gICAgICAgICAgICAgICAgPGltZyBzcmM9XCIvaW1hZ2VzL21vYi10b3AtZW1haWwuc3ZnXCIgYWx0PVwiZW1haWxcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sbGFwc2UgbmF2YmFyLWNvbGxhcHNlIGhlYWRlci1tZW51XCJcclxuICAgICAgICAgICAgICBpZD1cIm5hdmJhclRvZ2dsZXJEZW1vMDNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHVsICBjbGFzc05hbWU9XCJuYXZiYXItbmF2IG1yLWF1dG8gbXQtMiBtdC1sZy0wXCI+XHJcbiAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwibmF2LWl0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICBocmVmPVwiL2Fib3V0LXVzXCJcclxuICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGEgICBjbGFzc05hbWU9XCJuYXYtbGlua1wiICBhY3RpdmVjbGFzc05hbWU9XCJhY3RpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIEFib3V0IFVzIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj4oY3VycmVudCk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG5cclxuICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJuYXYtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9XCIvc2V2aWNlc1wiXHJcbiAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhICBjbGFzc05hbWU9XCJuYXYtbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVjbGFzc05hbWU9XCJhY3RpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHNlcnZpY2VzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS1hbmdsZS1kb3duXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS1hbmdsZS1kb3duXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3VibWVudVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IG0tMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtNiBwLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvc2V2aWNlcy93b3JkcHJlc3MtZGV2ZWxvcG1lbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFdvcmRwcmVzcyBEZXZlbG9wbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvc2V2aWNlcy9ibG9ja2NoYWluLWRldmVsb3BtZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBCbG9ja2NoYWluIERldmVsb3BtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9zZXZpY2VzL2Rlc2lnbi1hbmQtcHJvdG90eXBpbmdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlc2lnbiBhbmQgUHJvdG90eXBpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTYgcC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKjxsaT48TmF2TGluayB0bz1cIi9zZXZpY2VzL2F3c1wiPkFXUzwvTmF2TGluaz48L2xpPiovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9zZXZpY2VzL2ZpbGVtYWtlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRmlsZU1ha2VyIFBybyBEZXZlbG9wbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvc2V2aWNlcy91aS1kZXZlbG9wbWVudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVUkgRGV2ZWxvcG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiL3NldmljZXMvZGF0YWJhc2UtYW5kLWJhY2tlbmRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERCICYgQmFja2VuZCBEZXZlbG9wbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qPGxpPjxOYXZMaW5rIHRvPVwiL3NldmljZXMvbW9iaWxlLWFwcFwiPk1vYmlsZSBBcHAgRGV2ZWxvcG1lbnQ8L05hdkxpbms+PC9saT4qL31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuXHJcbiAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwibmF2LWl0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICBocmVmPVwiL3Nob3BpZnlcIlxyXG4gICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGEgICBjbGFzc05hbWU9XCJuYXYtbGlua1wiICBhY3RpdmVjbGFzc05hbWU9XCJhY3RpdmVcIj5cclxuICAgICAgICAgICAgICAgICAge1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICBTaG9waWZ5IDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj4oY3VycmVudCk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cIm5hdi1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cIi9ibG9nXCJcclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGEgICBjbGFzc05hbWU9XCJuYXYtbGlua1wiICBhY3RpdmVjbGFzc05hbWU9XCJhY3RpdmVcIj5cclxuICAgICAgICAgICAgICAgICAge1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICBCbG9nIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj4oY3VycmVudCk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJuYXYtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9XCIvY2FyZWVyc1wiXHJcbiAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8YSAgIGNsYXNzTmFtZT1cIm5hdi1saW5rXCIgIGFjdGl2ZWNsYXNzTmFtZT1cImFjdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICB7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIENhcmVlcnMgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPihjdXJyZW50KTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cIm5hdi1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cIi9jYXNlLXN0dWRpZXMvY2FzZXN0dWR5LWxpc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxhICAgY2xhc3NOYW1lPVwibmF2LWxpbmtcIiAgYWN0aXZlY2xhc3NOYW1lPVwiYWN0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgQ2FzZSBzdHVkaWVzIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj4oY3VycmVudCk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cIm5hdi1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cIi9jb250YWN0LXVzXCJcclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGEgICBjbGFzc05hbWU9XCJuYXYtbGlua1wiICBhY3RpdmVjbGFzc05hbWU9XCJhY3RpdmVcIj5cclxuICAgICAgICAgICAgICAgICAge1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICBDb250YWN0IFVzIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj4oY3VycmVudCk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0taW5saW5lIG15LTIgbXktbGctMFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tdHJhbnNwYXJlbnQgYnRuLWhlYWRlci0xIGJ0biBidG4tb3V0bGluZS1zdWNjZXNzIG15LTIgbXktc20tMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiL1wiIGNsYXNzTmFtZT1cImVuLWxpbmtcIj5cclxuICAgICAgICAgICAgICAgICAgICBFblxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvY29udGFjdC11c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInNwZWFrLWJ0biBidG4taGVhZGVyLTIgYnRuLXdoaXRlIGJ0biBidG4tb3V0bGluZS1zdWNjZXNzIG15LTIgbXktc20tMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvY29udGFjdC11c1wiPkxldCdzIFNwZWFrPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L25hdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9oZWFkZXI+XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9