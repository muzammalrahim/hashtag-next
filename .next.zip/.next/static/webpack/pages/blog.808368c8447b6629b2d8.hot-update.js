self["webpackHotUpdate_N_E"]("pages/blog",{

/***/ "./pages/blog/index.jsx":
/*!******************************!*\
  !*** ./pages/blog/index.jsx ***!
  \******************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Blog; }
/* harmony export */ });
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_header_index_jsx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../components/header/index.jsx */ "./components/header/index.jsx");
/* harmony import */ var _components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../components/footer/index.jsx */ "./components/footer/index.jsx");
/* harmony import */ var _components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../components/post-category/index.jsx */ "./components/post-category/index.jsx");
/* harmony import */ var _components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../components/post-recent/index.jsx */ "./components/post-recent/index.jsx");
/* harmony import */ var react_document_meta__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-document-meta */ "./node_modules/react-document-meta/dist/index.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! react-infinite-scroller */ "./node_modules/react-infinite-scroller/index.js");
/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_infinite_scroller__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../config.js */ "./config.js");
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! query-string */ "./node_modules/query-string/index.js");
/* harmony import */ var react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! react-reveal/Reveal */ "./node_modules/react-reveal/Reveal.js");
/* harmony import */ var react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_23__);
/* module decorator */ module = __webpack_require__.hmd(module);










var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\pages\\blog\\index.jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }



 // import Underconstruction from '../../components/under-construction/index.jsx';














__webpack_require__(/*! typeface-montserrat */ "./node_modules/typeface-montserrat/index.css");

var __N_SSP = true;

var Blog = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__.default)(Blog, _Component);

  var _super = _createSuper(Blog);

  function Blog(props) {
    var _this;

    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_4__.default)(this, Blog);

    _this = _super.call(this, props);
    var response = _this.props;

    if (false) {}

    _this.state = {
      allPosts: [],
      hasMoreItems: true,
      page: 1,
      no_items: "",
      search_val: "",
      keyword: "",
      data: response.data
    };
    _this.shiftContent = _this.shiftContent.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    _this.get_allPosts = _this.get_allPosts.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    _this.handleChange = _this.handleChange.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    _this.onSubmit = _this.onSubmit.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    return _this;
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__.default)(Blog, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.shiftContent();

      if (true) {
        window.addEventListener("resize", this.shiftContent);
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (true) {
        window.removeEventListener("resize", this.shiftContent);
      }
    }
  }, {
    key: "handleChange",
    value: function handleChange(e) {
      this.setState({
        search_val: e.target.value
      });
    }
  }, {
    key: "onSubmit",
    value: function onSubmit(e) {
      e.preventDefault();
      var values = this.state.search_val;
      this.setState({
        keyword: values,
        page: 1,
        allPosts: [],
        hasMoreItems: true,
        no_items: ""
      });
      this.props.history.push("/blogs?keyword=" + this.state.search_val);
    } //Search div shift

  }, {
    key: "shiftContent",
    value: function shiftContent() {
      if (jquery__WEBPACK_IMPORTED_MODULE_18___default()(".mob-visible").is(":visible")) {
        jquery__WEBPACK_IMPORTED_MODULE_18___default()(".widget_search").insertBefore(jquery__WEBPACK_IMPORTED_MODULE_18___default()(".blog-list"));
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_18___default()(".widget_search").insertBefore(jquery__WEBPACK_IMPORTED_MODULE_18___default()(".widget_recent_entries"));
      }
    } //Get posts

  }, {
    key: "get_allPosts",
    value: function () {
      var _get_allPosts = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__.default)( /*#__PURE__*/E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee() {
        var _this2 = this;

        var url, page, keyword;
        return E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                url = _config_js__WEBPACK_IMPORTED_MODULE_20__.myConfig.apiUrl + "blog/posts";
                page = this.state.page;
                keyword = this.state.keyword;
                axios__WEBPACK_IMPORTED_MODULE_19___default().get(url, {
                  params: {
                    page: page,
                    keyword: keyword
                  }
                }).then(function (response) {
                  var allPosts = _this2.state.allPosts;
                  response.data.data.posts.map(function (data) {
                    allPosts.push(data);
                  });

                  if (response.data.data.more_exists == true) {
                    _this2.setState({
                      allPosts: allPosts,
                      hasMoreItems: true,
                      page: page + 1
                    });
                  } else {
                    if (allPosts.length == 0) {
                      console.log("No posts found.");

                      _this2.setState({
                        hasMoreItems: false,
                        no_items: "No posts found."
                      });
                    } else {
                      _this2.setState({
                        hasMoreItems: false
                      });
                    }
                  }
                })["catch"](function (error) {
                  // console.log(error.response);
                  console.log("API error.");
                  react_toastify__WEBPACK_IMPORTED_MODULE_24__.toast.error("Something went wrong.");
                });

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function get_allPosts() {
        return _get_allPosts.apply(this, arguments);
      }

      return get_allPosts;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      console.log(data);
      var meta = {
        title: "Blogs - FullStack Web Development| Bay area, California",
        meta: {
          charset: "utf-8",
          name: {
            keywords: "Web development company,software development company,web development kochi,web development company kochi,software development kochi,web development company kochi,software development kochi,web design and development kochi,full stack development company,wordpress customisation company kerala,shopify theme development company kerala,ecommerce development company kerala,woocommerce development company kerala,web development company California,software development california,wordpress development california,wordpress development kochi,shopify development kochi,shopify development california,wordpress customisation company,shopify theme development company,ecommerce development company kochi,ecommerce development company california"
          }
        }
      };

      var loader = /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "loader",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "spinner",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 168,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 169,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 170,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 171,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 167,
          columnNumber: 9
        }, this), "Loading"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 166,
        columnNumber: 7
      }, this);

      var post_lists = [];
      this.state.allPosts.map(function (post, index) {
        post_lists.push( /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_22___default()), {
          bottom: true,
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
            className: "card",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h5", {
              className: "card-title text-level-4 title-orange",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), {
                href: "/blog/single/[slug]",
                as: "/blog/single/" + post.url,
                children: post.title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 183,
                columnNumber: 15
              }, _this3)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 182,
              columnNumber: 13
            }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "blog-img",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), {
                href: "/blog/single/[slug]",
                as: "/blog/single/" + post.url,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "blog-thumb",
                  style: {
                    backgroundImage: post.image == null ? "/images/blogs/writing-good-blog.jpg" : "url(".concat(post.image, ")")
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 195,
                  columnNumber: 17
                }, _this3)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 191,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                className: "card-img-overlay",
                children: post.categories.map(function (cat, i) {
                  var _jsxDEV2;

                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), (_jsxDEV2 = {
                    href: "/blog/category/[slug]"
                  }, (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(_jsxDEV2, "href", "/blog/category/" + cat.slug), (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(_jsxDEV2, "className", "btn btn-light btn-sm"), (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(_jsxDEV2, "children", cat.name), _jsxDEV2), i, false, {
                    fileName: _jsxFileName,
                    lineNumber: 209,
                    columnNumber: 21
                  }, _this3);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 206,
                columnNumber: 15
              }, _this3)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 190,
              columnNumber: 13
            }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "card-body",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h4", {
                className: "card-title text-level-4 title-orange",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), {
                  href: "/blog/single/[slug]",
                  as: "/blog/single/" + post.url,
                  children: post.title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 223,
                  columnNumber: 17
                }, _this3)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 222,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("small", {
                className: "text-muted cat text-above-main-title author-blk",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("i", {
                  className: "fa fa-hashtag",
                  "aria-hidden": "true"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 231,
                  columnNumber: 17
                }, _this3), " ", post.author]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 230,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                className: "card-text",
                children: post.excerpt
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 234,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
                className: "cta-link",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), {
                  href: "/blog/single/[slug].jsx",
                  as: "/blog/single/" + post.url,
                  className: "shopify-sub-title",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("a", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
                      children: "Read More"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 242,
                      columnNumber: 21
                    }, _this3), " ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("i", {
                      className: "fa fa-chevron-right",
                      "aria-hidden": "true"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 243,
                      columnNumber: 21
                    }, _this3)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 241,
                    columnNumber: 19
                  }, _this3)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 236,
                  columnNumber: 17
                }, _this3)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 235,
                columnNumber: 15
              }, _this3)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 221,
              columnNumber: 13
            }, _this3)]
          }, index, true, {
            fileName: _jsxFileName,
            lineNumber: 181,
            columnNumber: 11
          }, _this3)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 180,
          columnNumber: 9
        }, _this3));
      });
      var data = this.state.data;
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "blog-main",
        id: "blog-main",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_toastify__WEBPACK_IMPORTED_MODULE_24__.ToastContainer, {
          transition: react_toastify__WEBPACK_IMPORTED_MODULE_24__.Slide
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 255,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_document_meta__WEBPACK_IMPORTED_MODULE_15__.default, _objectSpread({}, meta), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 256,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_header_index_jsx__WEBPACK_IMPORTED_MODULE_11__.default, {
          title: data.title,
          description: data.description,
          keywords: data.keywords
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 257,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("section", {
          "class": "content-container",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
            className: "container-fluid service-bg p-0 m-0 ",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "service-bg-right",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                className: "service-banner-frame",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "container ",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                    className: "row justify-content-center service-banner-content pl-3 pr-3",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                        className: "sub-text-above-main-title title-white",
                        children: "Read Us"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 269,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h1", {
                        className: "main-title title-white d-block",
                        children: "Blogs"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 272,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 268,
                      columnNumber: 21
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12 text-white  ",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                        className: "bold-contents service-content-box pl-4",
                        children: "We are seeking brilliant minds to join our dynamic team and make it even better."
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 275,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 274,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 267,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 266,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 265,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 264,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 263,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
            className: "blog-section",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "container",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                className: "row b-row-1",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-8 col-lg-8",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                    className: "blog-wrap",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                      className: "blog-list",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((react_infinite_scroller__WEBPACK_IMPORTED_MODULE_17___default()), {
                        initialLoad: true,
                        loadMore: this.get_allPosts,
                        hasMore: this.state.hasMoreItems,
                        loader: loader,
                        children: post_lists
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 292,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                        children: this.state.no_items
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 300,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 291,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 290,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 289,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-4 col-lg-4",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                    className: "blog-sidebar",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("aside", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                        id: "search-4",
                        className: "widget widget_search posts_holder",
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("form", {
                          role: "search",
                          id: "searchform",
                          className: "searchform",
                          onSubmit: this.onSubmit,
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("input", {
                              type: "text",
                              name: "s",
                              id: "blog-search",
                              placeholder: "Search",
                              className: "placeholder",
                              value: this.state.search_val,
                              onChange: this.handleChange
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 319,
                              columnNumber: 29
                            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("button", {
                              type: "submit",
                              name: "search-submit",
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("i", {
                                className: "fa fa-search",
                                "aria-hidden": "true"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 329,
                                columnNumber: 31
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 328,
                              columnNumber: 29
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 318,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 312,
                          columnNumber: 25
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 308,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_14__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 337,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_13__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 338,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 307,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 306,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 305,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 288,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 287,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 286,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 262,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "mob-visible"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 346,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 347,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 254,
        columnNumber: 7
      }, this);
    }
  }]);

  return Blog;
}(react__WEBPACK_IMPORTED_MODULE_10__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYmxvZy9pbmRleC5qc3giXSwibmFtZXMiOlsicmVxdWlyZSIsIkJsb2ciLCJwcm9wcyIsInJlc3BvbnNlIiwic3RhdGUiLCJhbGxQb3N0cyIsImhhc01vcmVJdGVtcyIsInBhZ2UiLCJub19pdGVtcyIsInNlYXJjaF92YWwiLCJrZXl3b3JkIiwiZGF0YSIsInNoaWZ0Q29udGVudCIsImJpbmQiLCJnZXRfYWxsUG9zdHMiLCJoYW5kbGVDaGFuZ2UiLCJvblN1Ym1pdCIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiZSIsInNldFN0YXRlIiwidGFyZ2V0IiwidmFsdWUiLCJwcmV2ZW50RGVmYXVsdCIsInZhbHVlcyIsImhpc3RvcnkiLCJwdXNoIiwiJCIsImlzIiwiaW5zZXJ0QmVmb3JlIiwidXJsIiwiY29uZmlnIiwiYXhpb3MiLCJwYXJhbXMiLCJ0aGVuIiwicG9zdHMiLCJtYXAiLCJtb3JlX2V4aXN0cyIsImxlbmd0aCIsImNvbnNvbGUiLCJsb2ciLCJlcnJvciIsInRvYXN0IiwibWV0YSIsInRpdGxlIiwiY2hhcnNldCIsIm5hbWUiLCJrZXl3b3JkcyIsImxvYWRlciIsInBvc3RfbGlzdHMiLCJwb3N0IiwiaW5kZXgiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJpbWFnZSIsImNhdGVnb3JpZXMiLCJjYXQiLCJpIiwic2x1ZyIsImF1dGhvciIsImV4Y2VycHQiLCJTbGlkZSIsImRlc2NyaXB0aW9uIiwiQ29tcG9uZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0NBRUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBQSxtQkFBTyxDQUFDLHlFQUFELENBQVA7Ozs7SUE0QnFCQyxJOzs7OztBQUNuQixnQkFBWUMsS0FBWixFQUFtQjtBQUFBOztBQUFBOztBQUNqQiw4QkFBTUEsS0FBTjtBQUNBLFFBQUlDLFFBQVEsR0FBRyxNQUFLRCxLQUFwQjs7QUFDQSxlQUFtQyxFQUVsQzs7QUFDRCxVQUFLRSxLQUFMLEdBQWE7QUFDWEMsY0FBUSxFQUFFLEVBREM7QUFFWEMsa0JBQVksRUFBRSxJQUZIO0FBR1hDLFVBQUksRUFBRSxDQUhLO0FBSVhDLGNBQVEsRUFBRSxFQUpDO0FBS1hDLGdCQUFVLEVBQUUsRUFMRDtBQU1YQyxhQUFPLEVBQUUsRUFORTtBQU9YQyxVQUFJLEVBQUVSLFFBQVEsQ0FBQ1E7QUFQSixLQUFiO0FBVUEsVUFBS0MsWUFBTCxHQUFvQixNQUFLQSxZQUFMLENBQWtCQyxJQUFsQix5SUFBcEI7QUFDQSxVQUFLQyxZQUFMLEdBQW9CLE1BQUtBLFlBQUwsQ0FBa0JELElBQWxCLHlJQUFwQjtBQUVBLFVBQUtFLFlBQUwsR0FBb0IsTUFBS0EsWUFBTCxDQUFrQkYsSUFBbEIseUlBQXBCO0FBQ0EsVUFBS0csUUFBTCxHQUFnQixNQUFLQSxRQUFMLENBQWNILElBQWQseUlBQWhCO0FBcEJpQjtBQXFCbEI7Ozs7d0NBRW1CO0FBQ2xCLFdBQUtELFlBQUw7O0FBQ0EsZ0JBQWlDO0FBQy9CSyxjQUFNLENBQUNDLGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDLEtBQUtOLFlBQXZDO0FBQ0Q7QUFDRjs7OzJDQUVzQjtBQUNyQixnQkFBaUM7QUFDL0JLLGNBQU0sQ0FBQ0UsbUJBQVAsQ0FBMkIsUUFBM0IsRUFBcUMsS0FBS1AsWUFBMUM7QUFDRDtBQUNGOzs7aUNBRVlRLEMsRUFBRztBQUNkLFdBQUtDLFFBQUwsQ0FBYztBQUNaWixrQkFBVSxFQUFFVyxDQUFDLENBQUNFLE1BQUYsQ0FBU0M7QUFEVCxPQUFkO0FBR0Q7Ozs2QkFFUUgsQyxFQUFHO0FBQ1ZBLE9BQUMsQ0FBQ0ksY0FBRjtBQUNBLFVBQU1DLE1BQU0sR0FBRyxLQUFLckIsS0FBTCxDQUFXSyxVQUExQjtBQUNBLFdBQUtZLFFBQUwsQ0FBYztBQUNaWCxlQUFPLEVBQUVlLE1BREc7QUFFWmxCLFlBQUksRUFBRSxDQUZNO0FBR1pGLGdCQUFRLEVBQUUsRUFIRTtBQUlaQyxvQkFBWSxFQUFFLElBSkY7QUFLWkUsZ0JBQVEsRUFBRTtBQUxFLE9BQWQ7QUFPQSxXQUFLTixLQUFMLENBQVd3QixPQUFYLENBQW1CQyxJQUFuQixDQUF3QixvQkFBb0IsS0FBS3ZCLEtBQUwsQ0FBV0ssVUFBdkQ7QUFDRCxLLENBRUQ7Ozs7bUNBQ2U7QUFDYixVQUFJbUIsOENBQUMsQ0FBQyxjQUFELENBQUQsQ0FBa0JDLEVBQWxCLENBQXFCLFVBQXJCLENBQUosRUFBc0M7QUFDcENELHNEQUFDLENBQUMsZ0JBQUQsQ0FBRCxDQUFvQkUsWUFBcEIsQ0FBaUNGLDhDQUFDLENBQUMsWUFBRCxDQUFsQztBQUNELE9BRkQsTUFFTztBQUNMQSxzREFBQyxDQUFDLGdCQUFELENBQUQsQ0FBb0JFLFlBQXBCLENBQWlDRiw4Q0FBQyxDQUFDLHdCQUFELENBQWxDO0FBQ0Q7QUFDRixLLENBRUQ7Ozs7Ozs7Ozs7Ozs7QUFFTUcsbUIsR0FBTUMsd0RBQUEsR0FBeUIsWTtBQUMvQnpCLG9CLEdBQU8sS0FBS0gsS0FBTCxDQUFXRyxJO0FBQ2xCRyx1QixHQUFVLEtBQUtOLEtBQUwsQ0FBV00sTztBQUV6QnVCLGlFQUFBLENBQ09GLEdBRFAsRUFDWTtBQUFFRyx3QkFBTSxFQUFFO0FBQUUzQix3QkFBSSxFQUFFQSxJQUFSO0FBQWNHLDJCQUFPLEVBQUVBO0FBQXZCO0FBQVYsaUJBRFosRUFFR3lCLElBRkgsQ0FFUSxVQUFDaEMsUUFBRCxFQUFjO0FBQ2xCLHNCQUFNRSxRQUFRLEdBQUcsTUFBSSxDQUFDRCxLQUFMLENBQVdDLFFBQTVCO0FBRUFGLDBCQUFRLENBQUNRLElBQVQsQ0FBY0EsSUFBZCxDQUFtQnlCLEtBQW5CLENBQXlCQyxHQUF6QixDQUE2QixVQUFDMUIsSUFBRCxFQUFVO0FBQ3JDTiw0QkFBUSxDQUFDc0IsSUFBVCxDQUFjaEIsSUFBZDtBQUNELG1CQUZEOztBQUlBLHNCQUFJUixRQUFRLENBQUNRLElBQVQsQ0FBY0EsSUFBZCxDQUFtQjJCLFdBQW5CLElBQWtDLElBQXRDLEVBQTRDO0FBQzFDLDBCQUFJLENBQUNqQixRQUFMLENBQWM7QUFDWmhCLDhCQUFRLEVBQUVBLFFBREU7QUFFWkMsa0NBQVksRUFBRSxJQUZGO0FBR1pDLDBCQUFJLEVBQUVBLElBQUksR0FBRztBQUhELHFCQUFkO0FBS0QsbUJBTkQsTUFNTztBQUNMLHdCQUFJRixRQUFRLENBQUNrQyxNQUFULElBQW1CLENBQXZCLEVBQTBCO0FBQ3hCQyw2QkFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7O0FBQ0EsNEJBQUksQ0FBQ3BCLFFBQUwsQ0FBYztBQUNaZixvQ0FBWSxFQUFFLEtBREY7QUFFWkUsZ0NBQVEsRUFBRTtBQUZFLHVCQUFkO0FBSUQscUJBTkQsTUFNTztBQUNMLDRCQUFJLENBQUNhLFFBQUwsQ0FBYztBQUNaZixvQ0FBWSxFQUFFO0FBREYsdUJBQWQ7QUFHRDtBQUNGO0FBQ0YsaUJBNUJILFdBNkJTLFVBQUNvQyxLQUFELEVBQVc7QUFDaEI7QUFDQUYseUJBQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVo7QUFDQUUsMEVBQUEsQ0FBWSx1QkFBWjtBQUNELGlCQWpDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzZCQW9DTztBQUFBOztBQUNQSCxhQUFPLENBQUNDLEdBQVIsQ0FBWTlCLElBQVo7QUFDQSxVQUFNaUMsSUFBSSxHQUFHO0FBQ1hDLGFBQUssRUFBRSx5REFESTtBQUVYRCxZQUFJLEVBQUU7QUFDSkUsaUJBQU8sRUFBRSxPQURMO0FBRUpDLGNBQUksRUFBRTtBQUNKQyxvQkFBUSxFQUNOO0FBRkU7QUFGRjtBQUZLLE9BQWI7O0FBVUEsVUFBTUMsTUFBTSxnQkFDVjtBQUFLLGlCQUFTLEVBQUMsUUFBZjtBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBQyxTQUFmO0FBQUEsa0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUhGLGVBSUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREY7O0FBWUEsVUFBSUMsVUFBVSxHQUFHLEVBQWpCO0FBQ0EsV0FBSzlDLEtBQUwsQ0FBV0MsUUFBWCxDQUFvQmdDLEdBQXBCLENBQXdCLFVBQUNjLElBQUQsRUFBT0MsS0FBUCxFQUFpQjtBQUN2Q0Ysa0JBQVUsQ0FBQ3ZCLElBQVgsZUFDRSw4REFBQyw2REFBRDtBQUFNLGdCQUFNLE1BQVo7QUFBQSxpQ0FDRTtBQUFLLHFCQUFTLEVBQUMsTUFBZjtBQUFBLG9DQUNFO0FBQUksdUJBQVMsRUFBQyxzQ0FBZDtBQUFBLHFDQUNFLDhEQUFDLG1EQUFEO0FBQ0Usb0JBQUksRUFBRSxxQkFEUjtBQUVFLGtCQUFFLEVBQUUsa0JBQWtCd0IsSUFBSSxDQUFDcEIsR0FGN0I7QUFBQSwwQkFJR29CLElBQUksQ0FBQ047QUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQVNFO0FBQUssdUJBQVMsRUFBQyxVQUFmO0FBQUEsc0NBQ0UsOERBQUMsbURBQUQ7QUFDRSxvQkFBSSxFQUFFLHFCQURSO0FBRUUsa0JBQUUsRUFBRSxrQkFBa0JNLElBQUksQ0FBQ3BCLEdBRjdCO0FBQUEsdUNBSUU7QUFDRSwyQkFBUyxFQUFDLFlBRFo7QUFFRSx1QkFBSyxFQUFFO0FBQ0xzQixtQ0FBZSxFQUNiRixJQUFJLENBQUNHLEtBQUwsSUFBYyxJQUFkLEdBQ0kscUNBREosaUJBRVdILElBQUksQ0FBQ0csS0FGaEI7QUFGRztBQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBZ0JFO0FBQUsseUJBQVMsRUFBQyxrQkFBZjtBQUFBLDBCQUNHSCxJQUFJLENBQUNJLFVBQUwsQ0FBZ0JsQixHQUFoQixDQUFvQixVQUFDbUIsR0FBRCxFQUFNQyxDQUFOLEVBQVk7QUFBQTs7QUFDL0Isc0NBQ0UsOERBQUMsbURBQUQ7QUFDRSx3QkFBSSxFQUFFO0FBRFIsaUtBRVEsb0JBQW9CRCxHQUFHLENBQUNFLElBRmhDLG9KQUdZLHNCQUhaLG1KQU1HRixHQUFHLENBQUNULElBTlAsY0FJT1UsQ0FKUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQURGO0FBVUQsaUJBWEE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBVEYsZUF3Q0U7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSxzQ0FDRTtBQUFJLHlCQUFTLEVBQUMsc0NBQWQ7QUFBQSx1Q0FDRSw4REFBQyxtREFBRDtBQUNFLHNCQUFJLEVBQUUscUJBRFI7QUFFRSxvQkFBRSxFQUFFLGtCQUFrQk4sSUFBSSxDQUFDcEIsR0FGN0I7QUFBQSw0QkFJR29CLElBQUksQ0FBQ047QUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQVNFO0FBQU8seUJBQVMsRUFBQyxpREFBakI7QUFBQSx3Q0FDRTtBQUFHLDJCQUFTLEVBQUMsZUFBYjtBQUE2QixpQ0FBWTtBQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURGLEVBQ3VELEdBRHZELEVBRUdNLElBQUksQ0FBQ1EsTUFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBVEYsZUFhRTtBQUFHLHlCQUFTLEVBQUMsV0FBYjtBQUFBLDBCQUEwQlIsSUFBSSxDQUFDUztBQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWJGLGVBY0U7QUFBTSx5QkFBUyxFQUFDLFVBQWhCO0FBQUEsdUNBQ0UsOERBQUMsbURBQUQ7QUFDRSxzQkFBSSxFQUFFLHlCQURSO0FBRUUsb0JBQUUsRUFBRSxrQkFBa0JULElBQUksQ0FBQ3BCLEdBRjdCO0FBR0UsMkJBQVMsRUFBQyxtQkFIWjtBQUFBLHlDQUtFO0FBQUEsNENBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBREYsRUFDeUIsR0FEekIsZUFFRTtBQUFHLCtCQUFTLEVBQUMscUJBQWI7QUFBbUMscUNBQVk7QUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBeENGO0FBQUEsYUFBMkJxQixLQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERjtBQXdFRCxPQXpFRDtBQXpCTyxVQW1HQ3pDLElBbkdELEdBbUdVLEtBQUtQLEtBbkdmLENBbUdDTyxJQW5HRDtBQW9HUCwwQkFDRTtBQUFLLGlCQUFTLEVBQUMsV0FBZjtBQUEyQixVQUFFLEVBQUMsV0FBOUI7QUFBQSxnQ0FDRSw4REFBQywyREFBRDtBQUFnQixvQkFBVSxFQUFFa0Qsa0RBQUtBO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFFRSw4REFBQyx5REFBRCxvQkFBa0JqQixJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGLGVBR0UsOERBQUMsa0VBQUQ7QUFDRSxlQUFLLEVBQUVqQyxJQUFJLENBQUNrQyxLQURkO0FBRUUscUJBQVcsRUFBRWxDLElBQUksQ0FBQ21ELFdBRnBCO0FBR0Usa0JBQVEsRUFBRW5ELElBQUksQ0FBQ3FDO0FBSGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSEYsZUFRRTtBQUFTLG1CQUFNLG1CQUFmO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLHFDQUFmO0FBQUEsbUNBQ0U7QUFBSyx1QkFBUyxFQUFDLGtCQUFmO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLHNCQUFmO0FBQUEsdUNBQ0U7QUFBSywyQkFBUyxFQUFDLFlBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsNkRBQWY7QUFBQSw0Q0FDRTtBQUFLLCtCQUFTLEVBQUMsb0JBQWY7QUFBQSw4Q0FDRTtBQUFHLGlDQUFTLEVBQUMsdUNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBREYsZUFJRTtBQUFJLGlDQUFTLEVBQUMsZ0NBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQURGLGVBT0U7QUFBSywrQkFBUyxFQUFDLGlDQUFmO0FBQUEsNkNBQ0U7QUFBRyxpQ0FBUyxFQUFDLHdDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBd0JFO0FBQUsscUJBQVMsRUFBQyxjQUFmO0FBQUEsbUNBQ0U7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSxxQ0FDRTtBQUFLLHlCQUFTLEVBQUMsYUFBZjtBQUFBLHdDQUNFO0FBQUssMkJBQVMsRUFBQyxvQ0FBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxXQUFmO0FBQUEsMkNBQ0U7QUFBSywrQkFBUyxFQUFDLFdBQWY7QUFBQSw4Q0FDRSw4REFBQyxpRUFBRDtBQUNFLG1DQUFXLEVBQUUsSUFEZjtBQUVFLGdDQUFRLEVBQUUsS0FBS2xDLFlBRmpCO0FBR0UsK0JBQU8sRUFBRSxLQUFLVixLQUFMLENBQVdFLFlBSHRCO0FBSUUsOEJBQU0sRUFBRTJDLE1BSlY7QUFBQSxrQ0FNR0M7QUFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURGLGVBU0U7QUFBQSxrQ0FBSSxLQUFLOUMsS0FBTCxDQUFXSTtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFpQkU7QUFBSywyQkFBUyxFQUFDLG9DQUFmO0FBQUEseUNBQ0U7QUFBSyw2QkFBUyxFQUFDLGNBQWY7QUFBQSwyQ0FDRTtBQUFBLDhDQUNFO0FBQ0UsMEJBQUUsRUFBQyxVQURMO0FBRUUsaUNBQVMsRUFBQyxtQ0FGWjtBQUFBLCtDQUlFO0FBQ0UsOEJBQUksRUFBQyxRQURQO0FBRUUsNEJBQUUsRUFBQyxZQUZMO0FBR0UsbUNBQVMsRUFBQyxZQUhaO0FBSUUsa0NBQVEsRUFBRSxLQUFLUSxRQUpqQjtBQUFBLGlEQU1FO0FBQUEsb0RBQ0U7QUFDRSxrQ0FBSSxFQUFDLE1BRFA7QUFFRSxrQ0FBSSxFQUFDLEdBRlA7QUFHRSxnQ0FBRSxFQUFDLGFBSEw7QUFJRSx5Q0FBVyxFQUFDLFFBSmQ7QUFLRSx1Q0FBUyxFQUFDLGFBTFo7QUFNRSxtQ0FBSyxFQUFFLEtBQUtaLEtBQUwsQ0FBV0ssVUFOcEI7QUFPRSxzQ0FBUSxFQUFFLEtBQUtNO0FBUGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBREYsZUFVRTtBQUFRLGtDQUFJLEVBQUMsUUFBYjtBQUFzQixrQ0FBSSxFQUFDLGVBQTNCO0FBQUEscURBQ0U7QUFDRSx5Q0FBUyxFQUFDLGNBRFo7QUFFRSwrQ0FBWTtBQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURGLGVBOEJFLDhEQUFDLHVFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBOUJGLGVBK0JFLDhEQUFDLHlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVJGLGVBNEZFO0FBQUssbUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBNUZGLGVBNkZFLDhEQUFDLGtFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBN0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGO0FBaUdEOzs7O0VBaFQrQmdELDZDIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2Jsb2cuODA4MzY4Yzg0NDdiNjYyOWIyZDguaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEhlYWRlciBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9oZWFkZXIvaW5kZXguanN4XCI7XHJcbmltcG9ydCBGb290ZXIgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvZm9vdGVyL2luZGV4LmpzeFwiO1xyXG4vLyBpbXBvcnQgVW5kZXJjb25zdHJ1Y3Rpb24gZnJvbSAnLi4vLi4vY29tcG9uZW50cy91bmRlci1jb25zdHJ1Y3Rpb24vaW5kZXguanN4JztcclxuaW1wb3J0IEJsb2dDYXRlZ29yaWVzIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL3Bvc3QtY2F0ZWdvcnkvaW5kZXguanN4XCI7XHJcbmltcG9ydCBCbG9nUmVjZW50UG9zdHMgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvcG9zdC1yZWNlbnQvaW5kZXguanN4XCI7XHJcbmltcG9ydCBEb2N1bWVudE1ldGEgZnJvbSBcInJlYWN0LWRvY3VtZW50LW1ldGFcIjtcclxuaW1wb3J0IHsgVG9hc3RDb250YWluZXIsIHRvYXN0LCBTbGlkZSB9IGZyb20gXCJyZWFjdC10b2FzdGlmeVwiO1xyXG5pbXBvcnQgXCJyZWFjdC10b2FzdGlmeS9kaXN0L1JlYWN0VG9hc3RpZnkuY3NzXCI7XHJcbmltcG9ydCBJbmZpbml0ZVNjcm9sbCBmcm9tIFwicmVhY3QtaW5maW5pdGUtc2Nyb2xsZXJcIjtcclxuaW1wb3J0ICQgZnJvbSBcImpxdWVyeVwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCAqIGFzIGNvbmZpZyBmcm9tIFwiLi4vLi4vY29uZmlnLmpzXCI7XHJcbmltcG9ydCBxdWVyeVN0cmluZyBmcm9tIFwicXVlcnktc3RyaW5nXCI7XHJcbmltcG9ydCBGbGlwIGZyb20gXCJyZWFjdC1yZXZlYWwvUmV2ZWFsXCI7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuXHJcbnJlcXVpcmUoXCJ0eXBlZmFjZS1tb250c2VycmF0XCIpO1xyXG5pbXBvcnQgQXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBodHRwcyBmcm9tIFwiaHR0cHNcIjtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoKSB7XHJcbiAgbGV0IGRhdGEgPSBbXTtcclxuXHJcbiAgY29uc3QgaW5zdGFuY2UgPSBBeGlvcy5jcmVhdGUoe1xyXG4gICAgaHR0cHNBZ2VudDogbmV3IGh0dHBzLkFnZW50KHtcclxuICAgICAgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZSxcclxuICAgIH0pLFxyXG4gIH0pO1xyXG5cclxuICBhd2FpdCBpbnN0YW5jZVxyXG4gICAgLmdldChcImh0dHBzOi8vYXBpLmhhc2h0YWctY2EuY29tL2FwaS92MS9tZXRhZGF0YVwiLCB7XHJcbiAgICAgIHBhcmFtczoge1xyXG4gICAgICAgIHBhZ2VfdHlwZTogXCJzdGF0aWNcIixcclxuICAgICAgICBzbHVnOiBcInNldmljZXNcIixcclxuICAgICAgfSxcclxuICAgIH0pXHJcbiAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgZGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgICB9KTtcclxuICByZXR1cm4ge1xyXG4gICAgcHJvcHM6IHsgZGF0YSB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEJsb2cgZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gIGNvbnN0cnVjdG9yKHByb3BzKSB7XHJcbiAgICBzdXBlcihwcm9wcyk7XHJcbiAgICBsZXQgcmVzcG9uc2UgPSB0aGlzLnByb3BzO1xyXG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgZ2xvYmFsLndpbmRvdyA9IHt9O1xyXG4gICAgfVxyXG4gICAgdGhpcy5zdGF0ZSA9IHtcclxuICAgICAgYWxsUG9zdHM6IFtdLFxyXG4gICAgICBoYXNNb3JlSXRlbXM6IHRydWUsXHJcbiAgICAgIHBhZ2U6IDEsXHJcbiAgICAgIG5vX2l0ZW1zOiBcIlwiLFxyXG4gICAgICBzZWFyY2hfdmFsOiBcIlwiLFxyXG4gICAgICBrZXl3b3JkOiBcIlwiLFxyXG4gICAgICBkYXRhOiByZXNwb25zZS5kYXRhLFxyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLnNoaWZ0Q29udGVudCA9IHRoaXMuc2hpZnRDb250ZW50LmJpbmQodGhpcyk7XHJcbiAgICB0aGlzLmdldF9hbGxQb3N0cyA9IHRoaXMuZ2V0X2FsbFBvc3RzLmJpbmQodGhpcyk7XHJcblxyXG4gICAgdGhpcy5oYW5kbGVDaGFuZ2UgPSB0aGlzLmhhbmRsZUNoYW5nZS5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5vblN1Ym1pdCA9IHRoaXMub25TdWJtaXQuYmluZCh0aGlzKTtcclxuICB9XHJcblxyXG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xyXG4gICAgdGhpcy5zaGlmdENvbnRlbnQoKTtcclxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgdGhpcy5zaGlmdENvbnRlbnQpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHRoaXMuc2hpZnRDb250ZW50KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGhhbmRsZUNoYW5nZShlKSB7XHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgc2VhcmNoX3ZhbDogZS50YXJnZXQudmFsdWUsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIG9uU3VibWl0KGUpIHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IHZhbHVlcyA9IHRoaXMuc3RhdGUuc2VhcmNoX3ZhbDtcclxuICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICBrZXl3b3JkOiB2YWx1ZXMsXHJcbiAgICAgIHBhZ2U6IDEsXHJcbiAgICAgIGFsbFBvc3RzOiBbXSxcclxuICAgICAgaGFzTW9yZUl0ZW1zOiB0cnVlLFxyXG4gICAgICBub19pdGVtczogXCJcIixcclxuICAgIH0pO1xyXG4gICAgdGhpcy5wcm9wcy5oaXN0b3J5LnB1c2goXCIvYmxvZ3M/a2V5d29yZD1cIiArIHRoaXMuc3RhdGUuc2VhcmNoX3ZhbCk7XHJcbiAgfVxyXG5cclxuICAvL1NlYXJjaCBkaXYgc2hpZnRcclxuICBzaGlmdENvbnRlbnQoKSB7XHJcbiAgICBpZiAoJChcIi5tb2ItdmlzaWJsZVwiKS5pcyhcIjp2aXNpYmxlXCIpKSB7XHJcbiAgICAgICQoXCIud2lkZ2V0X3NlYXJjaFwiKS5pbnNlcnRCZWZvcmUoJChcIi5ibG9nLWxpc3RcIikpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgJChcIi53aWRnZXRfc2VhcmNoXCIpLmluc2VydEJlZm9yZSgkKFwiLndpZGdldF9yZWNlbnRfZW50cmllc1wiKSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvL0dldCBwb3N0c1xyXG4gIGFzeW5jIGdldF9hbGxQb3N0cygpIHtcclxuICAgIHZhciB1cmwgPSBjb25maWcubXlDb25maWcuYXBpVXJsICsgXCJibG9nL3Bvc3RzXCI7XHJcbiAgICB2YXIgcGFnZSA9IHRoaXMuc3RhdGUucGFnZTtcclxuICAgIHZhciBrZXl3b3JkID0gdGhpcy5zdGF0ZS5rZXl3b3JkO1xyXG5cclxuICAgIGF4aW9zXHJcbiAgICAgIC5nZXQodXJsLCB7IHBhcmFtczogeyBwYWdlOiBwYWdlLCBrZXl3b3JkOiBrZXl3b3JkIH0gfSlcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYWxsUG9zdHMgPSB0aGlzLnN0YXRlLmFsbFBvc3RzO1xyXG5cclxuICAgICAgICByZXNwb25zZS5kYXRhLmRhdGEucG9zdHMubWFwKChkYXRhKSA9PiB7XHJcbiAgICAgICAgICBhbGxQb3N0cy5wdXNoKGRhdGEpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5kYXRhLm1vcmVfZXhpc3RzID09IHRydWUpIHtcclxuICAgICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICBhbGxQb3N0czogYWxsUG9zdHMsXHJcbiAgICAgICAgICAgIGhhc01vcmVJdGVtczogdHJ1ZSxcclxuICAgICAgICAgICAgcGFnZTogcGFnZSArIDEsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgaWYgKGFsbFBvc3RzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTm8gcG9zdHMgZm91bmQuXCIpO1xyXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgICAgICBoYXNNb3JlSXRlbXM6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG5vX2l0ZW1zOiBcIk5vIHBvc3RzIGZvdW5kLlwiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICAgIGhhc01vcmVJdGVtczogZmFsc2UsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGVycm9yLnJlc3BvbnNlKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkFQSSBlcnJvci5cIik7XHJcbiAgICAgICAgdG9hc3QuZXJyb3IoXCJTb21ldGhpbmcgd2VudCB3cm9uZy5cIik7XHJcbiAgICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcmVuZGVyKCkge1xyXG4gICAgY29uc29sZS5sb2coZGF0YSlcclxuICAgIGNvbnN0IG1ldGEgPSB7XHJcbiAgICAgIHRpdGxlOiBcIkJsb2dzIC0gRnVsbFN0YWNrIFdlYiBEZXZlbG9wbWVudHwgQmF5IGFyZWEsIENhbGlmb3JuaWFcIixcclxuICAgICAgbWV0YToge1xyXG4gICAgICAgIGNoYXJzZXQ6IFwidXRmLThcIixcclxuICAgICAgICBuYW1lOiB7XHJcbiAgICAgICAgICBrZXl3b3JkczpcclxuICAgICAgICAgICAgXCJXZWIgZGV2ZWxvcG1lbnQgY29tcGFueSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBjb21wYW55LHdlYiBkZXZlbG9wbWVudCBrb2NoaSx3ZWIgZGV2ZWxvcG1lbnQgY29tcGFueSBrb2NoaSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBrb2NoaSx3ZWIgZGV2ZWxvcG1lbnQgY29tcGFueSBrb2NoaSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBrb2NoaSx3ZWIgZGVzaWduIGFuZCBkZXZlbG9wbWVudCBrb2NoaSxmdWxsIHN0YWNrIGRldmVsb3BtZW50IGNvbXBhbnksd29yZHByZXNzIGN1c3RvbWlzYXRpb24gY29tcGFueSBrZXJhbGEsc2hvcGlmeSB0aGVtZSBkZXZlbG9wbWVudCBjb21wYW55IGtlcmFsYSxlY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBrZXJhbGEsd29vY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBrZXJhbGEsd2ViIGRldmVsb3BtZW50IGNvbXBhbnkgQ2FsaWZvcm5pYSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBjYWxpZm9ybmlhLHdvcmRwcmVzcyBkZXZlbG9wbWVudCBjYWxpZm9ybmlhLHdvcmRwcmVzcyBkZXZlbG9wbWVudCBrb2NoaSxzaG9waWZ5IGRldmVsb3BtZW50IGtvY2hpLHNob3BpZnkgZGV2ZWxvcG1lbnQgY2FsaWZvcm5pYSx3b3JkcHJlc3MgY3VzdG9taXNhdGlvbiBjb21wYW55LHNob3BpZnkgdGhlbWUgZGV2ZWxvcG1lbnQgY29tcGFueSxlY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBrb2NoaSxlY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBjYWxpZm9ybmlhXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgIH07XHJcbiAgICBjb25zdCBsb2FkZXIgPSAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9hZGVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGlubmVyXCI+XHJcbiAgICAgICAgICA8ZGl2PjwvZGl2PlxyXG4gICAgICAgICAgPGRpdj48L2Rpdj5cclxuICAgICAgICAgIDxkaXY+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PjwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIExvYWRpbmdcclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG5cclxuICAgIHZhciBwb3N0X2xpc3RzID0gW107XHJcbiAgICB0aGlzLnN0YXRlLmFsbFBvc3RzLm1hcCgocG9zdCwgaW5kZXgpID0+IHtcclxuICAgICAgcG9zdF9saXN0cy5wdXNoKFxyXG4gICAgICAgIDxGbGlwIGJvdHRvbT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiIGtleT17aW5kZXh9PlxyXG4gICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwiY2FyZC10aXRsZSB0ZXh0LWxldmVsLTQgdGl0bGUtb3JhbmdlXCI+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvc2luZ2xlL1tzbHVnXVwifVxyXG4gICAgICAgICAgICAgICAgYXM9e1wiL2Jsb2cvc2luZ2xlL1wiICsgcG9zdC51cmx9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3Bvc3QudGl0bGV9XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2g1PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctaW1nXCI+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvc2luZ2xlL1tzbHVnXVwifVxyXG4gICAgICAgICAgICAgICAgYXM9e1wiL2Jsb2cvc2luZ2xlL1wiICsgcG9zdC51cmx9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9nLXRodW1iXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6XHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3N0LmltYWdlID09IG51bGxcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcIi9pbWFnZXMvYmxvZ3Mvd3JpdGluZy1nb29kLWJsb2cuanBnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBgdXJsKCR7cG9zdC5pbWFnZX0pYCxcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgIHsvKnsgKHBvc3QuaW1hZ2UgPT0gbnVsbCkgPyA8aW1nIHNyYz1cIi9pbWFnZXMvYmxvZ3Mvd3JpdGluZy1nb29kLWJsb2cuanBnXCIgYWx0PXtwb3N0LmltYWdlX2FsdH0gLz4gOiA8aW1nIHNyYz17cG9zdC5pbWFnZX0gYWx0PXtwb3N0LmltYWdlX2FsdH0gLz4gfSovfVxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtaW1nLW92ZXJsYXlcIj5cclxuICAgICAgICAgICAgICAgIHtwb3N0LmNhdGVnb3JpZXMubWFwKChjYXQsIGkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj17XCIvYmxvZy9jYXRlZ29yeS9bc2x1Z11cIn1cclxuICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvY2F0ZWdvcnkvXCIgKyBjYXQuc2x1Z31cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0biBidG4tbGlnaHQgYnRuLXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y2F0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keVwiPlxyXG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJjYXJkLXRpdGxlIHRleHQtbGV2ZWwtNCB0aXRsZS1vcmFuZ2VcIj5cclxuICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvc2luZ2xlL1tzbHVnXVwifVxyXG4gICAgICAgICAgICAgICAgICBhcz17XCIvYmxvZy9zaW5nbGUvXCIgKyBwb3N0LnVybH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3Bvc3QudGl0bGV9XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICA8c21hbGwgY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBjYXQgdGV4dC1hYm92ZS1tYWluLXRpdGxlIGF1dGhvci1ibGtcIj5cclxuICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLWhhc2h0YWdcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48L2k+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAge3Bvc3QuYXV0aG9yfVxyXG4gICAgICAgICAgICAgIDwvc21hbGw+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY2FyZC10ZXh0XCI+e3Bvc3QuZXhjZXJwdH08L3A+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY3RhLWxpbmtcIj5cclxuICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvc2luZ2xlL1tzbHVnXS5qc3hcIn1cclxuICAgICAgICAgICAgICAgICAgYXM9e1wiL2Jsb2cvc2luZ2xlL1wiICsgcG9zdC51cmx9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNob3BpZnktc3ViLXRpdGxlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGE+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVhZCBNb3JlPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS1jaGV2cm9uLXJpZ2h0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvRmxpcD5cclxuICAgICAgKTtcclxuICAgIH0pO1xyXG4gICAgY29uc3QgeyBkYXRhIH0gPSB0aGlzLnN0YXRlO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLW1haW5cIiBpZD1cImJsb2ctbWFpblwiPlxyXG4gICAgICAgIDxUb2FzdENvbnRhaW5lciB0cmFuc2l0aW9uPXtTbGlkZX0gLz5cclxuICAgICAgICA8RG9jdW1lbnRNZXRhIHsuLi5tZXRhfSAvPlxyXG4gICAgICAgIDxIZWFkZXJcclxuICAgICAgICAgIHRpdGxlPXtkYXRhLnRpdGxlfVxyXG4gICAgICAgICAgZGVzY3JpcHRpb249e2RhdGEuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICBrZXl3b3Jkcz17ZGF0YS5rZXl3b3Jkc31cclxuICAgICAgICA+PC9IZWFkZXI+XHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3M9XCJjb250ZW50LWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItZmx1aWQgc2VydmljZS1iZyBwLTAgbS0wIFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmctcmlnaHRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmFubmVyLWZyYW1lXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cganVzdGlmeS1jb250ZW50LWNlbnRlciBzZXJ2aWNlLWJhbm5lci1jb250ZW50IHBsLTMgcHItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzdWItdGV4dC1hYm92ZS1tYWluLXRpdGxlIHRpdGxlLXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWQgVXNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJtYWluLXRpdGxlIHRpdGxlLXdoaXRlIGQtYmxvY2tcIj5CbG9nczwvaDE+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbGctNiBjb2wtbWQtMTIgdGV4dC13aGl0ZSAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJib2xkLWNvbnRlbnRzIHNlcnZpY2UtY29udGVudC1ib3ggcGwtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBXZSBhcmUgc2Vla2luZyBicmlsbGlhbnQgbWluZHMgdG8gam9pbiBvdXIgZHluYW1pYyB0ZWFtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFuZCBtYWtlIGl0IGV2ZW4gYmV0dGVyLlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYi1yb3ctMVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLXNtLTEyIGNvbC1tZC04IGNvbC1sZy04XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWxpc3RcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbmZpbml0ZVNjcm9sbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpbml0aWFsTG9hZD17dHJ1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE1vcmU9e3RoaXMuZ2V0X2FsbFBvc3RzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYXNNb3JlPXt0aGlzLnN0YXRlLmhhc01vcmVJdGVtc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGVyPXtsb2FkZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwb3N0X2xpc3RzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9JbmZpbml0ZVNjcm9sbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwPnt0aGlzLnN0YXRlLm5vX2l0ZW1zfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtc20tMTIgY29sLW1kLTQgY29sLWxnLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXNpZGViYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwic2VhcmNoLTRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3aWRnZXQgd2lkZ2V0X3NlYXJjaCBwb3N0c19ob2xkZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJvbGU9XCJzZWFyY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwic2VhcmNoZm9ybVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2VhcmNoZm9ybVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25TdWJtaXQ9e3RoaXMub25TdWJtaXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImJsb2ctc2VhcmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwbGFjZWhvbGRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLnNlYXJjaF92YWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBuYW1lPVwic2VhcmNoLXN1Ym1pdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZhIGZhLXNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCbG9nUmVjZW50UG9zdHM+PC9CbG9nUmVjZW50UG9zdHM+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QmxvZ0NhdGVnb3JpZXM+PC9CbG9nQ2F0ZWdvcmllcz5cclxuICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vYi12aXNpYmxlXCI+PC9kaXY+XHJcbiAgICAgICAgPEZvb3Rlcj48L0Zvb3Rlcj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9