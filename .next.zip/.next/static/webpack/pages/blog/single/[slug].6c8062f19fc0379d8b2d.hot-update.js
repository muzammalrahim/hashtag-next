self["webpackHotUpdate_N_E"]("pages/blog/single/[slug]",{

/***/ "./pages/blog/single/[slug].jsx":
/*!**************************************!*\
  !*** ./pages/blog/single/[slug].jsx ***!
  \**************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Singlepost; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_header_index_jsx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../components/header/index.jsx */ "./components/header/index.jsx");
/* harmony import */ var _components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/footer/index.jsx */ "./components/footer/index.jsx");
/* harmony import */ var _components_under_construction_index_jsx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/under-construction/index.jsx */ "./components/under-construction/index.jsx");
/* harmony import */ var _components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/post-category/index.jsx */ "./components/post-category/index.jsx");
/* harmony import */ var _components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../components/post-recent/index.jsx */ "./components/post-recent/index.jsx");
/* harmony import */ var react_document_meta__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react-document-meta */ "./node_modules/react-document-meta/dist/index.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../config */ "./config.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_19__);
/* module decorator */ module = __webpack_require__.hmd(module);









var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\pages\\blog\\single\\[slug].jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }















__webpack_require__(/*! typeface-montserrat */ "./node_modules/typeface-montserrat/index.css");

var __N_SSP = true;

var Singlepost = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__.default)(Singlepost, _Component);

  var _super = _createSuper(Singlepost);

  function Singlepost(props) {
    var _this$props, _this$props$match, _this$props$match$par;

    var _this;

    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__.default)(this, Singlepost);

    _this = _super.call(this, props);

    if (false) {}

    var response = _this.props;
    _this.state = {
      data: response.data.data,
      postData: {
        categories: [{
          name: "",
          slug: ""
        }]
      },
      postUrl: (_this$props = _this.props) === null || _this$props === void 0 ? void 0 : (_this$props$match = _this$props.match) === null || _this$props$match === void 0 ? void 0 : (_this$props$match$par = _this$props$match.params) === null || _this$props$match$par === void 0 ? void 0 : _this$props$match$par.slug,
      loader: true
    };
    _this.shiftContent = _this.shiftContent.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__.default)(_this));
    return _this;
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__.default)(Singlepost, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.shiftContent();

      if (true) {
        window.addEventListener("resize", this.shiftContent);
      }

      if (window.location.pathname) {
        var pathNames = window.location.pathname.split("/");
        console.log("path", pathNames);
        var singlePost = pathNames[3];
        this.setState({
          postUrl: singlePost
        });
        this.get_postData(singlePost);
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (true) {
        window.removeEventListener("resize", this.shiftContent);
      }
    } //Search div shift

  }, {
    key: "shiftContent",
    value: function shiftContent() {
      if (jquery__WEBPACK_IMPORTED_MODULE_16___default()(".mob-visible").is(":visible")) {
        jquery__WEBPACK_IMPORTED_MODULE_16___default()(".widget_search").insertBefore(jquery__WEBPACK_IMPORTED_MODULE_16___default()(".blog-list"));
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_16___default()(".widget_search").insertBefore(jquery__WEBPACK_IMPORTED_MODULE_16___default()(".widget_recent_entries"));
      }
    } //Get post data

  }, {
    key: "get_postData",
    value: function get_postData(singlePost) {
      var _this2 = this;

      var postUrl = singlePost;
      axios__WEBPACK_IMPORTED_MODULE_17___default().get(_config__WEBPACK_IMPORTED_MODULE_18__.myConfig.apiUrl + "blog/posts/single", {
        params: {
          post_url: postUrl
        }
      }).then(function (response) {
        // console.log(response.data);
        var postData = response.data.data;

        _this2.setState({
          postData: postData,
          loader: false
        });
      })["catch"](function (error) {
        console.log(error.response);
        react_toastify__WEBPACK_IMPORTED_MODULE_20__.toast.error("Something went wrong.");
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _postData$categories,
          _this3 = this;

      var meta = {
        title: "Blogs - FullStack Web Development| Bay area, California",
        meta: {
          charset: "utf-8",
          name: {
            keywords: "Web development company,software development company,web development kochi,web development company kochi,software development kochi,web development company kochi,software development kochi,web design and development kochi,full stack development company,wordpress customisation company kerala,shopify theme development company kerala,ecommerce development company kerala,woocommerce development company kerala,web development company California,software development california,wordpress development california,wordpress development kochi,shopify development kochi,shopify development california,wordpress customisation company,shopify theme development company,ecommerce development company kochi,ecommerce development company california"
          }
        }
      };

      var loader = /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "loader",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "spinner",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 126,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 127,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 128,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 129,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 125,
          columnNumber: 9
        }, this), "Loading"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 124,
        columnNumber: 7
      }, this);

      var _this$state = this.state,
          postData = _this$state.postData,
          data = _this$state.data; //console.log(data)

      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "single-blog-main",
        id: "single-blog-main",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_document_meta__WEBPACK_IMPORTED_MODULE_14__.default, _objectSpread({}, meta), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 138,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_header_index_jsx__WEBPACK_IMPORTED_MODULE_9__.default, {
          title: data.title,
          description: data.description,
          keywords: data.keywords
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 139,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
          "class": "content-container",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "container-fluid service-bg p-0 m-0 ",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "service-bg-right",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "service-banner-frame",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "container ",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "row justify-content-center service-banner-content pl-3 pr-3",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                        className: "breadcrumbs",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_19___default()), {
                            href: "/blog",
                            children: "Blogs"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 154,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 153,
                          columnNumber: 25
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: postData.title
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 156,
                          columnNumber: 25
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 152,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 151,
                      columnNumber: 21
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12 text-white  ",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                        className: "bold-contents service-content-box pl-4",
                        children: "We are seeking brilliant minds to join our dynamic team and make it even better."
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 160,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 159,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 150,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 149,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 148,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 147,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 146,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "blog-section",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "container",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "row b-row-1",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-8 col-lg-8",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-wrap",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "blog-list",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "card",
                        children: this.state.loader == true ? loader : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h5", {
                            className: "card-title text-level-4 title-orange",
                            children: postData.title
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 182,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-meta",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                              children: [postData.published != null && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-clock-o",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 189,
                                  columnNumber: 37
                                }, this), " ", postData.published]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 188,
                                columnNumber: 35
                              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-th-large",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 197,
                                  columnNumber: 35
                                }, this), postData === null || postData === void 0 ? void 0 : (_postData$categories = postData.categories) === null || _postData$categories === void 0 ? void 0 : _postData$categories.map(function (cat, i) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                    children: [cat.name, " ", i < postData.categories.length - 1 ? ", " : ""]
                                  }, i, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 203,
                                    columnNumber: 39
                                  }, _this3);
                                })]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 196,
                                columnNumber: 33
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 186,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 185,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-img",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "blog-thumb",
                              style: {
                                backgroundImage: postData.image == null ? "/images/blogs/writing-good-blog.jpg" : "url(".concat(postData.image, ")")
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 215,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 214,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "card-body",
                            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("small", {
                              className: "text-muted cat text-above-main-title",
                              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                className: "fas fa-users text-info"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 228,
                                columnNumber: 33
                              }, this), " ", "Hashtag systems"]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 227,
                              columnNumber: 31
                            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "card-text blog-detail-page",
                              dangerouslySetInnerHTML: {
                                __html: postData.content
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 231,
                              columnNumber: 31
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 226,
                            columnNumber: 29
                          }, this)]
                        }, void 0, true)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 177,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 176,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 175,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 174,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-4 col-lg-4",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-sidebar",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("aside", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_13__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 252,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 253,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 251,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 250,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 249,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 173,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 172,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 171,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 145,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "mob-visible"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 261,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_10__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 262,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 137,
        columnNumber: 7
      }, this);
    }
  }]);

  return Singlepost;
}(react__WEBPACK_IMPORTED_MODULE_8__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYmxvZy9zaW5nbGUvW3NsdWddLmpzeCJdLCJuYW1lcyI6WyJyZXF1aXJlIiwiU2luZ2xlcG9zdCIsInByb3BzIiwicmVzcG9uc2UiLCJzdGF0ZSIsImRhdGEiLCJwb3N0RGF0YSIsImNhdGVnb3JpZXMiLCJuYW1lIiwic2x1ZyIsInBvc3RVcmwiLCJtYXRjaCIsInBhcmFtcyIsImxvYWRlciIsInNoaWZ0Q29udGVudCIsImJpbmQiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwibG9jYXRpb24iLCJwYXRobmFtZSIsInBhdGhOYW1lcyIsInNwbGl0IiwiY29uc29sZSIsImxvZyIsInNpbmdsZVBvc3QiLCJzZXRTdGF0ZSIsImdldF9wb3N0RGF0YSIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCIkIiwiaXMiLCJpbnNlcnRCZWZvcmUiLCJBeGlvcyIsImNvbmZpZyIsInBvc3RfdXJsIiwidGhlbiIsImVycm9yIiwidG9hc3QiLCJtZXRhIiwidGl0bGUiLCJjaGFyc2V0Iiwia2V5d29yZHMiLCJkZXNjcmlwdGlvbiIsInB1Ymxpc2hlZCIsIm1hcCIsImNhdCIsImkiLCJsZW5ndGgiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJpbWFnZSIsIl9faHRtbCIsImNvbnRlbnQiLCJDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQUEsbUJBQU8sQ0FBQyx5RUFBRCxDQUFQOzs7O0lBMEJxQkMsVTs7Ozs7QUFDbkIsc0JBQVlDLEtBQVosRUFBbUI7QUFBQTs7QUFBQTs7QUFBQTs7QUFDakIsOEJBQU1BLEtBQU47O0FBQ0EsZUFBbUMsRUFFbEM7O0FBQ0QsUUFBSUMsUUFBUSxHQUFHLE1BQUtELEtBQXBCO0FBQ0EsVUFBS0UsS0FBTCxHQUFhO0FBQ1hDLFVBQUksRUFBRUYsUUFBUSxDQUFDRSxJQUFULENBQWNBLElBRFQ7QUFFWEMsY0FBUSxFQUFFO0FBQ1JDLGtCQUFVLEVBQUUsQ0FBQztBQUFFQyxjQUFJLEVBQUUsRUFBUjtBQUFZQyxjQUFJLEVBQUU7QUFBbEIsU0FBRDtBQURKLE9BRkM7QUFLWEMsYUFBTyxpQkFBRSxNQUFLUixLQUFQLHFFQUFFLFlBQVlTLEtBQWQsK0VBQUUsa0JBQW1CQyxNQUFyQiwwREFBRSxzQkFBMkJILElBTHpCO0FBTVhJLFlBQU0sRUFBRTtBQU5HLEtBQWI7QUFTQSxVQUFLQyxZQUFMLEdBQW9CLE1BQUtBLFlBQUwsQ0FBa0JDLElBQWxCLHlJQUFwQjtBQWZpQjtBQWdCbEI7Ozs7d0NBRW1CO0FBQ2xCLFdBQUtELFlBQUw7O0FBQ0EsZ0JBQWlDO0FBQy9CRSxjQUFNLENBQUNDLGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDLEtBQUtILFlBQXZDO0FBQ0Q7O0FBQ0QsVUFBSUUsTUFBTSxDQUFDRSxRQUFQLENBQWdCQyxRQUFwQixFQUE4QjtBQUM1QixZQUFJQyxTQUFTLEdBQUdKLE1BQU0sQ0FBQ0UsUUFBUCxDQUFnQkMsUUFBaEIsQ0FBeUJFLEtBQXpCLENBQStCLEdBQS9CLENBQWhCO0FBQ0FDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBb0JILFNBQXBCO0FBQ0EsWUFBSUksVUFBVSxHQUFHSixTQUFTLENBQUMsQ0FBRCxDQUExQjtBQUNBLGFBQUtLLFFBQUwsQ0FBYztBQUFFZixpQkFBTyxFQUFFYztBQUFYLFNBQWQ7QUFDQSxhQUFLRSxZQUFMLENBQWtCRixVQUFsQjtBQUNEO0FBRUY7OzsyQ0FFc0I7QUFDckIsZ0JBQWlDO0FBQy9CUixjQUFNLENBQUNXLG1CQUFQLENBQTJCLFFBQTNCLEVBQXFDLEtBQUtiLFlBQTFDO0FBQ0Q7QUFDRixLLENBRUQ7Ozs7bUNBQ2U7QUFDYixVQUFJYyw4Q0FBQyxDQUFDLGNBQUQsQ0FBRCxDQUFrQkMsRUFBbEIsQ0FBcUIsVUFBckIsQ0FBSixFQUFzQztBQUNwQ0Qsc0RBQUMsQ0FBQyxnQkFBRCxDQUFELENBQW9CRSxZQUFwQixDQUFpQ0YsOENBQUMsQ0FBQyxZQUFELENBQWxDO0FBQ0QsT0FGRCxNQUVPO0FBQ0xBLHNEQUFDLENBQUMsZ0JBQUQsQ0FBRCxDQUFvQkUsWUFBcEIsQ0FBaUNGLDhDQUFDLENBQUMsd0JBQUQsQ0FBbEM7QUFDRDtBQUNGLEssQ0FFRDs7OztpQ0FDYUosVSxFQUFZO0FBQUE7O0FBQ3ZCLFVBQUlkLE9BQU8sR0FBR2MsVUFBZDtBQUNBTyx1REFBQSxDQUFVQyxxREFBQSxHQUF5QixtQkFBbkMsRUFBd0Q7QUFDdERwQixjQUFNLEVBQUU7QUFBRXFCLGtCQUFRLEVBQUV2QjtBQUFaO0FBRDhDLE9BQXhELEVBR0d3QixJQUhILENBR1EsVUFBQy9CLFFBQUQsRUFBYztBQUNsQjtBQUNBLFlBQU1HLFFBQVEsR0FBR0gsUUFBUSxDQUFDRSxJQUFULENBQWNBLElBQS9COztBQUNBLGNBQUksQ0FBQ29CLFFBQUwsQ0FBYztBQUNabkIsa0JBQVEsRUFBRUEsUUFERTtBQUVaTyxnQkFBTSxFQUFFO0FBRkksU0FBZDtBQUlELE9BVkgsV0FXUyxVQUFDc0IsS0FBRCxFQUFXO0FBQ2hCYixlQUFPLENBQUNDLEdBQVIsQ0FBWVksS0FBSyxDQUFDaEMsUUFBbEI7QUFDQWlDLGdFQUFBLENBQVksdUJBQVo7QUFDRCxPQWRIO0FBZUQ7Ozs2QkFFUTtBQUFBO0FBQUE7O0FBQ1AsVUFBTUMsSUFBSSxHQUFHO0FBQ1hDLGFBQUssRUFBRSx5REFESTtBQUVYRCxZQUFJLEVBQUU7QUFDSkUsaUJBQU8sRUFBRSxPQURMO0FBRUovQixjQUFJLEVBQUU7QUFDSmdDLG9CQUFRLEVBQ047QUFGRTtBQUZGO0FBRkssT0FBYjs7QUFXQSxVQUFNM0IsTUFBTSxnQkFDVjtBQUFLLGlCQUFTLEVBQUMsUUFBZjtBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBQyxTQUFmO0FBQUEsa0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUhGLGVBSUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREY7O0FBWk8sd0JBdUJrQixLQUFLVCxLQXZCdkI7QUFBQSxVQXVCREUsUUF2QkMsZUF1QkRBLFFBdkJDO0FBQUEsVUF1QlNELElBdkJULGVBdUJTQSxJQXZCVCxFQXdCUDs7QUFDQSwwQkFDRTtBQUFLLGlCQUFTLEVBQUMsa0JBQWY7QUFBa0MsVUFBRSxFQUFDLGtCQUFyQztBQUFBLGdDQUNFLDhEQUFDLHlEQUFELG9CQUFrQmdDLElBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFFRSw4REFBQyxpRUFBRDtBQUNFLGVBQUssRUFBRWhDLElBQUksQ0FBQ2lDLEtBRGQ7QUFFRSxxQkFBVyxFQUFFakMsSUFBSSxDQUFDb0MsV0FGcEI7QUFHRSxrQkFBUSxFQUFFcEMsSUFBSSxDQUFDbUM7QUFIakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRixlQVFFO0FBQVMsbUJBQU0sbUJBQWY7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMscUNBQWY7QUFBQSxtQ0FDRTtBQUFLLHVCQUFTLEVBQUMsa0JBQWY7QUFBQSxxQ0FDRTtBQUFLLHlCQUFTLEVBQUMsc0JBQWY7QUFBQSx1Q0FDRTtBQUFLLDJCQUFTLEVBQUMsWUFBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyw2REFBZjtBQUFBLDRDQUNFO0FBQUssK0JBQVMsRUFBQyxvQkFBZjtBQUFBLDZDQUNFO0FBQUksaUNBQVMsRUFBQyxhQUFkO0FBQUEsZ0RBQ0U7QUFBQSxpREFDRSw4REFBQyxtREFBRDtBQUFNLGdDQUFJLEVBQUMsT0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBREYsZUFJRTtBQUFBLG9DQUFLbEMsUUFBUSxDQUFDZ0M7QUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBREYsZUFTRTtBQUFLLCtCQUFTLEVBQUMsaUNBQWY7QUFBQSw2Q0FDRTtBQUFHLGlDQUFTLEVBQUMsd0NBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUEwQkU7QUFBSyxxQkFBUyxFQUFDLGNBQWY7QUFBQSxtQ0FDRTtBQUFLLHVCQUFTLEVBQUMsV0FBZjtBQUFBLHFDQUNFO0FBQUsseUJBQVMsRUFBQyxhQUFmO0FBQUEsd0NBQ0U7QUFBSywyQkFBUyxFQUFDLG9DQUFmO0FBQUEseUNBQ0U7QUFBSyw2QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FDRTtBQUFLLCtCQUFTLEVBQUMsV0FBZjtBQUFBLDZDQUNFO0FBQUssaUNBQVMsRUFBQyxNQUFmO0FBQUEsa0NBQ0csS0FBS2xDLEtBQUwsQ0FBV1MsTUFBWCxJQUFxQixJQUFyQixHQUNDQSxNQURELGdCQUdDO0FBQUEsa0RBQ0U7QUFBSSxxQ0FBUyxFQUFDLHNDQUFkO0FBQUEsc0NBQ0dQLFFBQVEsQ0FBQ2dDO0FBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FERixlQUlFO0FBQUsscUNBQVMsRUFBQyxXQUFmO0FBQUEsbURBQ0U7QUFBQSx5Q0FDR2hDLFFBQVEsQ0FBQ29DLFNBQVQsSUFBc0IsSUFBdEIsaUJBQ0M7QUFBQSx3REFDRTtBQUNFLDJDQUFTLEVBQUMsZUFEWjtBQUVFLGlEQUFZO0FBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx3Q0FERixFQUlRLEdBSlIsRUFLR3BDLFFBQVEsQ0FBQ29DLFNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNDQUZKLGVBVUU7QUFBQSx3REFDRTtBQUNFLDJDQUFTLEVBQUMsZ0JBRFo7QUFFRSxpREFBWTtBQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0NBREYsRUFLR3BDLFFBTEgsYUFLR0EsUUFMSCwrQ0FLR0EsUUFBUSxDQUFFQyxVQUxiLHlEQUtHLHFCQUFzQm9DLEdBQXRCLENBQTBCLFVBQUNDLEdBQUQsRUFBTUMsQ0FBTixFQUFZO0FBQ3JDLHNEQUNFO0FBQUEsK0NBQ0dELEdBQUcsQ0FBQ3BDLElBRFAsRUFDYSxHQURiLEVBRUdxQyxDQUFDLEdBQUd2QyxRQUFRLENBQUNDLFVBQVQsQ0FBb0J1QyxNQUFwQixHQUE2QixDQUFqQyxHQUNHLElBREgsR0FFRyxFQUpOO0FBQUEscUNBQVdELENBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSw0Q0FERjtBQVFELGlDQVRBLENBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNDQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBSkYsZUFpQ0U7QUFBSyxxQ0FBUyxFQUFDLFVBQWY7QUFBQSxtREFDRTtBQUNFLHVDQUFTLEVBQUMsWUFEWjtBQUVFLG1DQUFLLEVBQUU7QUFDTEUsK0NBQWUsRUFDYnpDLFFBQVEsQ0FBQzBDLEtBQVQsSUFBa0IsSUFBbEIsR0FDSSxxQ0FESixpQkFFVzFDLFFBQVEsQ0FBQzBDLEtBRnBCO0FBRkc7QUFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FqQ0YsZUE2Q0U7QUFBSyxxQ0FBUyxFQUFDLFdBQWY7QUFBQSxvREFDRTtBQUFPLHVDQUFTLEVBQUMsc0NBQWpCO0FBQUEsc0RBQ0U7QUFBRyx5Q0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQ0FERixFQUM2QyxHQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBREYsZUFLRTtBQUNFLHVDQUFTLEVBQUMsNEJBRFo7QUFFRSxxREFBdUIsRUFBRTtBQUN2QkMsc0NBQU0sRUFBRTNDLFFBQVEsQ0FBQzRDO0FBRE07QUFGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBN0NGO0FBQUE7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBNEVFO0FBQUssMkJBQVMsRUFBQyxvQ0FBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxjQUFmO0FBQUEsMkNBQ0U7QUFBQSw4Q0FDRSw4REFBQyx1RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURGLGVBRUUsOERBQUMseUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkE1RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFSRixlQTRIRTtBQUFLLG1CQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTVIRixlQTZIRSw4REFBQyxrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTdIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERjtBQWlJRDs7OztFQS9OcUNDLDRDIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2Jsb2cvc2luZ2xlL1tzbHVnXS42YzgwNjJmMTlmYzAzNzlkOGIyZC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEhlYWRlciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2hlYWRlci9pbmRleC5qc3gnO1xyXG5pbXBvcnQgRm9vdGVyIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvZm9vdGVyL2luZGV4LmpzeCc7XHJcbmltcG9ydCBVbmRlcmNvbnN0cnVjdGlvbiBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VuZGVyLWNvbnN0cnVjdGlvbi9pbmRleC5qc3gnO1xyXG5pbXBvcnQgQmxvZ0NhdGVnb3JpZXMgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9wb3N0LWNhdGVnb3J5L2luZGV4LmpzeCc7XHJcbmltcG9ydCBCbG9nUmVjZW50UG9zdHMgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9wb3N0LXJlY2VudC9pbmRleC5qc3gnO1xyXG5pbXBvcnQgRG9jdW1lbnRNZXRhIGZyb20gJ3JlYWN0LWRvY3VtZW50LW1ldGEnO1xyXG5pbXBvcnQgeyBUb2FzdENvbnRhaW5lciwgdG9hc3QsIFNsaWRlIH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xyXG5pbXBvcnQgJ3JlYWN0LXRvYXN0aWZ5L2Rpc3QvUmVhY3RUb2FzdGlmeS5jc3MnO1xyXG5pbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5pbXBvcnQgQXhpb3MgZnJvbSAnYXhpb3MnO1xyXG5pbXBvcnQgaHR0cHMgZnJvbSBcImh0dHBzXCI7XHJcbmltcG9ydCAqIGFzIGNvbmZpZyBmcm9tICcuLi8uLi8uLi9jb25maWcnO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcblxyXG5yZXF1aXJlKCd0eXBlZmFjZS1tb250c2VycmF0JylcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoKSB7XHJcbiAgbGV0IGRhdGEgPSBbXTtcclxuXHJcbiAgY29uc3QgaW5zdGFuY2UgPSBBeGlvcy5jcmVhdGUoe1xyXG4gICAgaHR0cHNBZ2VudDogbmV3IGh0dHBzLkFnZW50KHtcclxuICAgICAgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZSxcclxuICAgIH0pLFxyXG4gIH0pO1xyXG5cclxuICBhd2FpdCBpbnN0YW5jZVxyXG4gICAgLmdldChcImh0dHBzOi8vYXBpLmhhc2h0YWctY2EuY29tL2FwaS92MS9tZXRhZGF0YVwiLCB7XHJcbiAgICAgIHBhcmFtczoge1xyXG4gICAgICAgIHBhZ2VfdHlwZTogXCJzdGF0aWNcIixcclxuICAgICAgICBzbHVnOiBcInNldmljZXNcIixcclxuICAgICAgfSxcclxuICAgIH0pXHJcbiAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgZGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgICB9KTtcclxuICByZXR1cm4ge1xyXG4gICAgcHJvcHM6IHsgZGF0YSB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNpbmdsZXBvc3QgZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gIGNvbnN0cnVjdG9yKHByb3BzKSB7XHJcbiAgICBzdXBlcihwcm9wcyk7XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICBnbG9iYWwud2luZG93ID0ge307XHJcbiAgICB9XHJcbiAgICBsZXQgcmVzcG9uc2UgPSB0aGlzLnByb3BzO1xyXG4gICAgdGhpcy5zdGF0ZSA9IHtcclxuICAgICAgZGF0YTogcmVzcG9uc2UuZGF0YS5kYXRhLFxyXG4gICAgICBwb3N0RGF0YToge1xyXG4gICAgICAgIGNhdGVnb3JpZXM6IFt7IG5hbWU6IFwiXCIsIHNsdWc6IFwiXCIgfV0sXHJcbiAgICAgIH0sXHJcbiAgICAgIHBvc3RVcmw6IHRoaXMucHJvcHM/Lm1hdGNoPy5wYXJhbXM/LnNsdWcsXHJcbiAgICAgIGxvYWRlcjogdHJ1ZSxcclxuICAgIH07XHJcblxyXG4gICAgdGhpcy5zaGlmdENvbnRlbnQgPSB0aGlzLnNoaWZ0Q29udGVudC5iaW5kKHRoaXMpO1xyXG4gIH1cclxuXHJcbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XHJcbiAgICB0aGlzLnNoaWZ0Q29udGVudCgpO1xyXG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCB0aGlzLnNoaWZ0Q29udGVudCk7XHJcbiAgICB9XHJcbiAgICBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lKSB7XHJcbiAgICAgIGxldCBwYXRoTmFtZXMgPSB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUuc3BsaXQoXCIvXCIpO1xyXG4gICAgICBjb25zb2xlLmxvZyhcInBhdGhcIiwgcGF0aE5hbWVzKTtcclxuICAgICAgbGV0IHNpbmdsZVBvc3QgPSBwYXRoTmFtZXNbM107XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyBwb3N0VXJsOiBzaW5nbGVQb3N0IH0pO1xyXG4gICAgICB0aGlzLmdldF9wb3N0RGF0YShzaW5nbGVQb3N0KTtcclxuICAgIH1cclxuICAgIFxyXG4gIH1cclxuXHJcbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHRoaXMuc2hpZnRDb250ZW50KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vU2VhcmNoIGRpdiBzaGlmdFxyXG4gIHNoaWZ0Q29udGVudCgpIHtcclxuICAgIGlmICgkKFwiLm1vYi12aXNpYmxlXCIpLmlzKFwiOnZpc2libGVcIikpIHtcclxuICAgICAgJChcIi53aWRnZXRfc2VhcmNoXCIpLmluc2VydEJlZm9yZSgkKFwiLmJsb2ctbGlzdFwiKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAkKFwiLndpZGdldF9zZWFyY2hcIikuaW5zZXJ0QmVmb3JlKCQoXCIud2lkZ2V0X3JlY2VudF9lbnRyaWVzXCIpKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vR2V0IHBvc3QgZGF0YVxyXG4gIGdldF9wb3N0RGF0YShzaW5nbGVQb3N0KSB7XHJcbiAgICBsZXQgcG9zdFVybCA9IHNpbmdsZVBvc3Q7XHJcbiAgICBBeGlvcy5nZXQoY29uZmlnLm15Q29uZmlnLmFwaVVybCArIFwiYmxvZy9wb3N0cy9zaW5nbGVcIiwge1xyXG4gICAgICBwYXJhbXM6IHsgcG9zdF91cmw6IHBvc3RVcmwgfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIGNvbnN0IHBvc3REYXRhID0gcmVzcG9uc2UuZGF0YS5kYXRhO1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgcG9zdERhdGE6IHBvc3REYXRhLFxyXG4gICAgICAgICAgbG9hZGVyOiBmYWxzZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yLnJlc3BvbnNlKTtcclxuICAgICAgICB0b2FzdC5lcnJvcihcIlNvbWV0aGluZyB3ZW50IHdyb25nLlwiKTtcclxuICAgICAgfSk7XHJcbiAgfVxyXG5cclxuICByZW5kZXIoKSB7XHJcbiAgICBjb25zdCBtZXRhID0ge1xyXG4gICAgICB0aXRsZTogXCJCbG9ncyAtIEZ1bGxTdGFjayBXZWIgRGV2ZWxvcG1lbnR8IEJheSBhcmVhLCBDYWxpZm9ybmlhXCIsXHJcbiAgICAgIG1ldGE6IHtcclxuICAgICAgICBjaGFyc2V0OiBcInV0Zi04XCIsXHJcbiAgICAgICAgbmFtZToge1xyXG4gICAgICAgICAga2V5d29yZHM6XHJcbiAgICAgICAgICAgIFwiV2ViIGRldmVsb3BtZW50IGNvbXBhbnksc29mdHdhcmUgZGV2ZWxvcG1lbnQgY29tcGFueSx3ZWIgZGV2ZWxvcG1lbnQga29jaGksd2ViIGRldmVsb3BtZW50IGNvbXBhbnkga29jaGksc29mdHdhcmUgZGV2ZWxvcG1lbnQga29jaGksd2ViIGRldmVsb3BtZW50IGNvbXBhbnkga29jaGksc29mdHdhcmUgZGV2ZWxvcG1lbnQga29jaGksd2ViIGRlc2lnbiBhbmQgZGV2ZWxvcG1lbnQga29jaGksZnVsbCBzdGFjayBkZXZlbG9wbWVudCBjb21wYW55LHdvcmRwcmVzcyBjdXN0b21pc2F0aW9uIGNvbXBhbnkga2VyYWxhLHNob3BpZnkgdGhlbWUgZGV2ZWxvcG1lbnQgY29tcGFueSBrZXJhbGEsZWNvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkga2VyYWxhLHdvb2NvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkga2VyYWxhLHdlYiBkZXZlbG9wbWVudCBjb21wYW55IENhbGlmb3JuaWEsc29mdHdhcmUgZGV2ZWxvcG1lbnQgY2FsaWZvcm5pYSx3b3JkcHJlc3MgZGV2ZWxvcG1lbnQgY2FsaWZvcm5pYSx3b3JkcHJlc3MgZGV2ZWxvcG1lbnQga29jaGksc2hvcGlmeSBkZXZlbG9wbWVudCBrb2NoaSxzaG9waWZ5IGRldmVsb3BtZW50IGNhbGlmb3JuaWEsd29yZHByZXNzIGN1c3RvbWlzYXRpb24gY29tcGFueSxzaG9waWZ5IHRoZW1lIGRldmVsb3BtZW50IGNvbXBhbnksZWNvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkga29jaGksZWNvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkgY2FsaWZvcm5pYVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGxvYWRlciA9IChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2FkZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwaW5uZXJcIj5cclxuICAgICAgICAgIDxkaXY+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PjwvZGl2PlxyXG4gICAgICAgICAgPGRpdj48L2Rpdj5cclxuICAgICAgICAgIDxkaXY+PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgTG9hZGluZ1xyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgICBsZXQgeyBwb3N0RGF0YSwgZGF0YSB9ID0gdGhpcy5zdGF0ZTtcclxuICAgIC8vY29uc29sZS5sb2coZGF0YSlcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2luZ2xlLWJsb2ctbWFpblwiIGlkPVwic2luZ2xlLWJsb2ctbWFpblwiPlxyXG4gICAgICAgIDxEb2N1bWVudE1ldGEgey4uLm1ldGF9IC8+XHJcbiAgICAgICAgPEhlYWRlclxyXG4gICAgICAgICAgdGl0bGU9e2RhdGEudGl0bGV9XHJcbiAgICAgICAgICBkZXNjcmlwdGlvbj17ZGF0YS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgIGtleXdvcmRzPXtkYXRhLmtleXdvcmRzfVxyXG4gICAgICAgID48L0hlYWRlcj5cclxuXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3M9XCJjb250ZW50LWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItZmx1aWQgc2VydmljZS1iZyBwLTAgbS0wIFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmctcmlnaHRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmFubmVyLWZyYW1lXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cganVzdGlmeS1jb250ZW50LWNlbnRlciBzZXJ2aWNlLWJhbm5lci1jb250ZW50IHBsLTMgcHItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiYnJlYWRjcnVtYnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYmxvZ1wiPkJsb2dzPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGk+e3Bvc3REYXRhLnRpdGxlfTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyIHRleHQtd2hpdGUgIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYm9sZC1jb250ZW50cyBzZXJ2aWNlLWNvbnRlbnQtYm94IHBsLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgV2UgYXJlIHNlZWtpbmcgYnJpbGxpYW50IG1pbmRzIHRvIGpvaW4gb3VyIGR5bmFtaWMgdGVhbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmQgbWFrZSBpdCBldmVuIGJldHRlci5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGItcm93LTFcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1zbS0xMiBjb2wtbWQtOCBjb2wtbGctOFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3RoaXMuc3RhdGUubG9hZGVyID09IHRydWUgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJjYXJkLXRpdGxlIHRleHQtbGV2ZWwtNCB0aXRsZS1vcmFuZ2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Bvc3REYXRhLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oNT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx1bD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cG9zdERhdGEucHVibGlzaGVkICE9IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZhIGZhLWNsb2NrLW9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2k+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cG9zdERhdGEucHVibGlzaGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZhIGZhLXRoLWxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cG9zdERhdGE/LmNhdGVnb3JpZXM/Lm1hcCgoY2F0LCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXQubmFtZX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aSA8IHBvc3REYXRhLmNhdGVnb3JpZXMubGVuZ3RoIC0gMVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiLCBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWltZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvZy10aHVtYlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRJbWFnZTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zdERhdGEuaW1hZ2UgPT0gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCIvaW1hZ2VzL2Jsb2dzL3dyaXRpbmctZ29vZC1ibG9nLmpwZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBgdXJsKCR7cG9zdERhdGEuaW1hZ2V9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyp7IChwb3N0RGF0YS5pbWFnZSA9PSBudWxsKSA/IDxpbWcgc3JjPVwiL2ltYWdlcy9ibG9ncy93cml0aW5nLWdvb2QtYmxvZy5qcGdcIiBhbHQ9e3Bvc3REYXRhLmltYWdlX2FsdH0gLz4gOiA8aW1nIHNyYz17cG9zdERhdGEuaW1hZ2V9IGFsdD17cG9zdERhdGEuaW1hZ2VfYWx0fSAvPiB9Ki99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzbWFsbCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkIGNhdCB0ZXh0LWFib3ZlLW1haW4tdGl0bGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdXNlcnMgdGV4dC1pbmZvXCI+PC9pPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBIYXNodGFnIHN5c3RlbXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhcmQtdGV4dCBibG9nLWRldGFpbC1wYWdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX19odG1sOiBwb3N0RGF0YS5jb250ZW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qPGRpdiBjbGFzc05hbWU9XCJibG9nLW5hdlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJwcmV2XCI+PGkgY2xhc3NOYW1lPVwiZmEgZmEtYW5nbGUtbGVmdFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT5QcmV2PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJuZXh0XCI+TmV4dDxpIGNsYXNzTmFtZT1cImZhIGZhLWFuZ2xlLXJpZ2h0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPjwvYT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj4qL31cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtc20tMTIgY29sLW1kLTQgY29sLWxnLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXNpZGViYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QmxvZ1JlY2VudFBvc3RzPjwvQmxvZ1JlY2VudFBvc3RzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJsb2dDYXRlZ29yaWVzPjwvQmxvZ0NhdGVnb3JpZXM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2ItdmlzaWJsZVwiPjwvZGl2PlxyXG4gICAgICAgIDxGb290ZXI+PC9Gb290ZXI+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==