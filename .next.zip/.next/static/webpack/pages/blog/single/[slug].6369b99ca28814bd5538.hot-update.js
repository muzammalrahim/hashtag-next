self["webpackHotUpdate_N_E"]("pages/blog/single/[slug]",{

/***/ "./pages/blog/single/[slug].jsx":
/*!**************************************!*\
  !*** ./pages/blog/single/[slug].jsx ***!
  \**************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Singlepost; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_header_index_jsx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../components/header/index.jsx */ "./components/header/index.jsx");
/* harmony import */ var _components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/footer/index.jsx */ "./components/footer/index.jsx");
/* harmony import */ var _components_under_construction_index_jsx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/under-construction/index.jsx */ "./components/under-construction/index.jsx");
/* harmony import */ var _components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/post-category/index.jsx */ "./components/post-category/index.jsx");
/* harmony import */ var _components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../components/post-recent/index.jsx */ "./components/post-recent/index.jsx");
/* harmony import */ var react_document_meta__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react-document-meta */ "./node_modules/react-document-meta/dist/index.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../config */ "./config.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_19__);
/* module decorator */ module = __webpack_require__.hmd(module);









var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\pages\\blog\\single\\[slug].jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }















__webpack_require__(/*! typeface-montserrat */ "./node_modules/typeface-montserrat/index.css");

var __N_SSP = true;

var Singlepost = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__.default)(Singlepost, _Component);

  var _super = _createSuper(Singlepost);

  function Singlepost(props) {
    var _this$props, _this$props$match, _this$props$match$par;

    var _this;

    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__.default)(this, Singlepost);

    _this = _super.call(this, props);

    if (false) {}

    var response = _this.props;
    _this.state = {
      data: response.data.data,
      postData: {
        categories: [{
          name: "",
          slug: ""
        }]
      },
      postUrl: (_this$props = _this.props) === null || _this$props === void 0 ? void 0 : (_this$props$match = _this$props.match) === null || _this$props$match === void 0 ? void 0 : (_this$props$match$par = _this$props$match.params) === null || _this$props$match$par === void 0 ? void 0 : _this$props$match$par.slug,
      loader: true
    };
    _this.shiftContent = _this.shiftContent.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__.default)(_this));
    return _this;
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__.default)(Singlepost, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.shiftContent();

      if (true) {
        window.addEventListener("resize", this.shiftContent);
      }

      if (window.location.pathname) {
        var pathNames = window.location.pathname.split("/");
        console.log("path", pathNames);
        var _singlePost = pathNames[3];
        this.setState({
          postUrl: _singlePost
        });
      }

      this.get_postData(singlePost);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (true) {
        window.removeEventListener("resize", this.shiftContent);
      }
    } //Search div shift

  }, {
    key: "shiftContent",
    value: function shiftContent() {
      if (jquery__WEBPACK_IMPORTED_MODULE_16___default()(".mob-visible").is(":visible")) {
        jquery__WEBPACK_IMPORTED_MODULE_16___default()(".widget_search").insertBefore(jquery__WEBPACK_IMPORTED_MODULE_16___default()(".blog-list"));
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_16___default()(".widget_search").insertBefore(jquery__WEBPACK_IMPORTED_MODULE_16___default()(".widget_recent_entries"));
      }
    } //Get post data

  }, {
    key: "get_postData",
    value: function get_postData(singlePost) {
      var _this2 = this;

      var postUrl = singlePost;
      axios__WEBPACK_IMPORTED_MODULE_17___default().get(_config__WEBPACK_IMPORTED_MODULE_18__.myConfig.apiUrl + "blog/posts/single", {
        params: {
          post_url: postUrl
        }
      }).then(function (response) {
        // console.log(response.data);
        var postData = response.data.data;

        _this2.setState({
          postData: postData,
          loader: false
        });
      })["catch"](function (error) {
        console.log(error.response);
        react_toastify__WEBPACK_IMPORTED_MODULE_20__.toast.error("Something went wrong.");
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _postData$categories,
          _this3 = this;

      var meta = {
        title: "Blogs - FullStack Web Development| Bay area, California",
        meta: {
          charset: "utf-8",
          name: {
            keywords: "Web development company,software development company,web development kochi,web development company kochi,software development kochi,web development company kochi,software development kochi,web design and development kochi,full stack development company,wordpress customisation company kerala,shopify theme development company kerala,ecommerce development company kerala,woocommerce development company kerala,web development company California,software development california,wordpress development california,wordpress development kochi,shopify development kochi,shopify development california,wordpress customisation company,shopify theme development company,ecommerce development company kochi,ecommerce development company california"
          }
        }
      };

      var loader = /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "loader",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "spinner",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 125,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 126,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 127,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 128,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 124,
          columnNumber: 9
        }, this), "Loading"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 123,
        columnNumber: 7
      }, this);

      var _this$state = this.state,
          postData = _this$state.postData,
          data = _this$state.data; //console.log(data)

      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "single-blog-main",
        id: "single-blog-main",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_document_meta__WEBPACK_IMPORTED_MODULE_14__.default, _objectSpread({}, meta), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 137,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_header_index_jsx__WEBPACK_IMPORTED_MODULE_9__.default, {
          title: data.title,
          description: data.description,
          keywords: data.keywords
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 138,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
          "class": "content-container",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "container-fluid service-bg p-0 m-0 ",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "service-bg-right",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "service-banner-frame",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "container ",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "row justify-content-center service-banner-content pl-3 pr-3",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                        className: "breadcrumbs",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_19___default()), {
                            href: "/blog",
                            children: "Blogs"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 153,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 152,
                          columnNumber: 25
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: postData.title
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 155,
                          columnNumber: 25
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 151,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 150,
                      columnNumber: 21
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12 text-white  ",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                        className: "bold-contents service-content-box pl-4",
                        children: "We are seeking brilliant minds to join our dynamic team and make it even better."
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 159,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 158,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 149,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 148,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 147,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 146,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 145,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "blog-section",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "container",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "row b-row-1",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-8 col-lg-8",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-wrap",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "blog-list",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "card",
                        children: this.state.loader == true ? loader : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h5", {
                            className: "card-title text-level-4 title-orange",
                            children: postData.title
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 181,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-meta",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                              children: [postData.published != null && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-clock-o",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 188,
                                  columnNumber: 37
                                }, this), " ", postData.published]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 187,
                                columnNumber: 35
                              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-th-large",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 196,
                                  columnNumber: 35
                                }, this), postData === null || postData === void 0 ? void 0 : (_postData$categories = postData.categories) === null || _postData$categories === void 0 ? void 0 : _postData$categories.map(function (cat, i) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                    children: [cat.name, " ", i < postData.categories.length - 1 ? ", " : ""]
                                  }, i, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 202,
                                    columnNumber: 39
                                  }, _this3);
                                })]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 195,
                                columnNumber: 33
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 185,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 184,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-img",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "blog-thumb",
                              style: {
                                backgroundImage: postData.image == null ? "/images/blogs/writing-good-blog.jpg" : "url(".concat(postData.image, ")")
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 214,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 213,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "card-body",
                            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("small", {
                              className: "text-muted cat text-above-main-title",
                              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                className: "fas fa-users text-info"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 227,
                                columnNumber: 33
                              }, this), " ", "Hashtag systems"]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 226,
                              columnNumber: 31
                            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "card-text blog-detail-page",
                              dangerouslySetInnerHTML: {
                                __html: postData.content
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 230,
                              columnNumber: 31
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 225,
                            columnNumber: 29
                          }, this)]
                        }, void 0, true)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 176,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 175,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 174,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 173,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-4 col-lg-4",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-sidebar",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("aside", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_13__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 251,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 252,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 250,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 249,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 248,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 172,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 171,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 170,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 144,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "mob-visible"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 260,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_10__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 261,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 136,
        columnNumber: 7
      }, this);
    }
  }]);

  return Singlepost;
}(react__WEBPACK_IMPORTED_MODULE_8__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYmxvZy9zaW5nbGUvW3NsdWddLmpzeCJdLCJuYW1lcyI6WyJyZXF1aXJlIiwiU2luZ2xlcG9zdCIsInByb3BzIiwicmVzcG9uc2UiLCJzdGF0ZSIsImRhdGEiLCJwb3N0RGF0YSIsImNhdGVnb3JpZXMiLCJuYW1lIiwic2x1ZyIsInBvc3RVcmwiLCJtYXRjaCIsInBhcmFtcyIsImxvYWRlciIsInNoaWZ0Q29udGVudCIsImJpbmQiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwibG9jYXRpb24iLCJwYXRobmFtZSIsInBhdGhOYW1lcyIsInNwbGl0IiwiY29uc29sZSIsImxvZyIsInNpbmdsZVBvc3QiLCJzZXRTdGF0ZSIsImdldF9wb3N0RGF0YSIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCIkIiwiaXMiLCJpbnNlcnRCZWZvcmUiLCJBeGlvcyIsImNvbmZpZyIsInBvc3RfdXJsIiwidGhlbiIsImVycm9yIiwidG9hc3QiLCJtZXRhIiwidGl0bGUiLCJjaGFyc2V0Iiwia2V5d29yZHMiLCJkZXNjcmlwdGlvbiIsInB1Ymxpc2hlZCIsIm1hcCIsImNhdCIsImkiLCJsZW5ndGgiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJpbWFnZSIsIl9faHRtbCIsImNvbnRlbnQiLCJDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQUEsbUJBQU8sQ0FBQyx5RUFBRCxDQUFQOzs7O0lBMEJxQkMsVTs7Ozs7QUFDbkIsc0JBQVlDLEtBQVosRUFBbUI7QUFBQTs7QUFBQTs7QUFBQTs7QUFDakIsOEJBQU1BLEtBQU47O0FBQ0EsZUFBbUMsRUFFbEM7O0FBQ0QsUUFBSUMsUUFBUSxHQUFHLE1BQUtELEtBQXBCO0FBQ0EsVUFBS0UsS0FBTCxHQUFhO0FBQ1hDLFVBQUksRUFBRUYsUUFBUSxDQUFDRSxJQUFULENBQWNBLElBRFQ7QUFFWEMsY0FBUSxFQUFFO0FBQ1JDLGtCQUFVLEVBQUUsQ0FBQztBQUFFQyxjQUFJLEVBQUUsRUFBUjtBQUFZQyxjQUFJLEVBQUU7QUFBbEIsU0FBRDtBQURKLE9BRkM7QUFLWEMsYUFBTyxpQkFBRSxNQUFLUixLQUFQLHFFQUFFLFlBQVlTLEtBQWQsK0VBQUUsa0JBQW1CQyxNQUFyQiwwREFBRSxzQkFBMkJILElBTHpCO0FBTVhJLFlBQU0sRUFBRTtBQU5HLEtBQWI7QUFTQSxVQUFLQyxZQUFMLEdBQW9CLE1BQUtBLFlBQUwsQ0FBa0JDLElBQWxCLHlJQUFwQjtBQWZpQjtBQWdCbEI7Ozs7d0NBRW1CO0FBQ2xCLFdBQUtELFlBQUw7O0FBQ0EsZ0JBQWlDO0FBQy9CRSxjQUFNLENBQUNDLGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDLEtBQUtILFlBQXZDO0FBQ0Q7O0FBQ0QsVUFBSUUsTUFBTSxDQUFDRSxRQUFQLENBQWdCQyxRQUFwQixFQUE4QjtBQUM1QixZQUFJQyxTQUFTLEdBQUdKLE1BQU0sQ0FBQ0UsUUFBUCxDQUFnQkMsUUFBaEIsQ0FBeUJFLEtBQXpCLENBQStCLEdBQS9CLENBQWhCO0FBQ0FDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBb0JILFNBQXBCO0FBQ0EsWUFBSUksV0FBVSxHQUFHSixTQUFTLENBQUMsQ0FBRCxDQUExQjtBQUNBLGFBQUtLLFFBQUwsQ0FBYztBQUFFZixpQkFBTyxFQUFFYztBQUFYLFNBQWQ7QUFDRDs7QUFDRCxXQUFLRSxZQUFMLENBQWtCRixVQUFsQjtBQUNEOzs7MkNBRXNCO0FBQ3JCLGdCQUFpQztBQUMvQlIsY0FBTSxDQUFDVyxtQkFBUCxDQUEyQixRQUEzQixFQUFxQyxLQUFLYixZQUExQztBQUNEO0FBQ0YsSyxDQUVEOzs7O21DQUNlO0FBQ2IsVUFBSWMsOENBQUMsQ0FBQyxjQUFELENBQUQsQ0FBa0JDLEVBQWxCLENBQXFCLFVBQXJCLENBQUosRUFBc0M7QUFDcENELHNEQUFDLENBQUMsZ0JBQUQsQ0FBRCxDQUFvQkUsWUFBcEIsQ0FBaUNGLDhDQUFDLENBQUMsWUFBRCxDQUFsQztBQUNELE9BRkQsTUFFTztBQUNMQSxzREFBQyxDQUFDLGdCQUFELENBQUQsQ0FBb0JFLFlBQXBCLENBQWlDRiw4Q0FBQyxDQUFDLHdCQUFELENBQWxDO0FBQ0Q7QUFDRixLLENBRUQ7Ozs7aUNBQ2FKLFUsRUFBWTtBQUFBOztBQUN2QixVQUFJZCxPQUFPLEdBQUdjLFVBQWQ7QUFDQU8sdURBQUEsQ0FBVUMscURBQUEsR0FBeUIsbUJBQW5DLEVBQXdEO0FBQ3REcEIsY0FBTSxFQUFFO0FBQUVxQixrQkFBUSxFQUFFdkI7QUFBWjtBQUQ4QyxPQUF4RCxFQUdHd0IsSUFISCxDQUdRLFVBQUMvQixRQUFELEVBQWM7QUFDbEI7QUFDQSxZQUFNRyxRQUFRLEdBQUdILFFBQVEsQ0FBQ0UsSUFBVCxDQUFjQSxJQUEvQjs7QUFDQSxjQUFJLENBQUNvQixRQUFMLENBQWM7QUFDWm5CLGtCQUFRLEVBQUVBLFFBREU7QUFFWk8sZ0JBQU0sRUFBRTtBQUZJLFNBQWQ7QUFJRCxPQVZILFdBV1MsVUFBQ3NCLEtBQUQsRUFBVztBQUNoQmIsZUFBTyxDQUFDQyxHQUFSLENBQVlZLEtBQUssQ0FBQ2hDLFFBQWxCO0FBQ0FpQyxnRUFBQSxDQUFZLHVCQUFaO0FBQ0QsT0FkSDtBQWVEOzs7NkJBRVE7QUFBQTtBQUFBOztBQUNQLFVBQU1DLElBQUksR0FBRztBQUNYQyxhQUFLLEVBQUUseURBREk7QUFFWEQsWUFBSSxFQUFFO0FBQ0pFLGlCQUFPLEVBQUUsT0FETDtBQUVKL0IsY0FBSSxFQUFFO0FBQ0pnQyxvQkFBUSxFQUNOO0FBRkU7QUFGRjtBQUZLLE9BQWI7O0FBV0EsVUFBTTNCLE1BQU0sZ0JBQ1Y7QUFBSyxpQkFBUyxFQUFDLFFBQWY7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsU0FBZjtBQUFBLGtDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFIRixlQUlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGOztBQVpPLHdCQXVCa0IsS0FBS1QsS0F2QnZCO0FBQUEsVUF1QkRFLFFBdkJDLGVBdUJEQSxRQXZCQztBQUFBLFVBdUJTRCxJQXZCVCxlQXVCU0EsSUF2QlQsRUF3QlA7O0FBQ0EsMEJBQ0U7QUFBSyxpQkFBUyxFQUFDLGtCQUFmO0FBQWtDLFVBQUUsRUFBQyxrQkFBckM7QUFBQSxnQ0FDRSw4REFBQyx5REFBRCxvQkFBa0JnQyxJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUsOERBQUMsaUVBQUQ7QUFDRSxlQUFLLEVBQUVoQyxJQUFJLENBQUNpQyxLQURkO0FBRUUscUJBQVcsRUFBRWpDLElBQUksQ0FBQ29DLFdBRnBCO0FBR0Usa0JBQVEsRUFBRXBDLElBQUksQ0FBQ21DO0FBSGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkYsZUFRRTtBQUFTLG1CQUFNLG1CQUFmO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLHFDQUFmO0FBQUEsbUNBQ0U7QUFBSyx1QkFBUyxFQUFDLGtCQUFmO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLHNCQUFmO0FBQUEsdUNBQ0U7QUFBSywyQkFBUyxFQUFDLFlBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsNkRBQWY7QUFBQSw0Q0FDRTtBQUFLLCtCQUFTLEVBQUMsb0JBQWY7QUFBQSw2Q0FDRTtBQUFJLGlDQUFTLEVBQUMsYUFBZDtBQUFBLGdEQUNFO0FBQUEsaURBQ0UsOERBQUMsbURBQUQ7QUFBTSxnQ0FBSSxFQUFDLE9BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBSUU7QUFBQSxvQ0FBS2xDLFFBQVEsQ0FBQ2dDO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQURGLGVBU0U7QUFBSywrQkFBUyxFQUFDLGlDQUFmO0FBQUEsNkNBQ0U7QUFBRyxpQ0FBUyxFQUFDLHdDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBMEJFO0FBQUsscUJBQVMsRUFBQyxjQUFmO0FBQUEsbUNBQ0U7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSxxQ0FDRTtBQUFLLHlCQUFTLEVBQUMsYUFBZjtBQUFBLHdDQUNFO0FBQUssMkJBQVMsRUFBQyxvQ0FBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxXQUFmO0FBQUEsMkNBQ0U7QUFBSywrQkFBUyxFQUFDLFdBQWY7QUFBQSw2Q0FDRTtBQUFLLGlDQUFTLEVBQUMsTUFBZjtBQUFBLGtDQUNHLEtBQUtsQyxLQUFMLENBQVdTLE1BQVgsSUFBcUIsSUFBckIsR0FDQ0EsTUFERCxnQkFHQztBQUFBLGtEQUNFO0FBQUkscUNBQVMsRUFBQyxzQ0FBZDtBQUFBLHNDQUNHUCxRQUFRLENBQUNnQztBQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBREYsZUFJRTtBQUFLLHFDQUFTLEVBQUMsV0FBZjtBQUFBLG1EQUNFO0FBQUEseUNBQ0doQyxRQUFRLENBQUNvQyxTQUFULElBQXNCLElBQXRCLGlCQUNDO0FBQUEsd0RBQ0U7QUFDRSwyQ0FBUyxFQUFDLGVBRFo7QUFFRSxpREFBWTtBQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0NBREYsRUFJUSxHQUpSLEVBS0dwQyxRQUFRLENBQUNvQyxTQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQ0FGSixlQVVFO0FBQUEsd0RBQ0U7QUFDRSwyQ0FBUyxFQUFDLGdCQURaO0FBRUUsaURBQVk7QUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHdDQURGLEVBS0dwQyxRQUxILGFBS0dBLFFBTEgsK0NBS0dBLFFBQVEsQ0FBRUMsVUFMYix5REFLRyxxQkFBc0JvQyxHQUF0QixDQUEwQixVQUFDQyxHQUFELEVBQU1DLENBQU4sRUFBWTtBQUNyQyxzREFDRTtBQUFBLCtDQUNHRCxHQUFHLENBQUNwQyxJQURQLEVBQ2EsR0FEYixFQUVHcUMsQ0FBQyxHQUFHdkMsUUFBUSxDQUFDQyxVQUFULENBQW9CdUMsTUFBcEIsR0FBNkIsQ0FBakMsR0FDRyxJQURILEdBRUcsRUFKTjtBQUFBLHFDQUFXRCxDQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsNENBREY7QUFRRCxpQ0FUQSxDQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQ0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQUpGLGVBaUNFO0FBQUsscUNBQVMsRUFBQyxVQUFmO0FBQUEsbURBQ0U7QUFDRSx1Q0FBUyxFQUFDLFlBRFo7QUFFRSxtQ0FBSyxFQUFFO0FBQ0xFLCtDQUFlLEVBQ2J6QyxRQUFRLENBQUMwQyxLQUFULElBQWtCLElBQWxCLEdBQ0kscUNBREosaUJBRVcxQyxRQUFRLENBQUMwQyxLQUZwQjtBQUZHO0FBRlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBakNGLGVBNkNFO0FBQUsscUNBQVMsRUFBQyxXQUFmO0FBQUEsb0RBQ0U7QUFBTyx1Q0FBUyxFQUFDLHNDQUFqQjtBQUFBLHNEQUNFO0FBQUcseUNBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0NBREYsRUFDNkMsR0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQURGLGVBS0U7QUFDRSx1Q0FBUyxFQUFDLDRCQURaO0FBRUUscURBQXVCLEVBQUU7QUFDdkJDLHNDQUFNLEVBQUUzQyxRQUFRLENBQUM0QztBQURNO0FBRjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQTdDRjtBQUFBO0FBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQTRFRTtBQUFLLDJCQUFTLEVBQUMsb0NBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsY0FBZjtBQUFBLDJDQUNFO0FBQUEsOENBQ0UsOERBQUMsdUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFERixlQUVFLDhEQUFDLHlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUkYsZUE0SEU7QUFBSyxtQkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkE1SEYsZUE2SEUsOERBQUMsa0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkE3SEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREY7QUFpSUQ7Ozs7RUE5TnFDQyw0QyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9ibG9nL3NpbmdsZS9bc2x1Z10uNjM2OWI5OWNhMjg4MTRiZDU1MzguaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBIZWFkZXIgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9oZWFkZXIvaW5kZXguanN4JztcclxuaW1wb3J0IEZvb3RlciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2Zvb3Rlci9pbmRleC5qc3gnO1xyXG5pbXBvcnQgVW5kZXJjb25zdHJ1Y3Rpb24gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91bmRlci1jb25zdHJ1Y3Rpb24vaW5kZXguanN4JztcclxuaW1wb3J0IEJsb2dDYXRlZ29yaWVzIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvcG9zdC1jYXRlZ29yeS9pbmRleC5qc3gnO1xyXG5pbXBvcnQgQmxvZ1JlY2VudFBvc3RzIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvcG9zdC1yZWNlbnQvaW5kZXguanN4JztcclxuaW1wb3J0IERvY3VtZW50TWV0YSBmcm9tICdyZWFjdC1kb2N1bWVudC1tZXRhJztcclxuaW1wb3J0IHsgVG9hc3RDb250YWluZXIsIHRvYXN0LCBTbGlkZSB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcclxuaW1wb3J0ICdyZWFjdC10b2FzdGlmeS9kaXN0L1JlYWN0VG9hc3RpZnkuY3NzJztcclxuaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuaW1wb3J0IEF4aW9zIGZyb20gJ2F4aW9zJztcclxuaW1wb3J0IGh0dHBzIGZyb20gXCJodHRwc1wiO1xyXG5pbXBvcnQgKiBhcyBjb25maWcgZnJvbSAnLi4vLi4vLi4vY29uZmlnJztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5cclxucmVxdWlyZSgndHlwZWZhY2UtbW9udHNlcnJhdCcpXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKCkge1xyXG4gIGxldCBkYXRhID0gW107XHJcblxyXG4gIGNvbnN0IGluc3RhbmNlID0gQXhpb3MuY3JlYXRlKHtcclxuICAgIGh0dHBzQWdlbnQ6IG5ldyBodHRwcy5BZ2VudCh7XHJcbiAgICAgIHJlamVjdFVuYXV0aG9yaXplZDogZmFsc2UsXHJcbiAgICB9KSxcclxuICB9KTtcclxuXHJcbiAgYXdhaXQgaW5zdGFuY2VcclxuICAgIC5nZXQoXCJodHRwczovL2FwaS5oYXNodGFnLWNhLmNvbS9hcGkvdjEvbWV0YWRhdGFcIiwge1xyXG4gICAgICBwYXJhbXM6IHtcclxuICAgICAgICBwYWdlX3R5cGU6IFwic3RhdGljXCIsXHJcbiAgICAgICAgc2x1ZzogXCJzZXZpY2VzXCIsXHJcbiAgICAgIH0sXHJcbiAgICB9KVxyXG4gICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgIGRhdGEgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgfSk7XHJcbiAgcmV0dXJuIHtcclxuICAgIHByb3BzOiB7IGRhdGEgfSxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTaW5nbGVwb3N0IGV4dGVuZHMgQ29tcG9uZW50IHtcclxuICBjb25zdHJ1Y3Rvcihwcm9wcykge1xyXG4gICAgc3VwZXIocHJvcHMpO1xyXG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgZ2xvYmFsLndpbmRvdyA9IHt9O1xyXG4gICAgfVxyXG4gICAgbGV0IHJlc3BvbnNlID0gdGhpcy5wcm9wcztcclxuICAgIHRoaXMuc3RhdGUgPSB7XHJcbiAgICAgIGRhdGE6IHJlc3BvbnNlLmRhdGEuZGF0YSxcclxuICAgICAgcG9zdERhdGE6IHtcclxuICAgICAgICBjYXRlZ29yaWVzOiBbeyBuYW1lOiBcIlwiLCBzbHVnOiBcIlwiIH1dLFxyXG4gICAgICB9LFxyXG4gICAgICBwb3N0VXJsOiB0aGlzLnByb3BzPy5tYXRjaD8ucGFyYW1zPy5zbHVnLFxyXG4gICAgICBsb2FkZXI6IHRydWUsXHJcbiAgICB9O1xyXG5cclxuICAgIHRoaXMuc2hpZnRDb250ZW50ID0gdGhpcy5zaGlmdENvbnRlbnQuYmluZCh0aGlzKTtcclxuICB9XHJcblxyXG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xyXG4gICAgdGhpcy5zaGlmdENvbnRlbnQoKTtcclxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgdGhpcy5zaGlmdENvbnRlbnQpO1xyXG4gICAgfVxyXG4gICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSkge1xyXG4gICAgICBsZXQgcGF0aE5hbWVzID0gd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLnNwbGl0KFwiL1wiKTtcclxuICAgICAgY29uc29sZS5sb2coXCJwYXRoXCIsIHBhdGhOYW1lcyk7XHJcbiAgICAgIGxldCBzaW5nbGVQb3N0ID0gcGF0aE5hbWVzWzNdO1xyXG4gICAgICB0aGlzLnNldFN0YXRlKHsgcG9zdFVybDogc2luZ2xlUG9zdCB9KTtcclxuICAgIH1cclxuICAgIHRoaXMuZ2V0X3Bvc3REYXRhKHNpbmdsZVBvc3QpO1xyXG4gIH1cclxuXHJcbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHRoaXMuc2hpZnRDb250ZW50KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vU2VhcmNoIGRpdiBzaGlmdFxyXG4gIHNoaWZ0Q29udGVudCgpIHtcclxuICAgIGlmICgkKFwiLm1vYi12aXNpYmxlXCIpLmlzKFwiOnZpc2libGVcIikpIHtcclxuICAgICAgJChcIi53aWRnZXRfc2VhcmNoXCIpLmluc2VydEJlZm9yZSgkKFwiLmJsb2ctbGlzdFwiKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAkKFwiLndpZGdldF9zZWFyY2hcIikuaW5zZXJ0QmVmb3JlKCQoXCIud2lkZ2V0X3JlY2VudF9lbnRyaWVzXCIpKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vR2V0IHBvc3QgZGF0YVxyXG4gIGdldF9wb3N0RGF0YShzaW5nbGVQb3N0KSB7XHJcbiAgICBsZXQgcG9zdFVybCA9IHNpbmdsZVBvc3Q7XHJcbiAgICBBeGlvcy5nZXQoY29uZmlnLm15Q29uZmlnLmFwaVVybCArIFwiYmxvZy9wb3N0cy9zaW5nbGVcIiwge1xyXG4gICAgICBwYXJhbXM6IHsgcG9zdF91cmw6IHBvc3RVcmwgfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIGNvbnN0IHBvc3REYXRhID0gcmVzcG9uc2UuZGF0YS5kYXRhO1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgcG9zdERhdGE6IHBvc3REYXRhLFxyXG4gICAgICAgICAgbG9hZGVyOiBmYWxzZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yLnJlc3BvbnNlKTtcclxuICAgICAgICB0b2FzdC5lcnJvcihcIlNvbWV0aGluZyB3ZW50IHdyb25nLlwiKTtcclxuICAgICAgfSk7XHJcbiAgfVxyXG5cclxuICByZW5kZXIoKSB7XHJcbiAgICBjb25zdCBtZXRhID0ge1xyXG4gICAgICB0aXRsZTogXCJCbG9ncyAtIEZ1bGxTdGFjayBXZWIgRGV2ZWxvcG1lbnR8IEJheSBhcmVhLCBDYWxpZm9ybmlhXCIsXHJcbiAgICAgIG1ldGE6IHtcclxuICAgICAgICBjaGFyc2V0OiBcInV0Zi04XCIsXHJcbiAgICAgICAgbmFtZToge1xyXG4gICAgICAgICAga2V5d29yZHM6XHJcbiAgICAgICAgICAgIFwiV2ViIGRldmVsb3BtZW50IGNvbXBhbnksc29mdHdhcmUgZGV2ZWxvcG1lbnQgY29tcGFueSx3ZWIgZGV2ZWxvcG1lbnQga29jaGksd2ViIGRldmVsb3BtZW50IGNvbXBhbnkga29jaGksc29mdHdhcmUgZGV2ZWxvcG1lbnQga29jaGksd2ViIGRldmVsb3BtZW50IGNvbXBhbnkga29jaGksc29mdHdhcmUgZGV2ZWxvcG1lbnQga29jaGksd2ViIGRlc2lnbiBhbmQgZGV2ZWxvcG1lbnQga29jaGksZnVsbCBzdGFjayBkZXZlbG9wbWVudCBjb21wYW55LHdvcmRwcmVzcyBjdXN0b21pc2F0aW9uIGNvbXBhbnkga2VyYWxhLHNob3BpZnkgdGhlbWUgZGV2ZWxvcG1lbnQgY29tcGFueSBrZXJhbGEsZWNvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkga2VyYWxhLHdvb2NvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkga2VyYWxhLHdlYiBkZXZlbG9wbWVudCBjb21wYW55IENhbGlmb3JuaWEsc29mdHdhcmUgZGV2ZWxvcG1lbnQgY2FsaWZvcm5pYSx3b3JkcHJlc3MgZGV2ZWxvcG1lbnQgY2FsaWZvcm5pYSx3b3JkcHJlc3MgZGV2ZWxvcG1lbnQga29jaGksc2hvcGlmeSBkZXZlbG9wbWVudCBrb2NoaSxzaG9waWZ5IGRldmVsb3BtZW50IGNhbGlmb3JuaWEsd29yZHByZXNzIGN1c3RvbWlzYXRpb24gY29tcGFueSxzaG9waWZ5IHRoZW1lIGRldmVsb3BtZW50IGNvbXBhbnksZWNvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkga29jaGksZWNvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkgY2FsaWZvcm5pYVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGxvYWRlciA9IChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2FkZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwaW5uZXJcIj5cclxuICAgICAgICAgIDxkaXY+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PjwvZGl2PlxyXG4gICAgICAgICAgPGRpdj48L2Rpdj5cclxuICAgICAgICAgIDxkaXY+PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgTG9hZGluZ1xyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgICBsZXQgeyBwb3N0RGF0YSwgZGF0YSB9ID0gdGhpcy5zdGF0ZTtcclxuICAgIC8vY29uc29sZS5sb2coZGF0YSlcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2luZ2xlLWJsb2ctbWFpblwiIGlkPVwic2luZ2xlLWJsb2ctbWFpblwiPlxyXG4gICAgICAgIDxEb2N1bWVudE1ldGEgey4uLm1ldGF9IC8+XHJcbiAgICAgICAgPEhlYWRlclxyXG4gICAgICAgICAgdGl0bGU9e2RhdGEudGl0bGV9XHJcbiAgICAgICAgICBkZXNjcmlwdGlvbj17ZGF0YS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgIGtleXdvcmRzPXtkYXRhLmtleXdvcmRzfVxyXG4gICAgICAgID48L0hlYWRlcj5cclxuXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3M9XCJjb250ZW50LWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItZmx1aWQgc2VydmljZS1iZyBwLTAgbS0wIFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmctcmlnaHRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmFubmVyLWZyYW1lXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cganVzdGlmeS1jb250ZW50LWNlbnRlciBzZXJ2aWNlLWJhbm5lci1jb250ZW50IHBsLTMgcHItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiYnJlYWRjcnVtYnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYmxvZ1wiPkJsb2dzPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGk+e3Bvc3REYXRhLnRpdGxlfTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyIHRleHQtd2hpdGUgIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYm9sZC1jb250ZW50cyBzZXJ2aWNlLWNvbnRlbnQtYm94IHBsLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgV2UgYXJlIHNlZWtpbmcgYnJpbGxpYW50IG1pbmRzIHRvIGpvaW4gb3VyIGR5bmFtaWMgdGVhbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmQgbWFrZSBpdCBldmVuIGJldHRlci5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGItcm93LTFcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1zbS0xMiBjb2wtbWQtOCBjb2wtbGctOFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3RoaXMuc3RhdGUubG9hZGVyID09IHRydWUgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJjYXJkLXRpdGxlIHRleHQtbGV2ZWwtNCB0aXRsZS1vcmFuZ2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Bvc3REYXRhLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oNT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx1bD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cG9zdERhdGEucHVibGlzaGVkICE9IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZhIGZhLWNsb2NrLW9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2k+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cG9zdERhdGEucHVibGlzaGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZhIGZhLXRoLWxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cG9zdERhdGE/LmNhdGVnb3JpZXM/Lm1hcCgoY2F0LCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXQubmFtZX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aSA8IHBvc3REYXRhLmNhdGVnb3JpZXMubGVuZ3RoIC0gMVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiLCBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWltZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvZy10aHVtYlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRJbWFnZTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zdERhdGEuaW1hZ2UgPT0gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCIvaW1hZ2VzL2Jsb2dzL3dyaXRpbmctZ29vZC1ibG9nLmpwZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBgdXJsKCR7cG9zdERhdGEuaW1hZ2V9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyp7IChwb3N0RGF0YS5pbWFnZSA9PSBudWxsKSA/IDxpbWcgc3JjPVwiL2ltYWdlcy9ibG9ncy93cml0aW5nLWdvb2QtYmxvZy5qcGdcIiBhbHQ9e3Bvc3REYXRhLmltYWdlX2FsdH0gLz4gOiA8aW1nIHNyYz17cG9zdERhdGEuaW1hZ2V9IGFsdD17cG9zdERhdGEuaW1hZ2VfYWx0fSAvPiB9Ki99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzbWFsbCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkIGNhdCB0ZXh0LWFib3ZlLW1haW4tdGl0bGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdXNlcnMgdGV4dC1pbmZvXCI+PC9pPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBIYXNodGFnIHN5c3RlbXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhcmQtdGV4dCBibG9nLWRldGFpbC1wYWdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX19odG1sOiBwb3N0RGF0YS5jb250ZW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qPGRpdiBjbGFzc05hbWU9XCJibG9nLW5hdlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJwcmV2XCI+PGkgY2xhc3NOYW1lPVwiZmEgZmEtYW5nbGUtbGVmdFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT5QcmV2PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJuZXh0XCI+TmV4dDxpIGNsYXNzTmFtZT1cImZhIGZhLWFuZ2xlLXJpZ2h0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPjwvYT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj4qL31cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtc20tMTIgY29sLW1kLTQgY29sLWxnLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXNpZGViYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QmxvZ1JlY2VudFBvc3RzPjwvQmxvZ1JlY2VudFBvc3RzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJsb2dDYXRlZ29yaWVzPjwvQmxvZ0NhdGVnb3JpZXM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2ItdmlzaWJsZVwiPjwvZGl2PlxyXG4gICAgICAgIDxGb290ZXI+PC9Gb290ZXI+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==