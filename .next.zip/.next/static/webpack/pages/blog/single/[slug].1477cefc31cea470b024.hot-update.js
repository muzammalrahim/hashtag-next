self["webpackHotUpdate_N_E"]("pages/blog/single/[slug]",{

/***/ "./pages/blog/single/[slug].jsx":
/*!**************************************!*\
  !*** ./pages/blog/single/[slug].jsx ***!
  \**************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Singlepost; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_header_index_jsx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/header/index.jsx */ "./components/header/index.jsx");
/* harmony import */ var _components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/footer/index.jsx */ "./components/footer/index.jsx");
/* harmony import */ var _components_under_construction_index_jsx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/under-construction/index.jsx */ "./components/under-construction/index.jsx");
/* harmony import */ var _components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../components/post-category/index.jsx */ "./components/post-category/index.jsx");
/* harmony import */ var _components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../components/post-recent/index.jsx */ "./components/post-recent/index.jsx");
/* harmony import */ var react_document_meta__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-document-meta */ "./node_modules/react-document-meta/dist/index.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../config */ "./config.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_20__);
/* module decorator */ module = __webpack_require__.hmd(module);









var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\pages\\blog\\single\\[slug].jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }
















__webpack_require__(/*! typeface-montserrat */ "./node_modules/typeface-montserrat/index.css");

var __N_SSP = true;

var Singlepost = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__.default)(Singlepost, _Component);

  var _super = _createSuper(Singlepost);

  function Singlepost(props) {
    var _this;

    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__.default)(this, Singlepost);

    _this = _super.call(this, props);

    if (false) {}

    var response = _this.props;
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    var slug = router.query.slug;
    _this.state = {
      data: response.data.data,
      postData: {
        categories: [{
          name: "",
          slug: ""
        }]
      },
      postUrl: slug,
      loader: true
    };
    _this.shiftContent = _this.shiftContent.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__.default)(_this));
    return _this;
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__.default)(Singlepost, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.shiftContent();

      if (true) {
        window.addEventListener("resize", this.shiftContent);
      }

      this.get_postData();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (true) {
        window.removeEventListener("resize", this.shiftContent);
      }
    } //Search div shift

  }, {
    key: "shiftContent",
    value: function shiftContent() {
      if (jquery__WEBPACK_IMPORTED_MODULE_17___default()(".mob-visible").is(":visible")) {
        jquery__WEBPACK_IMPORTED_MODULE_17___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_17___default()('.blog-list'));
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_17___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_17___default()('.widget_recent_entries'));
      }
    } //Get post data

  }, {
    key: "get_postData",
    value: function get_postData() {
      var _this2 = this;

      var postUrl = this.state.postUrl;
      axios__WEBPACK_IMPORTED_MODULE_18___default().get(_config__WEBPACK_IMPORTED_MODULE_19__.myConfig.apiUrl + 'blog/posts/single', {
        params: {
          post_url: postUrl
        }
      }).then(function (response) {
        // console.log(response.data);
        var postData = response.data.data;

        _this2.setState({
          postData: postData,
          loader: false
        });
      })["catch"](function (error) {
        console.log(error.response);
        react_toastify__WEBPACK_IMPORTED_MODULE_21__.toast.error("Something went wrong.");
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var meta = {
        title: 'Blogs - FullStack Web Development| Bay area, California',
        meta: {
          charset: 'utf-8',
          name: {
            keywords: 'Web development company,software development company,web development kochi,web development company kochi,software development kochi,web development company kochi,software development kochi,web design and development kochi,full stack development company,wordpress customisation company kerala,shopify theme development company kerala,ecommerce development company kerala,woocommerce development company kerala,web development company California,software development california,wordpress development california,wordpress development kochi,shopify development kochi,shopify development california,wordpress customisation company,shopify theme development company,ecommerce development company kochi,ecommerce development company california'
          }
        }
      };

      var loader = /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "loader",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "spinner",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 121,
            columnNumber: 69
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 121,
            columnNumber: 80
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 121,
            columnNumber: 91
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 121,
            columnNumber: 102
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 121,
          columnNumber: 44
        }, this), "Loading"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 121,
        columnNumber: 20
      }, this);

      var _this$state = this.state,
          postData = _this$state.postData,
          data = _this$state.data;
      console.log(data);
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "single-blog-main",
        id: "single-blog-main",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_document_meta__WEBPACK_IMPORTED_MODULE_15__.default, _objectSpread({}, meta), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 126,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_header_index_jsx__WEBPACK_IMPORTED_MODULE_10__.default, {
          title: data.title,
          description: data.description,
          keywords: data.keywords
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 127,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
          "class": "content-container",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "container-fluid service-bg p-0 m-0 ",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "service-bg-right",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "service-banner-frame",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "container ",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "row justify-content-center service-banner-content pl-3 pr-3",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                        className: "breadcrumbs",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_20___default()), {
                            href: "/blog",
                            children: "Blogs"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 137,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 137,
                          columnNumber: 25
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: postData.title
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 138,
                          columnNumber: 25
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 136,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 135,
                      columnNumber: 21
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12 text-white  ",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                        className: "bold-contents service-content-box pl-4",
                        children: "We are seeking brilliant minds to join our dynamic team and make it even better."
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 142,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 141,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 134,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 133,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 132,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 131,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 130,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "blog-section",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "container",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "row b-row-1",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-8 col-lg-8",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-wrap",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "blog-list",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "card",
                        children: this.state.loader == true ? loader : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h5", {
                            className: "card-title text-level-4 title-orange",
                            children: postData.title
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 162,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-meta",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                              children: [postData.published != null && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-clock-o",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 166,
                                  columnNumber: 39
                                }, this), " ", postData.published]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 166,
                                columnNumber: 35
                              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-th-large",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 169,
                                  columnNumber: 35
                                }, this), postData.categories.map(function (cat, i) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                    children: [cat.name, " ", i < postData.categories.length - 1 ? ', ' : '']
                                  }, i, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 172,
                                    columnNumber: 39
                                  }, _this3);
                                })]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 168,
                                columnNumber: 33
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 164,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 163,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-img",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "blog-thumb",
                              style: {
                                backgroundImage: postData.image == null ? '/images/blogs/writing-good-blog.jpg' : "url(".concat(postData.image, ")")
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 179,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 178,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "card-body",
                            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("small", {
                              className: "text-muted cat text-above-main-title",
                              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                className: "fas fa-users text-info"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 185,
                                columnNumber: 33
                              }, this), " Hashtag systems"]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 184,
                              columnNumber: 31
                            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "card-text blog-detail-page",
                              dangerouslySetInnerHTML: {
                                __html: postData.content
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 187,
                              columnNumber: 31
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 183,
                            columnNumber: 29
                          }, this)]
                        }, void 0, true)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 157,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 156,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 155,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 154,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-4 col-lg-4",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-sidebar",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("aside", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_14__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 203,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_13__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 204,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 202,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 201,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 200,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 153,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 152,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 151,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 129,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "mob-visible"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 212,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_11__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 213,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 125,
        columnNumber: 7
      }, this);
    }
  }]);

  return Singlepost;
}(react__WEBPACK_IMPORTED_MODULE_8__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ }),

/***/ "./node_modules/next/router.js":
/*!*************************************!*\
  !*** ./node_modules/next/router.js ***!
  \*************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/router */ "./node_modules/next/dist/client/router.js")


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYmxvZy9zaW5nbGUvW3NsdWddLmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL25leHQvcm91dGVyLmpzIl0sIm5hbWVzIjpbInJlcXVpcmUiLCJTaW5nbGVwb3N0IiwicHJvcHMiLCJyZXNwb25zZSIsInJvdXRlciIsInVzZVJvdXRlciIsInNsdWciLCJxdWVyeSIsInN0YXRlIiwiZGF0YSIsInBvc3REYXRhIiwiY2F0ZWdvcmllcyIsIm5hbWUiLCJwb3N0VXJsIiwibG9hZGVyIiwic2hpZnRDb250ZW50IiwiYmluZCIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJnZXRfcG9zdERhdGEiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiJCIsImlzIiwiaW5zZXJ0QmVmb3JlIiwiQXhpb3MiLCJjb25maWciLCJwYXJhbXMiLCJwb3N0X3VybCIsInRoZW4iLCJzZXRTdGF0ZSIsImVycm9yIiwiY29uc29sZSIsImxvZyIsInRvYXN0IiwibWV0YSIsInRpdGxlIiwiY2hhcnNldCIsImtleXdvcmRzIiwiZGVzY3JpcHRpb24iLCJwdWJsaXNoZWQiLCJtYXAiLCJjYXQiLCJpIiwibGVuZ3RoIiwiYmFja2dyb3VuZEltYWdlIiwiaW1hZ2UiLCJfX2h0bWwiLCJjb250ZW50IiwiQ29tcG9uZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBQSxtQkFBTyxDQUFDLHlFQUFELENBQVA7Ozs7SUEwQnFCQyxVOzs7OztBQUduQixzQkFBWUMsS0FBWixFQUFtQjtBQUFBOztBQUFBOztBQUNqQiw4QkFBTUEsS0FBTjs7QUFDSixlQUFtQyxFQUU5Qjs7QUFDRCxRQUFJQyxRQUFRLEdBQUcsTUFBS0QsS0FBcEI7QUFDQSxRQUFNRSxNQUFNLEdBQUdDLHNEQUFTLEVBQXhCO0FBTmlCLFFBT1RDLElBUFMsR0FPQUYsTUFBTSxDQUFDRyxLQVBQLENBT1RELElBUFM7QUFRakIsVUFBS0UsS0FBTCxHQUFhO0FBQ1hDLFVBQUksRUFBRU4sUUFBUSxDQUFDTSxJQUFULENBQWNBLElBRFQ7QUFFWEMsY0FBUSxFQUFFO0FBQ1JDLGtCQUFVLEVBQUUsQ0FBQztBQUFFQyxjQUFJLEVBQUUsRUFBUjtBQUFZTixjQUFJLEVBQUU7QUFBbEIsU0FBRDtBQURKLE9BRkM7QUFLWE8sYUFBTyxFQUFFUCxJQUxFO0FBTVhRLFlBQU0sRUFBRTtBQU5HLEtBQWI7QUFTQSxVQUFLQyxZQUFMLEdBQW9CLE1BQUtBLFlBQUwsQ0FBa0JDLElBQWxCLHlJQUFwQjtBQWpCaUI7QUFtQmxCOzs7O3dDQUdtQjtBQUNsQixXQUFLRCxZQUFMOztBQUNBLGdCQUErQjtBQUM3QkUsY0FBTSxDQUFDQyxnQkFBUCxDQUF3QixRQUF4QixFQUFrQyxLQUFLSCxZQUF2QztBQUNEOztBQUNELFdBQUtJLFlBQUw7QUFDRDs7OzJDQUVzQjtBQUNyQixnQkFBaUM7QUFDL0JGLGNBQU0sQ0FBQ0csbUJBQVAsQ0FBMkIsUUFBM0IsRUFBcUMsS0FBS0wsWUFBMUM7QUFDRDtBQUNGLEssQ0FFRDs7OzttQ0FDYztBQUNaLFVBQUdNLDhDQUFDLENBQUMsY0FBRCxDQUFELENBQWtCQyxFQUFsQixDQUFxQixVQUFyQixDQUFILEVBQXFDO0FBQ25DRCxzREFBQyxDQUFDLGdCQUFELENBQUQsQ0FBb0JFLFlBQXBCLENBQWlDRiw4Q0FBQyxDQUFDLFlBQUQsQ0FBbEM7QUFDRCxPQUZELE1BR0s7QUFDSEEsc0RBQUMsQ0FBQyxnQkFBRCxDQUFELENBQW9CRSxZQUFwQixDQUFpQ0YsOENBQUMsQ0FBQyx3QkFBRCxDQUFsQztBQUNEO0FBQ0YsSyxDQUVEOzs7O21DQUNjO0FBQUE7O0FBQ1osVUFBSVIsT0FBTyxHQUFHLEtBQUtMLEtBQUwsQ0FBV0ssT0FBekI7QUFDQVcsdURBQUEsQ0FBVUMscURBQUEsR0FBdUIsbUJBQWpDLEVBQXNEO0FBQUNDLGNBQU0sRUFBRTtBQUFDQyxrQkFBUSxFQUFFZDtBQUFYO0FBQVQsT0FBdEQsRUFDQ2UsSUFERCxDQUNNLFVBQUN6QixRQUFELEVBQWM7QUFDbEI7QUFDQSxZQUFNTyxRQUFRLEdBQUdQLFFBQVEsQ0FBQ00sSUFBVCxDQUFjQSxJQUEvQjs7QUFDQSxjQUFJLENBQUNvQixRQUFMLENBQWM7QUFDWm5CLGtCQUFRLEVBQUVBLFFBREU7QUFFWkksZ0JBQU0sRUFBRTtBQUZJLFNBQWQ7QUFJRCxPQVJELFdBUVMsVUFBQWdCLEtBQUssRUFBRztBQUNmQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsS0FBSyxDQUFDM0IsUUFBbEI7QUFDQThCLGdFQUFBLENBQVksdUJBQVo7QUFDRCxPQVhEO0FBWUQ7Ozs2QkFHUTtBQUFBOztBQUNQLFVBQU1DLElBQUksR0FBRztBQUNYQyxhQUFLLEVBQUUseURBREk7QUFFWEQsWUFBSSxFQUFFO0FBQ0pFLGlCQUFPLEVBQUUsT0FETDtBQUVGeEIsY0FBSSxFQUFFO0FBQ0p5QixvQkFBUSxFQUFFO0FBRE47QUFGSjtBQUZLLE9BQWI7O0FBVUEsVUFBTXZCLE1BQU0sZ0JBQUc7QUFBSyxpQkFBUyxFQUFDLFFBQWY7QUFBQSxnQ0FBd0I7QUFBSyxtQkFBUyxFQUFDLFNBQWY7QUFBQSxrQ0FBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBekIsZUFBb0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBcEMsZUFBK0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBL0MsZUFBMEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FBZjs7QUFYTyx3QkFZZ0IsS0FBS04sS0FackI7QUFBQSxVQVlGRSxRQVpFLGVBWUZBLFFBWkU7QUFBQSxVQVlRRCxJQVpSLGVBWVFBLElBWlI7QUFhUHNCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZdkIsSUFBWjtBQUNBLDBCQUNFO0FBQUssaUJBQVMsRUFBQyxrQkFBZjtBQUFrQyxVQUFFLEVBQUMsa0JBQXJDO0FBQUEsZ0NBQ0UsOERBQUMseURBQUQsb0JBQWtCeUIsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFLDhEQUFDLGtFQUFEO0FBQVEsZUFBSyxFQUFFekIsSUFBSSxDQUFDMEIsS0FBcEI7QUFBMkIscUJBQVcsRUFBRTFCLElBQUksQ0FBQzZCLFdBQTdDO0FBQTBELGtCQUFRLEVBQUU3QixJQUFJLENBQUM0QjtBQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGLGVBSUU7QUFBUyxtQkFBTSxtQkFBZjtBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxxQ0FBZjtBQUFBLG1DQUNFO0FBQUssdUJBQVMsRUFBQyxrQkFBZjtBQUFBLHFDQUNFO0FBQUsseUJBQVMsRUFBQyxzQkFBZjtBQUFBLHVDQUNFO0FBQUssMkJBQVMsRUFBQyxZQUFmO0FBQUEseUNBQ0U7QUFBSyw2QkFBUyxFQUFDLDZEQUFmO0FBQUEsNENBQ0U7QUFBSywrQkFBUyxFQUFDLG9CQUFmO0FBQUEsNkNBQ0U7QUFBSSxpQ0FBUyxFQUFDLGFBQWQ7QUFBQSxnREFDRTtBQUFBLGlEQUFJLDhEQUFDLG1EQUFEO0FBQU0sZ0NBQUksRUFBQyxPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FERixlQUVFO0FBQUEsb0NBQUszQixRQUFRLENBQUN5QjtBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFERixlQU9FO0FBQUssK0JBQVMsRUFBQyxpQ0FBZjtBQUFBLDZDQUNFO0FBQUcsaUNBQVMsRUFBQyx3Q0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQXNCRTtBQUFLLHFCQUFTLEVBQUMsY0FBZjtBQUFBLG1DQUNFO0FBQUssdUJBQVMsRUFBQyxXQUFmO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLGFBQWY7QUFBQSx3Q0FDRTtBQUFLLDJCQUFTLEVBQUMsb0NBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsV0FBZjtBQUFBLDJDQUNFO0FBQUssK0JBQVMsRUFBQyxXQUFmO0FBQUEsNkNBQ0U7QUFBSyxpQ0FBUyxFQUFDLE1BQWY7QUFBQSxrQ0FDSSxLQUFLM0IsS0FBTCxDQUFXTSxNQUFYLElBQXFCLElBQXRCLEdBQ0NBLE1BREQsZ0JBR0M7QUFBQSxrREFDRTtBQUFJLHFDQUFTLEVBQUMsc0NBQWQ7QUFBQSxzQ0FBc0RKLFFBQVEsQ0FBQ3lCO0FBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBREYsZUFFRTtBQUFLLHFDQUFTLEVBQUMsV0FBZjtBQUFBLG1EQUNFO0FBQUEseUNBQ0l6QixRQUFRLENBQUM2QixTQUFULElBQXNCLElBQXZCLGlCQUNDO0FBQUEsd0RBQUk7QUFBRywyQ0FBUyxFQUFDLGVBQWI7QUFBNkIsaURBQVk7QUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx3Q0FBSixPQUEwRDdCLFFBQVEsQ0FBQzZCLFNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQ0FGSixlQUlFO0FBQUEsd0RBQ0U7QUFBRywyQ0FBUyxFQUFDLGdCQUFiO0FBQThCLGlEQUFZO0FBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0NBREYsRUFFRzdCLFFBQVEsQ0FBQ0MsVUFBVCxDQUFvQjZCLEdBQXBCLENBQXdCLFVBQUNDLEdBQUQsRUFBTUMsQ0FBTixFQUFZO0FBQ25DLHNEQUNFO0FBQUEsK0NBQWVELEdBQUcsQ0FBQzdCLElBQW5CLE9BQTBCOEIsQ0FBQyxHQUFJaEMsUUFBUSxDQUFDQyxVQUFWLENBQXNCZ0MsTUFBdEIsR0FBK0IsQ0FBbkMsR0FBdUMsSUFBdkMsR0FBOEMsRUFBeEU7QUFBQSxxQ0FBV0QsQ0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRDQURGO0FBR0QsaUNBSkEsQ0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0NBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FGRixlQWlCRTtBQUFLLHFDQUFTLEVBQUMsVUFBZjtBQUFBLG1EQUNFO0FBQUssdUNBQVMsRUFBQyxZQUFmO0FBQTRCLG1DQUFLLEVBQUU7QUFBQ0UsK0NBQWUsRUFBR2xDLFFBQVEsQ0FBQ21DLEtBQVQsSUFBa0IsSUFBbkIsR0FBMkIscUNBQTNCLGlCQUEwRW5DLFFBQVEsQ0FBQ21DLEtBQW5GO0FBQWxCO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQWpCRixlQXNCRTtBQUFLLHFDQUFTLEVBQUMsV0FBZjtBQUFBLG9EQUNFO0FBQU8sdUNBQVMsRUFBQyxzQ0FBakI7QUFBQSxzREFDRTtBQUFHLHlDQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNDQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FERixlQUlFO0FBQUssdUNBQVMsRUFBQyw0QkFBZjtBQUE0QyxxREFBdUIsRUFBRTtBQUFDQyxzQ0FBTSxFQUFFcEMsUUFBUSxDQUFDcUM7QUFBbEI7QUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBdEJGO0FBQUE7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBK0NFO0FBQUssMkJBQVMsRUFBQyxvQ0FBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxjQUFmO0FBQUEsMkNBQ0U7QUFBQSw4Q0FDRSw4REFBQyx1RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURGLGVBRUUsOERBQUMseUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRixlQXVGRTtBQUFLLG1CQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXZGRixlQXdGRSw4REFBQyxrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERjtBQTRGRDs7OztFQTdLcUNDLDRDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFDeEMsNkdBQWdEIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2Jsb2cvc2luZ2xlL1tzbHVnXS4xNDc3Y2VmYzMxY2VhNDcwYjAyNC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBIZWFkZXIgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9oZWFkZXIvaW5kZXguanN4JztcclxuaW1wb3J0IEZvb3RlciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2Zvb3Rlci9pbmRleC5qc3gnO1xyXG5pbXBvcnQgVW5kZXJjb25zdHJ1Y3Rpb24gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91bmRlci1jb25zdHJ1Y3Rpb24vaW5kZXguanN4JztcclxuaW1wb3J0IEJsb2dDYXRlZ29yaWVzIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvcG9zdC1jYXRlZ29yeS9pbmRleC5qc3gnO1xyXG5pbXBvcnQgQmxvZ1JlY2VudFBvc3RzIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvcG9zdC1yZWNlbnQvaW5kZXguanN4JztcclxuaW1wb3J0IERvY3VtZW50TWV0YSBmcm9tICdyZWFjdC1kb2N1bWVudC1tZXRhJztcclxuaW1wb3J0IHsgVG9hc3RDb250YWluZXIsIHRvYXN0LCBTbGlkZSB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcclxuaW1wb3J0ICdyZWFjdC10b2FzdGlmeS9kaXN0L1JlYWN0VG9hc3RpZnkuY3NzJztcclxuaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuaW1wb3J0IEF4aW9zIGZyb20gJ2F4aW9zJztcclxuaW1wb3J0IGh0dHBzIGZyb20gXCJodHRwc1wiO1xyXG5pbXBvcnQgKiBhcyBjb25maWcgZnJvbSAnLi4vLi4vLi4vY29uZmlnJztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5cclxucmVxdWlyZSgndHlwZWZhY2UtbW9udHNlcnJhdCcpXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKCkge1xyXG4gIGxldCBkYXRhID0gW107XHJcblxyXG4gIGNvbnN0IGluc3RhbmNlID0gQXhpb3MuY3JlYXRlKHtcclxuICAgIGh0dHBzQWdlbnQ6IG5ldyBodHRwcy5BZ2VudCh7XHJcbiAgICAgIHJlamVjdFVuYXV0aG9yaXplZDogZmFsc2UsXHJcbiAgICB9KSxcclxuICB9KTtcclxuXHJcbiAgYXdhaXQgaW5zdGFuY2VcclxuICAgIC5nZXQoXCJodHRwczovL2FwaS5oYXNodGFnLWNhLmNvbS9hcGkvdjEvbWV0YWRhdGFcIiwge1xyXG4gICAgICBwYXJhbXM6IHtcclxuICAgICAgICBwYWdlX3R5cGU6IFwic3RhdGljXCIsXHJcbiAgICAgICAgc2x1ZzogXCJzZXZpY2VzXCIsXHJcbiAgICAgIH0sXHJcbiAgICB9KVxyXG4gICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgIGRhdGEgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgfSk7XHJcbiAgcmV0dXJuIHtcclxuICAgIHByb3BzOiB7IGRhdGEgfSxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTaW5nbGVwb3N0IGV4dGVuZHMgQ29tcG9uZW50IHtcclxuXHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb3BzKSB7XHJcbiAgICBzdXBlcihwcm9wcyk7XHJcbmlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgZ2xvYmFsLndpbmRvdyA9IHt9O1xyXG4gICAgfVxyXG4gICAgbGV0IHJlc3BvbnNlID0gdGhpcy5wcm9wc1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgICBjb25zdCB7IHNsdWcgfSA9IHJvdXRlci5xdWVyeTtcclxuICAgIHRoaXMuc3RhdGUgPSB7XHJcbiAgICAgIGRhdGE6IHJlc3BvbnNlLmRhdGEuZGF0YSxcclxuICAgICAgcG9zdERhdGE6IHtcclxuICAgICAgICBjYXRlZ29yaWVzOiBbeyBuYW1lOiBcIlwiLCBzbHVnOiBcIlwiIH1dLFxyXG4gICAgICB9LFxyXG4gICAgICBwb3N0VXJsOiBzbHVnLFxyXG4gICAgICBsb2FkZXI6IHRydWUsXHJcbiAgICB9O1xyXG5cclxuICAgIHRoaXMuc2hpZnRDb250ZW50ID0gdGhpcy5zaGlmdENvbnRlbnQuYmluZCh0aGlzKTtcclxuICAgIFxyXG4gIH1cclxuXHJcblxyXG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xyXG4gICAgdGhpcy5zaGlmdENvbnRlbnQoKTtcclxuICAgIGlmKHR5cGVvZiB3aW5kb3cgIT09IHVuZGVmaW5lZCl7XHJcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHRoaXMuc2hpZnRDb250ZW50KTtcclxuICAgIH1cclxuICAgIHRoaXMuZ2V0X3Bvc3REYXRhKCk7XHJcbiAgfVxyXG5cclxuICBjb21wb25lbnRXaWxsVW5tb3VudCgpIHtcclxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgdGhpcy5zaGlmdENvbnRlbnQpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy9TZWFyY2ggZGl2IHNoaWZ0XHJcbiAgc2hpZnRDb250ZW50KCl7XHJcbiAgICBpZigkKFwiLm1vYi12aXNpYmxlXCIpLmlzKFwiOnZpc2libGVcIikpIHsgXHJcbiAgICAgICQoJy53aWRnZXRfc2VhcmNoJykuaW5zZXJ0QmVmb3JlKCQoJy5ibG9nLWxpc3QnKSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgJCgnLndpZGdldF9zZWFyY2gnKS5pbnNlcnRCZWZvcmUoJCgnLndpZGdldF9yZWNlbnRfZW50cmllcycpKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vR2V0IHBvc3QgZGF0YVxyXG4gIGdldF9wb3N0RGF0YSgpe1xyXG4gICAgbGV0IHBvc3RVcmwgPSB0aGlzLnN0YXRlLnBvc3RVcmw7XHJcbiAgICBBeGlvcy5nZXQoY29uZmlnLm15Q29uZmlnLmFwaVVybCsnYmxvZy9wb3N0cy9zaW5nbGUnLCB7cGFyYW1zOiB7cG9zdF91cmw6IHBvc3RVcmx9fSlcclxuICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAvLyBjb25zb2xlLmxvZyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgY29uc3QgcG9zdERhdGEgPSByZXNwb25zZS5kYXRhLmRhdGE7XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyBcclxuICAgICAgICBwb3N0RGF0YTogcG9zdERhdGEsXHJcbiAgICAgICAgbG9hZGVyOiBmYWxzZVxyXG4gICAgICB9KVxyXG4gICAgfSkuY2F0Y2goZXJyb3IgPT57XHJcbiAgICAgIGNvbnNvbGUubG9nKGVycm9yLnJlc3BvbnNlKTtcclxuICAgICAgdG9hc3QuZXJyb3IoXCJTb21ldGhpbmcgd2VudCB3cm9uZy5cIik7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG5cclxuICByZW5kZXIoKSB7XHJcbiAgICBjb25zdCBtZXRhID0ge1xyXG4gICAgICB0aXRsZTogJ0Jsb2dzIC0gRnVsbFN0YWNrIFdlYiBEZXZlbG9wbWVudHwgQmF5IGFyZWEsIENhbGlmb3JuaWEnLFxyXG4gICAgICBtZXRhOiB7XHJcbiAgICAgICAgY2hhcnNldDogJ3V0Zi04JyxcclxuICAgICAgICAgIG5hbWU6IHtcclxuICAgICAgICAgICAga2V5d29yZHM6ICdXZWIgZGV2ZWxvcG1lbnQgY29tcGFueSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBjb21wYW55LHdlYiBkZXZlbG9wbWVudCBrb2NoaSx3ZWIgZGV2ZWxvcG1lbnQgY29tcGFueSBrb2NoaSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBrb2NoaSx3ZWIgZGV2ZWxvcG1lbnQgY29tcGFueSBrb2NoaSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBrb2NoaSx3ZWIgZGVzaWduIGFuZCBkZXZlbG9wbWVudCBrb2NoaSxmdWxsIHN0YWNrIGRldmVsb3BtZW50IGNvbXBhbnksd29yZHByZXNzIGN1c3RvbWlzYXRpb24gY29tcGFueSBrZXJhbGEsc2hvcGlmeSB0aGVtZSBkZXZlbG9wbWVudCBjb21wYW55IGtlcmFsYSxlY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBrZXJhbGEsd29vY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBrZXJhbGEsd2ViIGRldmVsb3BtZW50IGNvbXBhbnkgQ2FsaWZvcm5pYSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBjYWxpZm9ybmlhLHdvcmRwcmVzcyBkZXZlbG9wbWVudCBjYWxpZm9ybmlhLHdvcmRwcmVzcyBkZXZlbG9wbWVudCBrb2NoaSxzaG9waWZ5IGRldmVsb3BtZW50IGtvY2hpLHNob3BpZnkgZGV2ZWxvcG1lbnQgY2FsaWZvcm5pYSx3b3JkcHJlc3MgY3VzdG9taXNhdGlvbiBjb21wYW55LHNob3BpZnkgdGhlbWUgZGV2ZWxvcG1lbnQgY29tcGFueSxlY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBrb2NoaSxlY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBjYWxpZm9ybmlhJ1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBsb2FkZXIgPSA8ZGl2IGNsYXNzTmFtZT1cImxvYWRlclwiPjxkaXYgY2xhc3NOYW1lPVwic3Bpbm5lclwiPjxkaXY+PC9kaXY+PGRpdj48L2Rpdj48ZGl2PjwvZGl2PjxkaXY+PC9kaXY+PC9kaXY+TG9hZGluZzwvZGl2PjtcclxuICAgIGxldCB7cG9zdERhdGEsIGRhdGF9ID0gdGhpcy5zdGF0ZTtcclxuICAgIGNvbnNvbGUubG9nKGRhdGEpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpbmdsZS1ibG9nLW1haW5cIiBpZD1cInNpbmdsZS1ibG9nLW1haW5cIj5cclxuICAgICAgICA8RG9jdW1lbnRNZXRhIHsuLi5tZXRhfSAvPlxyXG4gICAgICAgIDxIZWFkZXIgdGl0bGU9e2RhdGEudGl0bGV9IGRlc2NyaXB0aW9uPXtkYXRhLmRlc2NyaXB0aW9ufSBrZXl3b3Jkcz17ZGF0YS5rZXl3b3Jkc30+PC9IZWFkZXI+XHJcblxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzPVwiY29udGVudC1jb250YWluZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLWZsdWlkIHNlcnZpY2UtYmcgcC0wIG0tMCBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXJ2aWNlLWJnLXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXJ2aWNlLWJhbm5lci1mcmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGp1c3RpZnktY29udGVudC1jZW50ZXIgc2VydmljZS1iYW5uZXItY29udGVudCBwbC0zIHByLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1sZy02IGNvbC1tZC0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImJyZWFkY3J1bWJzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48TGluayBocmVmPVwiL2Jsb2dcIj5CbG9nczwvTGluaz48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGk+e3Bvc3REYXRhLnRpdGxlfTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyIHRleHQtd2hpdGUgIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYm9sZC1jb250ZW50cyBzZXJ2aWNlLWNvbnRlbnQtYm94IHBsLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFdlIGFyZSBzZWVraW5nIGJyaWxsaWFudCBtaW5kcyB0byBqb2luIG91ciBkeW5hbWljIHRlYW0gYW5kIG1ha2UgaXQgZXZlbiBiZXR0ZXIuPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PiAgXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+IFxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYi1yb3ctMVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLXNtLTEyIGNvbC1tZC04IGNvbC1sZy04XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWxpc3RcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7KHRoaXMuc3RhdGUubG9hZGVyID09IHRydWUpPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cImNhcmQtdGl0bGUgdGV4dC1sZXZlbC00IHRpdGxlLW9yYW5nZVwiPntwb3N0RGF0YS50aXRsZX08L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLW1ldGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsocG9zdERhdGEucHVibGlzaGVkICE9IG51bGwpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGkgY2xhc3NOYW1lPVwiZmEgZmEtY2xvY2stb1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT4ge3Bvc3REYXRhLnB1Ymxpc2hlZH08L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS10aC1sYXJnZVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwb3N0RGF0YS5jYXRlZ29yaWVzLm1hcCgoY2F0LCBpKSA9PiB7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfT57Y2F0Lm5hbWV9IHtpIDwgKHBvc3REYXRhLmNhdGVnb3JpZXMpLmxlbmd0aCAtIDEgPyAnLCAnIDogJyd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWltZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctdGh1bWJcIiBzdHlsZT17e2JhY2tncm91bmRJbWFnZTogKHBvc3REYXRhLmltYWdlID09IG51bGwpID8gJy9pbWFnZXMvYmxvZ3Mvd3JpdGluZy1nb29kLWJsb2cuanBnJyA6IGB1cmwoJHtwb3N0RGF0YS5pbWFnZX0pYCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKnsgKHBvc3REYXRhLmltYWdlID09IG51bGwpID8gPGltZyBzcmM9XCIvaW1hZ2VzL2Jsb2dzL3dyaXRpbmctZ29vZC1ibG9nLmpwZ1wiIGFsdD17cG9zdERhdGEuaW1hZ2VfYWx0fSAvPiA6IDxpbWcgc3JjPXtwb3N0RGF0YS5pbWFnZX0gYWx0PXtwb3N0RGF0YS5pbWFnZV9hbHR9IC8+IH0qL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNtYWxsIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgY2F0IHRleHQtYWJvdmUtbWFpbi10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhcyBmYS11c2VycyB0ZXh0LWluZm9cIj48L2k+IEhhc2h0YWcgc3lzdGVtc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NtYWxsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtdGV4dCBibG9nLWRldGFpbC1wYWdlXCIgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3tfX2h0bWw6IHBvc3REYXRhLmNvbnRlbnR9fT48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qPGRpdiBjbGFzc05hbWU9XCJibG9nLW5hdlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJwcmV2XCI+PGkgY2xhc3NOYW1lPVwiZmEgZmEtYW5nbGUtbGVmdFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT5QcmV2PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJuZXh0XCI+TmV4dDxpIGNsYXNzTmFtZT1cImZhIGZhLWFuZ2xlLXJpZ2h0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPjwvYT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj4qL31cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtc20tMTIgY29sLW1kLTQgY29sLWxnLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXNpZGViYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QmxvZ1JlY2VudFBvc3RzPjwvQmxvZ1JlY2VudFBvc3RzPiAgXHJcbiAgICAgICAgICAgICAgICAgICAgICA8QmxvZ0NhdGVnb3JpZXM+PC9CbG9nQ2F0ZWdvcmllcz4gICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2ItdmlzaWJsZVwiPjwvZGl2PlxyXG4gICAgICAgIDxGb290ZXI+PC9Gb290ZXI+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH1cclxufVxyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vZGlzdC9jbGllbnQvcm91dGVyJylcbiJdLCJzb3VyY2VSb290IjoiIn0=