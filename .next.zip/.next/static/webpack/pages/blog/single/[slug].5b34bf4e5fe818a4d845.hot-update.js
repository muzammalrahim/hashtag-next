self["webpackHotUpdate_N_E"]("pages/blog/single/[slug]",{

/***/ "./pages/blog/single/[slug].jsx":
/*!**************************************!*\
  !*** ./pages/blog/single/[slug].jsx ***!
  \**************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Singlepost; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_header_index_jsx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../components/header/index.jsx */ "./components/header/index.jsx");
/* harmony import */ var _components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/footer/index.jsx */ "./components/footer/index.jsx");
/* harmony import */ var _components_under_construction_index_jsx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/under-construction/index.jsx */ "./components/under-construction/index.jsx");
/* harmony import */ var _components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/post-category/index.jsx */ "./components/post-category/index.jsx");
/* harmony import */ var _components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../components/post-recent/index.jsx */ "./components/post-recent/index.jsx");
/* harmony import */ var react_document_meta__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react-document-meta */ "./node_modules/react-document-meta/dist/index.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../config */ "./config.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_19__);
/* module decorator */ module = __webpack_require__.hmd(module);









var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\pages\\blog\\single\\[slug].jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }















__webpack_require__(/*! typeface-montserrat */ "./node_modules/typeface-montserrat/index.css");

var __N_SSP = true;

var Singlepost = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__.default)(Singlepost, _Component);

  var _super = _createSuper(Singlepost);

  function Singlepost(props) {
    var _this$props, _this$props$match, _this$props$match$par;

    var _this;

    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__.default)(this, Singlepost);

    _this = _super.call(this, props);

    if (false) {}

    var response = _this.props;
    _this.state = {
      data: response.data.data,
      postData: {
        categories: [{
          "name": "",
          "slug": ""
        }]
      },
      postUrl: (_this$props = _this.props) === null || _this$props === void 0 ? void 0 : (_this$props$match = _this$props.match) === null || _this$props$match === void 0 ? void 0 : (_this$props$match$par = _this$props$match.params) === null || _this$props$match$par === void 0 ? void 0 : _this$props$match$par.slug,
      loader: true
    };
    _this.shiftContent = _this.shiftContent.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__.default)(_this));
    return _this;
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__.default)(Singlepost, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.shiftContent();

      if (true) {
        window.addEventListener("resize", this.shiftContent);
      }

      if (window.location.pathname) {
        var pathNames = window.location.pathname.split('/');
        console.log('path', pathNames);
        var singlePost = pathNames[3];
        this.setState({
          postUrl: singlePost
        });
      }

      this.get_postData();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (true) {
        window.removeEventListener("resize", this.shiftContent);
      }
    } //Search div shift

  }, {
    key: "shiftContent",
    value: function shiftContent() {
      if (jquery__WEBPACK_IMPORTED_MODULE_16___default()(".mob-visible").is(":visible")) {
        jquery__WEBPACK_IMPORTED_MODULE_16___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_16___default()('.blog-list'));
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_16___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_16___default()('.widget_recent_entries'));
      }
    } //Get post data

  }, {
    key: "get_postData",
    value: function get_postData() {
      var _this2 = this;

      var postUrl = this.state.postUrl;
      axios__WEBPACK_IMPORTED_MODULE_17___default().get(_config__WEBPACK_IMPORTED_MODULE_18__.myConfig.apiUrl + 'blog/posts/single', {
        params: {
          post_url: postUrl
        }
      }).then(function (response) {
        // console.log(response.data);
        var postData = response.data.data;

        _this2.setState({
          postData: postData,
          loader: false
        });
      })["catch"](function (error) {
        console.log(error.response);
        react_toastify__WEBPACK_IMPORTED_MODULE_20__.toast.error("Something went wrong.");
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _postData$categories,
          _this3 = this;

      var meta = {
        title: 'Blogs - FullStack Web Development| Bay area, California',
        meta: {
          charset: 'utf-8',
          name: {
            keywords: 'Web development company,software development company,web development kochi,web development company kochi,software development kochi,web development company kochi,software development kochi,web design and development kochi,full stack development company,wordpress customisation company kerala,shopify theme development company kerala,ecommerce development company kerala,woocommerce development company kerala,web development company California,software development california,wordpress development california,wordpress development kochi,shopify development kochi,shopify development california,wordpress customisation company,shopify theme development company,ecommerce development company kochi,ecommerce development company california'
          }
        }
      };

      var loader = /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "loader",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "spinner",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 124,
            columnNumber: 69
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 124,
            columnNumber: 80
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 124,
            columnNumber: 91
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 124,
            columnNumber: 102
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 124,
          columnNumber: 44
        }, this), "Loading"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 124,
        columnNumber: 20
      }, this);

      var _this$state = this.state,
          postData = _this$state.postData,
          data = _this$state.data; //console.log(data)

      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "single-blog-main",
        id: "single-blog-main",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_document_meta__WEBPACK_IMPORTED_MODULE_14__.default, _objectSpread({}, meta), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 129,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_header_index_jsx__WEBPACK_IMPORTED_MODULE_9__.default, {
          title: data.title,
          description: data.description,
          keywords: data.keywords
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 130,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
          "class": "content-container",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "container-fluid service-bg p-0 m-0 ",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "service-bg-right",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "service-banner-frame",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "container ",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "row justify-content-center service-banner-content pl-3 pr-3",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                        className: "breadcrumbs",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_19___default()), {
                            href: "/blog",
                            children: "Blogs"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 140,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 140,
                          columnNumber: 25
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: postData.title
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 141,
                          columnNumber: 25
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 139,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 138,
                      columnNumber: 21
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12 text-white  ",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                        className: "bold-contents service-content-box pl-4",
                        children: "We are seeking brilliant minds to join our dynamic team and make it even better."
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 145,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 144,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 137,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 136,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 135,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 134,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 133,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "blog-section",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "container",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "row b-row-1",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-8 col-lg-8",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-wrap",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "blog-list",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "card",
                        children: this.state.loader == true ? loader : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h5", {
                            className: "card-title text-level-4 title-orange",
                            children: postData.title
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 165,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-meta",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                              children: [postData.published != null && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-clock-o",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 169,
                                  columnNumber: 39
                                }, this), " ", postData.published]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 169,
                                columnNumber: 35
                              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-th-large",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 172,
                                  columnNumber: 35
                                }, this), postData === null || postData === void 0 ? void 0 : (_postData$categories = postData.categories) === null || _postData$categories === void 0 ? void 0 : _postData$categories.map(function (cat, i) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                    children: [cat.name, " ", i < postData.categories.length - 1 ? ', ' : '']
                                  }, i, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 175,
                                    columnNumber: 39
                                  }, _this3);
                                })]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 171,
                                columnNumber: 33
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 167,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 166,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-img",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "blog-thumb",
                              style: {
                                backgroundImage: postData.image == null ? '/images/blogs/writing-good-blog.jpg' : "url(".concat(postData.image, ")")
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 182,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 181,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "card-body",
                            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("small", {
                              className: "text-muted cat text-above-main-title",
                              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                className: "fas fa-users text-info"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 188,
                                columnNumber: 33
                              }, this), " Hashtag systems"]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 187,
                              columnNumber: 31
                            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "card-text blog-detail-page",
                              dangerouslySetInnerHTML: {
                                __html: postData.content
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 190,
                              columnNumber: 31
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 186,
                            columnNumber: 29
                          }, this)]
                        }, void 0, true)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 160,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 159,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 158,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 157,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-4 col-lg-4",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-sidebar",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("aside", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_13__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 206,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 207,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 205,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 204,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 203,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 156,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 155,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 154,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 132,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "mob-visible"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 215,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_10__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 216,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 128,
        columnNumber: 7
      }, this);
    }
  }]);

  return Singlepost;
}(react__WEBPACK_IMPORTED_MODULE_8__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYmxvZy9zaW5nbGUvW3NsdWddLmpzeCJdLCJuYW1lcyI6WyJyZXF1aXJlIiwiU2luZ2xlcG9zdCIsInByb3BzIiwicmVzcG9uc2UiLCJzdGF0ZSIsImRhdGEiLCJwb3N0RGF0YSIsImNhdGVnb3JpZXMiLCJwb3N0VXJsIiwibWF0Y2giLCJwYXJhbXMiLCJzbHVnIiwibG9hZGVyIiwic2hpZnRDb250ZW50IiwiYmluZCIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJsb2NhdGlvbiIsInBhdGhuYW1lIiwicGF0aE5hbWVzIiwic3BsaXQiLCJjb25zb2xlIiwibG9nIiwic2luZ2xlUG9zdCIsInNldFN0YXRlIiwiZ2V0X3Bvc3REYXRhIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIiQiLCJpcyIsImluc2VydEJlZm9yZSIsIkF4aW9zIiwiY29uZmlnIiwicG9zdF91cmwiLCJ0aGVuIiwiZXJyb3IiLCJ0b2FzdCIsIm1ldGEiLCJ0aXRsZSIsImNoYXJzZXQiLCJuYW1lIiwia2V5d29yZHMiLCJkZXNjcmlwdGlvbiIsInB1Ymxpc2hlZCIsIm1hcCIsImNhdCIsImkiLCJsZW5ndGgiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJpbWFnZSIsIl9faHRtbCIsImNvbnRlbnQiLCJDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQUEsbUJBQU8sQ0FBQyx5RUFBRCxDQUFQOzs7O0lBMEJxQkMsVTs7Ozs7QUFHbkIsc0JBQVlDLEtBQVosRUFBbUI7QUFBQTs7QUFBQTs7QUFBQTs7QUFDakIsOEJBQU1BLEtBQU47O0FBQ0osZUFBbUMsRUFFOUI7O0FBQ0QsUUFBSUMsUUFBUSxHQUFHLE1BQUtELEtBQXBCO0FBQ0EsVUFBS0UsS0FBTCxHQUFhO0FBQ1hDLFVBQUksRUFBR0YsUUFBUSxDQUFDRSxJQUFULENBQWNBLElBRFY7QUFFWEMsY0FBUSxFQUFFO0FBQ1JDLGtCQUFVLEVBQUUsQ0FBQztBQUFDLGtCQUFPLEVBQVI7QUFBVyxrQkFBUTtBQUFuQixTQUFEO0FBREosT0FGQztBQUtYQyxhQUFPLGlCQUFFLE1BQUtOLEtBQVAscUVBQUUsWUFBWU8sS0FBZCwrRUFBRSxrQkFBbUJDLE1BQXJCLDBEQUFFLHNCQUEyQkMsSUFMekI7QUFNWEMsWUFBTSxFQUFFO0FBTkcsS0FBYjtBQVNBLFVBQUtDLFlBQUwsR0FBb0IsTUFBS0EsWUFBTCxDQUFrQkMsSUFBbEIseUlBQXBCO0FBZmlCO0FBaUJsQjs7Ozt3Q0FHbUI7QUFDbEIsV0FBS0QsWUFBTDs7QUFDQSxnQkFBK0I7QUFDN0JFLGNBQU0sQ0FBQ0MsZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0MsS0FBS0gsWUFBdkM7QUFDRDs7QUFDRCxVQUFJRSxNQUFNLENBQUNFLFFBQVAsQ0FBZ0JDLFFBQXBCLEVBQThCO0FBQzVCLFlBQUlDLFNBQVMsR0FBR0osTUFBTSxDQUFDRSxRQUFQLENBQWdCQyxRQUFoQixDQUF5QkUsS0FBekIsQ0FBK0IsR0FBL0IsQ0FBaEI7QUFDQUMsZUFBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFvQkgsU0FBcEI7QUFDQSxZQUFJSSxVQUFVLEdBQUdKLFNBQVMsQ0FBQyxDQUFELENBQTFCO0FBQ0EsYUFBS0ssUUFBTCxDQUFjO0FBQUVoQixpQkFBTyxFQUFHZTtBQUFaLFNBQWQ7QUFDRDs7QUFDRCxXQUFLRSxZQUFMO0FBQ0Q7OzsyQ0FFc0I7QUFDckIsZ0JBQWlDO0FBQy9CVixjQUFNLENBQUNXLG1CQUFQLENBQTJCLFFBQTNCLEVBQXFDLEtBQUtiLFlBQTFDO0FBQ0Q7QUFDRixLLENBRUQ7Ozs7bUNBQ2M7QUFDWixVQUFHYyw4Q0FBQyxDQUFDLGNBQUQsQ0FBRCxDQUFrQkMsRUFBbEIsQ0FBcUIsVUFBckIsQ0FBSCxFQUFxQztBQUNuQ0Qsc0RBQUMsQ0FBQyxnQkFBRCxDQUFELENBQW9CRSxZQUFwQixDQUFpQ0YsOENBQUMsQ0FBQyxZQUFELENBQWxDO0FBQ0QsT0FGRCxNQUdLO0FBQ0hBLHNEQUFDLENBQUMsZ0JBQUQsQ0FBRCxDQUFvQkUsWUFBcEIsQ0FBaUNGLDhDQUFDLENBQUMsd0JBQUQsQ0FBbEM7QUFDRDtBQUNGLEssQ0FFRDs7OzttQ0FDYztBQUFBOztBQUNaLFVBQUluQixPQUFPLEdBQUcsS0FBS0osS0FBTCxDQUFXSSxPQUF6QjtBQUNBc0IsdURBQUEsQ0FBVUMscURBQUEsR0FBdUIsbUJBQWpDLEVBQXNEO0FBQUNyQixjQUFNLEVBQUU7QUFBQ3NCLGtCQUFRLEVBQUV4QjtBQUFYO0FBQVQsT0FBdEQsRUFDQ3lCLElBREQsQ0FDTSxVQUFDOUIsUUFBRCxFQUFjO0FBQ2xCO0FBQ0EsWUFBTUcsUUFBUSxHQUFHSCxRQUFRLENBQUNFLElBQVQsQ0FBY0EsSUFBL0I7O0FBQ0EsY0FBSSxDQUFDbUIsUUFBTCxDQUFjO0FBQ1psQixrQkFBUSxFQUFFQSxRQURFO0FBRVpNLGdCQUFNLEVBQUU7QUFGSSxTQUFkO0FBSUQsT0FSRCxXQVFTLFVBQUFzQixLQUFLLEVBQUc7QUFDZmIsZUFBTyxDQUFDQyxHQUFSLENBQVlZLEtBQUssQ0FBQy9CLFFBQWxCO0FBQ0FnQyxnRUFBQSxDQUFZLHVCQUFaO0FBQ0QsT0FYRDtBQVlEOzs7NkJBR1E7QUFBQTtBQUFBOztBQUNQLFVBQU1DLElBQUksR0FBRztBQUNYQyxhQUFLLEVBQUUseURBREk7QUFFWEQsWUFBSSxFQUFFO0FBQ0pFLGlCQUFPLEVBQUUsT0FETDtBQUVGQyxjQUFJLEVBQUU7QUFDSkMsb0JBQVEsRUFBRTtBQUROO0FBRko7QUFGSyxPQUFiOztBQVVBLFVBQU01QixNQUFNLGdCQUFHO0FBQUssaUJBQVMsRUFBQyxRQUFmO0FBQUEsZ0NBQXdCO0FBQUssbUJBQVMsRUFBQyxTQUFmO0FBQUEsa0NBQXlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQXpCLGVBQW9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQXBDLGVBQStDO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQS9DLGVBQTBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQWY7O0FBWE8sd0JBWWdCLEtBQUtSLEtBWnJCO0FBQUEsVUFZRkUsUUFaRSxlQVlGQSxRQVpFO0FBQUEsVUFZUUQsSUFaUixlQVlRQSxJQVpSLEVBYVA7O0FBQ0EsMEJBQ0U7QUFBSyxpQkFBUyxFQUFDLGtCQUFmO0FBQWtDLFVBQUUsRUFBQyxrQkFBckM7QUFBQSxnQ0FDRSw4REFBQyx5REFBRCxvQkFBa0IrQixJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUsOERBQUMsaUVBQUQ7QUFBUSxlQUFLLEVBQUUvQixJQUFJLENBQUNnQyxLQUFwQjtBQUEyQixxQkFBVyxFQUFFaEMsSUFBSSxDQUFDb0MsV0FBN0M7QUFBMEQsa0JBQVEsRUFBRXBDLElBQUksQ0FBQ21DO0FBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkYsZUFJRTtBQUFTLG1CQUFNLG1CQUFmO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLHFDQUFmO0FBQUEsbUNBQ0U7QUFBSyx1QkFBUyxFQUFDLGtCQUFmO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLHNCQUFmO0FBQUEsdUNBQ0U7QUFBSywyQkFBUyxFQUFDLFlBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsNkRBQWY7QUFBQSw0Q0FDRTtBQUFLLCtCQUFTLEVBQUMsb0JBQWY7QUFBQSw2Q0FDRTtBQUFJLGlDQUFTLEVBQUMsYUFBZDtBQUFBLGdEQUNFO0FBQUEsaURBQUksOERBQUMsbURBQUQ7QUFBTSxnQ0FBSSxFQUFDLE9BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBRUU7QUFBQSxvQ0FBS2xDLFFBQVEsQ0FBQytCO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQURGLGVBT0U7QUFBSywrQkFBUyxFQUFDLGlDQUFmO0FBQUEsNkNBQ0U7QUFBRyxpQ0FBUyxFQUFDLHdDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBc0JFO0FBQUsscUJBQVMsRUFBQyxjQUFmO0FBQUEsbUNBQ0U7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSxxQ0FDRTtBQUFLLHlCQUFTLEVBQUMsYUFBZjtBQUFBLHdDQUNFO0FBQUssMkJBQVMsRUFBQyxvQ0FBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxXQUFmO0FBQUEsMkNBQ0U7QUFBSywrQkFBUyxFQUFDLFdBQWY7QUFBQSw2Q0FDRTtBQUFLLGlDQUFTLEVBQUMsTUFBZjtBQUFBLGtDQUNJLEtBQUtqQyxLQUFMLENBQVdRLE1BQVgsSUFBcUIsSUFBdEIsR0FDQ0EsTUFERCxnQkFHQztBQUFBLGtEQUNFO0FBQUkscUNBQVMsRUFBQyxzQ0FBZDtBQUFBLHNDQUFzRE4sUUFBUSxDQUFDK0I7QUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FERixlQUVFO0FBQUsscUNBQVMsRUFBQyxXQUFmO0FBQUEsbURBQ0U7QUFBQSx5Q0FDSS9CLFFBQVEsQ0FBQ29DLFNBQVQsSUFBc0IsSUFBdkIsaUJBQ0M7QUFBQSx3REFBSTtBQUFHLDJDQUFTLEVBQUMsZUFBYjtBQUE2QixpREFBWTtBQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHdDQUFKLE9BQTBEcEMsUUFBUSxDQUFDb0MsU0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNDQUZKLGVBSUU7QUFBQSx3REFDRTtBQUFHLDJDQUFTLEVBQUMsZ0JBQWI7QUFBOEIsaURBQVk7QUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx3Q0FERixFQUVHcEMsUUFGSCxhQUVHQSxRQUZILCtDQUVHQSxRQUFRLENBQUVDLFVBRmIseURBRUcscUJBQXNCb0MsR0FBdEIsQ0FBMEIsVUFBQ0MsR0FBRCxFQUFNQyxDQUFOLEVBQVk7QUFDckMsc0RBQ0U7QUFBQSwrQ0FBZUQsR0FBRyxDQUFDTCxJQUFuQixPQUEwQk0sQ0FBQyxHQUFJdkMsUUFBUSxDQUFDQyxVQUFWLENBQXNCdUMsTUFBdEIsR0FBK0IsQ0FBbkMsR0FBdUMsSUFBdkMsR0FBOEMsRUFBeEU7QUFBQSxxQ0FBV0QsQ0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRDQURGO0FBR0QsaUNBSkEsQ0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0NBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FGRixlQWlCRTtBQUFLLHFDQUFTLEVBQUMsVUFBZjtBQUFBLG1EQUNFO0FBQUssdUNBQVMsRUFBQyxZQUFmO0FBQTRCLG1DQUFLLEVBQUU7QUFBQ0UsK0NBQWUsRUFBR3pDLFFBQVEsQ0FBQzBDLEtBQVQsSUFBa0IsSUFBbkIsR0FBMkIscUNBQTNCLGlCQUEwRTFDLFFBQVEsQ0FBQzBDLEtBQW5GO0FBQWxCO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQWpCRixlQXNCRTtBQUFLLHFDQUFTLEVBQUMsV0FBZjtBQUFBLG9EQUNFO0FBQU8sdUNBQVMsRUFBQyxzQ0FBakI7QUFBQSxzREFDRTtBQUFHLHlDQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNDQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FERixlQUlFO0FBQUssdUNBQVMsRUFBQyw0QkFBZjtBQUE0QyxxREFBdUIsRUFBRTtBQUFDQyxzQ0FBTSxFQUFFM0MsUUFBUSxDQUFDNEM7QUFBbEI7QUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBdEJGO0FBQUE7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBK0NFO0FBQUssMkJBQVMsRUFBQyxvQ0FBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxjQUFmO0FBQUEsMkNBQ0U7QUFBQSw4Q0FDRSw4REFBQyx1RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURGLGVBRUUsOERBQUMseUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRixlQXVGRTtBQUFLLG1CQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXZGRixlQXdGRSw4REFBQyxrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERjtBQTRGRDs7OztFQWpMcUNDLDRDIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2Jsb2cvc2luZ2xlL1tzbHVnXS41YjM0YmY0ZTVmZTgxOGE0ZDg0NS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEhlYWRlciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2hlYWRlci9pbmRleC5qc3gnO1xyXG5pbXBvcnQgRm9vdGVyIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvZm9vdGVyL2luZGV4LmpzeCc7XHJcbmltcG9ydCBVbmRlcmNvbnN0cnVjdGlvbiBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VuZGVyLWNvbnN0cnVjdGlvbi9pbmRleC5qc3gnO1xyXG5pbXBvcnQgQmxvZ0NhdGVnb3JpZXMgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9wb3N0LWNhdGVnb3J5L2luZGV4LmpzeCc7XHJcbmltcG9ydCBCbG9nUmVjZW50UG9zdHMgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9wb3N0LXJlY2VudC9pbmRleC5qc3gnO1xyXG5pbXBvcnQgRG9jdW1lbnRNZXRhIGZyb20gJ3JlYWN0LWRvY3VtZW50LW1ldGEnO1xyXG5pbXBvcnQgeyBUb2FzdENvbnRhaW5lciwgdG9hc3QsIFNsaWRlIH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xyXG5pbXBvcnQgJ3JlYWN0LXRvYXN0aWZ5L2Rpc3QvUmVhY3RUb2FzdGlmeS5jc3MnO1xyXG5pbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5pbXBvcnQgQXhpb3MgZnJvbSAnYXhpb3MnO1xyXG5pbXBvcnQgaHR0cHMgZnJvbSBcImh0dHBzXCI7XHJcbmltcG9ydCAqIGFzIGNvbmZpZyBmcm9tICcuLi8uLi8uLi9jb25maWcnO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcblxyXG5yZXF1aXJlKCd0eXBlZmFjZS1tb250c2VycmF0JylcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoKSB7XHJcbiAgbGV0IGRhdGEgPSBbXTtcclxuXHJcbiAgY29uc3QgaW5zdGFuY2UgPSBBeGlvcy5jcmVhdGUoe1xyXG4gICAgaHR0cHNBZ2VudDogbmV3IGh0dHBzLkFnZW50KHtcclxuICAgICAgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZSxcclxuICAgIH0pLFxyXG4gIH0pO1xyXG5cclxuICBhd2FpdCBpbnN0YW5jZVxyXG4gICAgLmdldChcImh0dHBzOi8vYXBpLmhhc2h0YWctY2EuY29tL2FwaS92MS9tZXRhZGF0YVwiLCB7XHJcbiAgICAgIHBhcmFtczoge1xyXG4gICAgICAgIHBhZ2VfdHlwZTogXCJzdGF0aWNcIixcclxuICAgICAgICBzbHVnOiBcInNldmljZXNcIixcclxuICAgICAgfSxcclxuICAgIH0pXHJcbiAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgZGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgICB9KTtcclxuICByZXR1cm4ge1xyXG4gICAgcHJvcHM6IHsgZGF0YSB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNpbmdsZXBvc3QgZXh0ZW5kcyBDb21wb25lbnQge1xyXG5cclxuXHJcbiAgY29uc3RydWN0b3IocHJvcHMpIHtcclxuICAgIHN1cGVyKHByb3BzKTtcclxuaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHtcclxuICBnbG9iYWwud2luZG93ID0ge307XHJcbiAgICB9XHJcbiAgICBsZXQgcmVzcG9uc2UgPSB0aGlzLnByb3BzXHJcbiAgICB0aGlzLnN0YXRlID0ge1xyXG4gICAgICBkYXRhIDogcmVzcG9uc2UuZGF0YS5kYXRhLFxyXG4gICAgICBwb3N0RGF0YToge1xyXG4gICAgICAgIGNhdGVnb3JpZXM6IFt7XCJuYW1lXCI6XCJcIixcInNsdWdcIjogXCJcIn1dXHJcbiAgICAgIH0sXHJcbiAgICAgIHBvc3RVcmw6IHRoaXMucHJvcHM/Lm1hdGNoPy5wYXJhbXM/LnNsdWcsXHJcbiAgICAgIGxvYWRlcjogdHJ1ZVxyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLnNoaWZ0Q29udGVudCA9IHRoaXMuc2hpZnRDb250ZW50LmJpbmQodGhpcyk7XHJcbiAgICBcclxuICB9XHJcblxyXG5cclxuICBjb21wb25lbnREaWRNb3VudCgpIHtcclxuICAgIHRoaXMuc2hpZnRDb250ZW50KCk7XHJcbiAgICBpZih0eXBlb2Ygd2luZG93ICE9PSB1bmRlZmluZWQpe1xyXG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCB0aGlzLnNoaWZ0Q29udGVudCk7XHJcbiAgICB9XHJcbiAgICBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lKSB7XHJcbiAgICAgIGxldCBwYXRoTmFtZXMgPSB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUuc3BsaXQoJy8nKTtcclxuICAgICAgY29uc29sZS5sb2coJ3BhdGgnLCBwYXRoTmFtZXMpO1xyXG4gICAgICBsZXQgc2luZ2xlUG9zdCA9IHBhdGhOYW1lc1szXTtcclxuICAgICAgdGhpcy5zZXRTdGF0ZSh7IHBvc3RVcmwgOiBzaW5nbGVQb3N0fSk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmdldF9wb3N0RGF0YSgpO1xyXG4gIH1cclxuXHJcbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHRoaXMuc2hpZnRDb250ZW50KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vU2VhcmNoIGRpdiBzaGlmdFxyXG4gIHNoaWZ0Q29udGVudCgpe1xyXG4gICAgaWYoJChcIi5tb2ItdmlzaWJsZVwiKS5pcyhcIjp2aXNpYmxlXCIpKSB7IFxyXG4gICAgICAkKCcud2lkZ2V0X3NlYXJjaCcpLmluc2VydEJlZm9yZSgkKCcuYmxvZy1saXN0JykpO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgICQoJy53aWRnZXRfc2VhcmNoJykuaW5zZXJ0QmVmb3JlKCQoJy53aWRnZXRfcmVjZW50X2VudHJpZXMnKSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvL0dldCBwb3N0IGRhdGFcclxuICBnZXRfcG9zdERhdGEoKXtcclxuICAgIGxldCBwb3N0VXJsID0gdGhpcy5zdGF0ZS5wb3N0VXJsO1xyXG4gICAgQXhpb3MuZ2V0KGNvbmZpZy5teUNvbmZpZy5hcGlVcmwrJ2Jsb2cvcG9zdHMvc2luZ2xlJywge3BhcmFtczoge3Bvc3RfdXJsOiBwb3N0VXJsfX0pXHJcbiAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgLy8gY29uc29sZS5sb2cocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIGNvbnN0IHBvc3REYXRhID0gcmVzcG9uc2UuZGF0YS5kYXRhO1xyXG4gICAgICB0aGlzLnNldFN0YXRlKHsgXHJcbiAgICAgICAgcG9zdERhdGE6IHBvc3REYXRhLFxyXG4gICAgICAgIGxvYWRlcjogZmFsc2VcclxuICAgICAgfSlcclxuICAgIH0pLmNhdGNoKGVycm9yID0+e1xyXG4gICAgICBjb25zb2xlLmxvZyhlcnJvci5yZXNwb25zZSk7XHJcbiAgICAgIHRvYXN0LmVycm9yKFwiU29tZXRoaW5nIHdlbnQgd3JvbmcuXCIpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuXHJcbiAgcmVuZGVyKCkge1xyXG4gICAgY29uc3QgbWV0YSA9IHtcclxuICAgICAgdGl0bGU6ICdCbG9ncyAtIEZ1bGxTdGFjayBXZWIgRGV2ZWxvcG1lbnR8IEJheSBhcmVhLCBDYWxpZm9ybmlhJyxcclxuICAgICAgbWV0YToge1xyXG4gICAgICAgIGNoYXJzZXQ6ICd1dGYtOCcsXHJcbiAgICAgICAgICBuYW1lOiB7XHJcbiAgICAgICAgICAgIGtleXdvcmRzOiAnV2ViIGRldmVsb3BtZW50IGNvbXBhbnksc29mdHdhcmUgZGV2ZWxvcG1lbnQgY29tcGFueSx3ZWIgZGV2ZWxvcG1lbnQga29jaGksd2ViIGRldmVsb3BtZW50IGNvbXBhbnkga29jaGksc29mdHdhcmUgZGV2ZWxvcG1lbnQga29jaGksd2ViIGRldmVsb3BtZW50IGNvbXBhbnkga29jaGksc29mdHdhcmUgZGV2ZWxvcG1lbnQga29jaGksd2ViIGRlc2lnbiBhbmQgZGV2ZWxvcG1lbnQga29jaGksZnVsbCBzdGFjayBkZXZlbG9wbWVudCBjb21wYW55LHdvcmRwcmVzcyBjdXN0b21pc2F0aW9uIGNvbXBhbnkga2VyYWxhLHNob3BpZnkgdGhlbWUgZGV2ZWxvcG1lbnQgY29tcGFueSBrZXJhbGEsZWNvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkga2VyYWxhLHdvb2NvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkga2VyYWxhLHdlYiBkZXZlbG9wbWVudCBjb21wYW55IENhbGlmb3JuaWEsc29mdHdhcmUgZGV2ZWxvcG1lbnQgY2FsaWZvcm5pYSx3b3JkcHJlc3MgZGV2ZWxvcG1lbnQgY2FsaWZvcm5pYSx3b3JkcHJlc3MgZGV2ZWxvcG1lbnQga29jaGksc2hvcGlmeSBkZXZlbG9wbWVudCBrb2NoaSxzaG9waWZ5IGRldmVsb3BtZW50IGNhbGlmb3JuaWEsd29yZHByZXNzIGN1c3RvbWlzYXRpb24gY29tcGFueSxzaG9waWZ5IHRoZW1lIGRldmVsb3BtZW50IGNvbXBhbnksZWNvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkga29jaGksZWNvbW1lcmNlIGRldmVsb3BtZW50IGNvbXBhbnkgY2FsaWZvcm5pYSdcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgbG9hZGVyID0gPGRpdiBjbGFzc05hbWU9XCJsb2FkZXJcIj48ZGl2IGNsYXNzTmFtZT1cInNwaW5uZXJcIj48ZGl2PjwvZGl2PjxkaXY+PC9kaXY+PGRpdj48L2Rpdj48ZGl2PjwvZGl2PjwvZGl2PkxvYWRpbmc8L2Rpdj47XHJcbiAgICBsZXQge3Bvc3REYXRhLCBkYXRhfSA9IHRoaXMuc3RhdGU7XHJcbiAgICAvL2NvbnNvbGUubG9nKGRhdGEpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpbmdsZS1ibG9nLW1haW5cIiBpZD1cInNpbmdsZS1ibG9nLW1haW5cIj5cclxuICAgICAgICA8RG9jdW1lbnRNZXRhIHsuLi5tZXRhfSAvPlxyXG4gICAgICAgIDxIZWFkZXIgdGl0bGU9e2RhdGEudGl0bGV9IGRlc2NyaXB0aW9uPXtkYXRhLmRlc2NyaXB0aW9ufSBrZXl3b3Jkcz17ZGF0YS5rZXl3b3Jkc30+PC9IZWFkZXI+XHJcblxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzPVwiY29udGVudC1jb250YWluZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLWZsdWlkIHNlcnZpY2UtYmcgcC0wIG0tMCBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXJ2aWNlLWJnLXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXJ2aWNlLWJhbm5lci1mcmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGp1c3RpZnktY29udGVudC1jZW50ZXIgc2VydmljZS1iYW5uZXItY29udGVudCBwbC0zIHByLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1sZy02IGNvbC1tZC0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImJyZWFkY3J1bWJzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48TGluayBocmVmPVwiL2Jsb2dcIj5CbG9nczwvTGluaz48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGk+e3Bvc3REYXRhLnRpdGxlfTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyIHRleHQtd2hpdGUgIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYm9sZC1jb250ZW50cyBzZXJ2aWNlLWNvbnRlbnQtYm94IHBsLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFdlIGFyZSBzZWVraW5nIGJyaWxsaWFudCBtaW5kcyB0byBqb2luIG91ciBkeW5hbWljIHRlYW0gYW5kIG1ha2UgaXQgZXZlbiBiZXR0ZXIuPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PiAgXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+IFxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgYi1yb3ctMVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLXNtLTEyIGNvbC1tZC04IGNvbC1sZy04XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWxpc3RcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7KHRoaXMuc3RhdGUubG9hZGVyID09IHRydWUpPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cImNhcmQtdGl0bGUgdGV4dC1sZXZlbC00IHRpdGxlLW9yYW5nZVwiPntwb3N0RGF0YS50aXRsZX08L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLW1ldGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsocG9zdERhdGEucHVibGlzaGVkICE9IG51bGwpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGkgY2xhc3NOYW1lPVwiZmEgZmEtY2xvY2stb1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT4ge3Bvc3REYXRhLnB1Ymxpc2hlZH08L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS10aC1sYXJnZVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwb3N0RGF0YT8uY2F0ZWdvcmllcz8ubWFwKChjYXQsIGkpID0+IHsgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2l9PntjYXQubmFtZX0ge2kgPCAocG9zdERhdGEuY2F0ZWdvcmllcykubGVuZ3RoIC0gMSA/ICcsICcgOiAnJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctaW1nXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy10aHVtYlwiIHN0eWxlPXt7YmFja2dyb3VuZEltYWdlOiAocG9zdERhdGEuaW1hZ2UgPT0gbnVsbCkgPyAnL2ltYWdlcy9ibG9ncy93cml0aW5nLWdvb2QtYmxvZy5qcGcnIDogYHVybCgke3Bvc3REYXRhLmltYWdlfSlgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qeyAocG9zdERhdGEuaW1hZ2UgPT0gbnVsbCkgPyA8aW1nIHNyYz1cIi9pbWFnZXMvYmxvZ3Mvd3JpdGluZy1nb29kLWJsb2cuanBnXCIgYWx0PXtwb3N0RGF0YS5pbWFnZV9hbHR9IC8+IDogPGltZyBzcmM9e3Bvc3REYXRhLmltYWdlfSBhbHQ9e3Bvc3REYXRhLmltYWdlX2FsdH0gLz4gfSovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c21hbGwgY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBjYXQgdGV4dC1hYm92ZS1tYWluLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXVzZXJzIHRleHQtaW5mb1wiPjwvaT4gSGFzaHRhZyBzeXN0ZW1zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc21hbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC10ZXh0IGJsb2ctZGV0YWlsLXBhZ2VcIiBkYW5nZXJvdXNseVNldElubmVySFRNTD17e19faHRtbDogcG9zdERhdGEuY29udGVudH19PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7Lyo8ZGl2IGNsYXNzTmFtZT1cImJsb2ctbmF2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInByZXZcIj48aSBjbGFzc05hbWU9XCJmYSBmYS1hbmdsZS1sZWZ0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPlByZXY8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cIm5leHRcIj5OZXh0PGkgY2xhc3NOYW1lPVwiZmEgZmEtYW5nbGUtcmlnaHRcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48L2k+PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PiovfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1zbS0xMiBjb2wtbWQtNCBjb2wtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctc2lkZWJhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhc2lkZT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCbG9nUmVjZW50UG9zdHM+PC9CbG9nUmVjZW50UG9zdHM+ICBcclxuICAgICAgICAgICAgICAgICAgICAgIDxCbG9nQ2F0ZWdvcmllcz48L0Jsb2dDYXRlZ29yaWVzPiAgICBcclxuICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vYi12aXNpYmxlXCI+PC9kaXY+XHJcbiAgICAgICAgPEZvb3Rlcj48L0Zvb3Rlcj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=