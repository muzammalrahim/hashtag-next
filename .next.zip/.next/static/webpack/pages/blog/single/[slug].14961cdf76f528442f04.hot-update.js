self["webpackHotUpdate_N_E"]("pages/blog/single/[slug]",{

/***/ "./components/under-construction/index.jsx":
/*!*************************************************!*\
  !*** ./components/under-construction/index.jsx ***!
  \*************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Underconstruction; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* module decorator */ module = __webpack_require__.hmd(module);






var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\components\\under-construction\\index.jsx";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

 // import { HashLink as Link } from 'react-router-hash-link';
// import { NavHashLink as NavLink } from 'react-router-hash-link';
// import './style.css';

var Underconstruction = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__.default)(Underconstruction, _Component);

  var _super = _createSuper(Underconstruction);

  function Underconstruction() {
    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__.default)(this, Underconstruction);

    return _super.apply(this, arguments);
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__.default)(Underconstruction, [{
    key: "render",
    value: function render() {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "construction-main",
        id: "construction-main",
        children: ["  ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("main", {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: 100,
            height: 70,
            viewBox: "0 0 100 68",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("g", {
              id: "large",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
                fill: "none",
                stroke: "#F44",
                d: "M55.8 38.5l6.2-1.2c0-1.8-.1-3.5-.4-5.3l-6.3-.2c-.5-2-1.2-4-2.1-6l4.8-4c-.9-1.6-1.9-3-3-4.4l-5.6 3c-1.3-1.6-3-3-4.7-4.1l2-6A30 30 0 0 0 42 8l-3.3 5.4c-2-.7-4.2-1-6.2-1.2L31.3 6c-1.8 0-3.5.1-5.3.4l-.2 6.3c-2 .5-4 1.2-6 2.1l-4-4.8c-1.6.9-3 1.9-4.4 3l3 5.6c-1.6 1.3-3 3-4.1 4.7l-6-2A32.5 32.5 0 0 0 2 26l5.4 3.3c-.7 2-1 4.2-1.2 6.2L0 36.7c0 1.8.1 3.5.4 5.3l6.3.2c.5 2 1.2 4 2.1 6l-4.8 4c.9 1.6 1.9 3 3 4.4l5.6-3c1.4 1.6 3 3 4.7 4.1l-2 6A30.5 30.5 0 0 0 20 66l3.4-5.4c2 .7 4 1 6.1 1.2l1.2 6.2c1.8 0 3.5-.1 5.3-.4l.2-6.3c2-.5 4-1.2 6-2.1l4 4.8c1.6-.9 3-1.9 4.4-3l-3-5.6c1.6-1.3 3-3 4.1-4.7l6 2A32 32 0 0 0 60 48l-5.4-3.3c.7-2 1-4.2 1.2-6.2zm-13.5 4a12.5 12.5 0 1 1-22.6-11 12.5 12.5 0 0 1 22.6 11z"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 22,
                columnNumber: 15
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("animateTransform", {
                attributeName: "transform",
                begin: "0s",
                dur: "3s",
                from: "0 31 37",
                repeatCount: "indefinite",
                to: "360 31 37",
                type: "rotate"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 15
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 13
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("g", {
              id: "small",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
                fill: "none",
                stroke: "#F44",
                d: "M93 19.3l6-3c-.4-1.6-1-3.2-1.7-4.8L90.8 13c-.9-1.4-2-2.7-3.4-3.8l2.1-6.3A21.8 21.8 0 0 0 85 .7l-3.6 5.5c-1.7-.4-3.4-.5-5.1-.3l-3-5.9c-1.6.4-3.2 1-4.7 1.7L70 8c-1.5 1-2.8 2-3.9 3.5L60 9.4a20.6 20.6 0 0 0-2.2 4.6l5.5 3.6a15 15 0 0 0-.3 5.1l-5.9 3c.4 1.6 1 3.2 1.7 4.7L65 29c1 1.5 2.1 2.8 3.5 3.9l-2.1 6.3a21 21 0 0 0 4.5 2.2l3.6-5.6c1.7.4 3.5.5 5.2.3l2.9 5.9c1.6-.4 3.2-1 4.8-1.7L86 34c1.4-1 2.7-2.1 3.8-3.5l6.3 2.1a21.5 21.5 0 0 0 2.2-4.5l-5.6-3.6c.4-1.7.5-3.5.3-5.1zM84.5 24a7 7 0 1 1-12.8-6.2 7 7 0 0 1 12.8 6.2z"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 26,
                columnNumber: 15
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("animateTransform", {
                attributeName: "transform",
                begin: "0s",
                dur: "2s",
                from: "0 78 21",
                repeatCount: "indefinite",
                to: "-360 78 21",
                type: "rotate"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 27,
                columnNumber: 15
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 13
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
            "class": "main-title banner-main-title text-center",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
              "class": "mobile-white title-orange",
              children: "Under Maintenance"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 30,
              columnNumber: 64
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 61
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 1
      }, this);
    }
  }]);

  return Underconstruction;
}(react__WEBPACK_IMPORTED_MODULE_6__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ }),

/***/ "./pages/blog/single/[slug].jsx":
/*!**************************************!*\
  !*** ./pages/blog/single/[slug].jsx ***!
  \**************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Singlepost; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_header_index_jsx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../components/header/index.jsx */ "./components/header/index.jsx");
/* harmony import */ var _components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../components/footer/index.jsx */ "./components/footer/index.jsx");
/* harmony import */ var _components_under_construction_index_jsx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/under-construction/index.jsx */ "./components/under-construction/index.jsx");
/* harmony import */ var _components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/post-category/index.jsx */ "./components/post-category/index.jsx");
/* harmony import */ var _components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../components/post-recent/index.jsx */ "./components/post-recent/index.jsx");
/* harmony import */ var react_document_meta__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react-document-meta */ "./node_modules/react-document-meta/dist/index.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../config */ "./config.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_19__);
/* module decorator */ module = __webpack_require__.hmd(module);









var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\pages\\blog\\single\\[slug].jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }















__webpack_require__(/*! typeface-montserrat */ "./node_modules/typeface-montserrat/index.css");

var __N_SSP = true;

var Singlepost = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__.default)(Singlepost, _Component);

  var _super = _createSuper(Singlepost);

  function Singlepost(props) {
    var _this;

    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__.default)(this, Singlepost);

    _this = _super.call(this, props);

    if (false) {}

    var response = _this.props;
    _this.state = {
      data: response.data.data,
      postData: {
        categories: [{
          "name": "",
          "slug": ""
        }]
      },
      postUrl: _this.props.match.params.slug,
      loader: true
    };
    _this.shiftContent = _this.shiftContent.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__.default)(_this));
    return _this;
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__.default)(Singlepost, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.shiftContent();

      if (true) {
        window.addEventListener("resize", this.shiftContent);
      }

      this.get_postData();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (true) {
        window.removeEventListener("resize", this.shiftContent);
      }
    } //Search div shift

  }, {
    key: "shiftContent",
    value: function shiftContent() {
      if (jquery__WEBPACK_IMPORTED_MODULE_16___default()(".mob-visible").is(":visible")) {
        jquery__WEBPACK_IMPORTED_MODULE_16___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_16___default()('.blog-list'));
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_16___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_16___default()('.widget_recent_entries'));
      }
    } //Get post data

  }, {
    key: "get_postData",
    value: function get_postData() {
      var _this2 = this;

      var postUrl = this.state.postUrl;
      axios__WEBPACK_IMPORTED_MODULE_17___default().get(_config__WEBPACK_IMPORTED_MODULE_18__.myConfig.apiUrl + 'blog/posts/single', {
        params: {
          post_url: postUrl
        }
      }).then(function (response) {
        // console.log(response.data);
        var postData = response.data.data;

        _this2.setState({
          postData: postData,
          loader: false
        });
      })["catch"](function (error) {
        console.log(error.response);
        react_toastify__WEBPACK_IMPORTED_MODULE_20__.toast.error("Something went wrong.");
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var meta = {
        title: 'Blogs - FullStack Web Development| Bay area, California',
        meta: {
          charset: 'utf-8',
          name: {
            keywords: 'Web development company,software development company,web development kochi,web development company kochi,software development kochi,web development company kochi,software development kochi,web design and development kochi,full stack development company,wordpress customisation company kerala,shopify theme development company kerala,ecommerce development company kerala,woocommerce development company kerala,web development company California,software development california,wordpress development california,wordpress development kochi,shopify development kochi,shopify development california,wordpress customisation company,shopify theme development company,ecommerce development company kochi,ecommerce development company california'
          }
        }
      };

      var loader = /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "loader",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "spinner",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 118,
            columnNumber: 69
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 118,
            columnNumber: 80
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 118,
            columnNumber: 91
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 118,
            columnNumber: 102
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 118,
          columnNumber: 44
        }, this), "Loading"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 118,
        columnNumber: 20
      }, this);

      var _this$state = this.state,
          postData = _this$state.postData,
          data = _this$state.data;
      console.log(data);
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "single-blog-main",
        id: "single-blog-main",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_document_meta__WEBPACK_IMPORTED_MODULE_14__.default, _objectSpread({}, meta), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 123,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_header_index_jsx__WEBPACK_IMPORTED_MODULE_9__.default, {
          title: data.title,
          description: data.description,
          keywords: data.keywords
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 124,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
          "class": "content-container",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "container-fluid service-bg p-0 m-0 ",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "service-bg-right",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "service-banner-frame",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "container ",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "row justify-content-center service-banner-content pl-3 pr-3",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                        className: "breadcrumbs",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_19___default()), {
                            href: "/blog",
                            children: "Blogs"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 134,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 134,
                          columnNumber: 25
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                          children: postData.title
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 135,
                          columnNumber: 25
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 133,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 132,
                      columnNumber: 21
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12 text-white  ",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                        className: "bold-contents service-content-box pl-4",
                        children: "We are seeking brilliant minds to join our dynamic team and make it even better."
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 139,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 138,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 131,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 130,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 129,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 128,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 127,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "blog-section",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "container",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "row b-row-1",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-8 col-lg-8",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-wrap",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                      className: "blog-list",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "card",
                        children: this.state.loader == true ? loader : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h5", {
                            className: "card-title text-level-4 title-orange",
                            children: postData.title
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 159,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-meta",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                              children: [postData.published != null && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-clock-o",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 163,
                                  columnNumber: 39
                                }, this), " ", postData.published]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 163,
                                columnNumber: 35
                              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                  className: "fa fa-th-large",
                                  "aria-hidden": "true"
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 166,
                                  columnNumber: 35
                                }, this), postData.categories.map(function (cat, i) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                    children: [cat.name, " ", i < postData.categories.length - 1 ? ', ' : '']
                                  }, i, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 169,
                                    columnNumber: 39
                                  }, _this3);
                                })]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 165,
                                columnNumber: 33
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 161,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 160,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "blog-img",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "blog-thumb",
                              style: {
                                backgroundImage: postData.image == null ? '/images/blogs/writing-good-blog.jpg' : "url(".concat(postData.image, ")")
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 176,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 175,
                            columnNumber: 29
                          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "card-body",
                            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("small", {
                              className: "text-muted cat text-above-main-title",
                              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                                className: "fas fa-users text-info"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 182,
                                columnNumber: 33
                              }, this), " Hashtag systems"]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 181,
                              columnNumber: 31
                            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                              className: "card-text blog-detail-page",
                              dangerouslySetInnerHTML: {
                                __html: postData.content
                              }
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 184,
                              columnNumber: 31
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 180,
                            columnNumber: 29
                          }, this)]
                        }, void 0, true)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 154,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 153,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 152,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 151,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-4 col-lg-4",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "blog-sidebar",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("aside", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_13__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 200,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 201,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 199,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 198,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 197,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 150,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 149,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 148,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 126,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "mob-visible"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 209,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_10__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 210,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 122,
        columnNumber: 7
      }, this);
    }
  }]);

  return Singlepost;
}(react__WEBPACK_IMPORTED_MODULE_8__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy91bmRlci1jb25zdHJ1Y3Rpb24vaW5kZXguanN4Iiwid2VicGFjazovL19OX0UvLi9wYWdlcy9ibG9nL3NpbmdsZS9bc2x1Z10uanN4Il0sIm5hbWVzIjpbIlVuZGVyY29uc3RydWN0aW9uIiwiQ29tcG9uZW50IiwicmVxdWlyZSIsIlNpbmdsZXBvc3QiLCJwcm9wcyIsInJlc3BvbnNlIiwic3RhdGUiLCJkYXRhIiwicG9zdERhdGEiLCJjYXRlZ29yaWVzIiwicG9zdFVybCIsIm1hdGNoIiwicGFyYW1zIiwic2x1ZyIsImxvYWRlciIsInNoaWZ0Q29udGVudCIsImJpbmQiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwiZ2V0X3Bvc3REYXRhIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIiQiLCJpcyIsImluc2VydEJlZm9yZSIsIkF4aW9zIiwiY29uZmlnIiwicG9zdF91cmwiLCJ0aGVuIiwic2V0U3RhdGUiLCJlcnJvciIsImNvbnNvbGUiLCJsb2ciLCJ0b2FzdCIsIm1ldGEiLCJ0aXRsZSIsImNoYXJzZXQiLCJuYW1lIiwia2V5d29yZHMiLCJkZXNjcmlwdGlvbiIsInB1Ymxpc2hlZCIsIm1hcCIsImNhdCIsImkiLCJsZW5ndGgiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJpbWFnZSIsIl9faHRtbCIsImNvbnRlbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBQ0E7QUFDQTtBQUlBOztJQUVxQkEsaUI7Ozs7Ozs7Ozs7Ozs7NkJBSVY7QUFDUCwwQkFLSjtBQUFLLGlCQUFTLEVBQUMsbUJBQWY7QUFBbUMsVUFBRSxFQUFDLG1CQUF0QztBQUFBLHNDQUE0RDtBQUFBLGtDQUNsRDtBQUFLLGlCQUFLLEVBQUMsNEJBQVg7QUFBd0MsaUJBQUssRUFBRSxHQUEvQztBQUFvRCxrQkFBTSxFQUFFLEVBQTVEO0FBQWdFLG1CQUFPLEVBQUMsWUFBeEU7QUFBQSxvQ0FDRTtBQUFHLGdCQUFFLEVBQUMsT0FBTjtBQUFBLHNDQUNFO0FBQU0sb0JBQUksRUFBQyxNQUFYO0FBQWtCLHNCQUFNLEVBQUMsTUFBekI7QUFBZ0MsaUJBQUMsRUFBQztBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURGLGVBRUU7QUFBa0IsNkJBQWEsRUFBQyxXQUFoQztBQUE0QyxxQkFBSyxFQUFDLElBQWxEO0FBQXVELG1CQUFHLEVBQUMsSUFBM0Q7QUFBZ0Usb0JBQUksRUFBQyxTQUFyRTtBQUErRSwyQkFBVyxFQUFDLFlBQTNGO0FBQXdHLGtCQUFFLEVBQUMsV0FBM0c7QUFBdUgsb0JBQUksRUFBQztBQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUtFO0FBQUcsZ0JBQUUsRUFBQyxPQUFOO0FBQUEsc0NBQ0U7QUFBTSxvQkFBSSxFQUFDLE1BQVg7QUFBa0Isc0JBQU0sRUFBQyxNQUF6QjtBQUFnQyxpQkFBQyxFQUFDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUFFRTtBQUFrQiw2QkFBYSxFQUFDLFdBQWhDO0FBQTRDLHFCQUFLLEVBQUMsSUFBbEQ7QUFBdUQsbUJBQUcsRUFBQyxJQUEzRDtBQUFnRSxvQkFBSSxFQUFDLFNBQXJFO0FBQStFLDJCQUFXLEVBQUMsWUFBM0Y7QUFBd0csa0JBQUUsRUFBQyxZQUEzRztBQUF3SCxvQkFBSSxFQUFDO0FBQTdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFEa0QsZUFXbEQ7QUFBSSxxQkFBTSwwQ0FBVjtBQUFBLG1DQUFxRDtBQUFNLHVCQUFNLDJCQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBWGtEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTEk7QUFxQkQ7Ozs7RUExQjRDQyw0Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1IvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQUMsbUJBQU8sQ0FBQyx5RUFBRCxDQUFQOzs7O0lBMEJxQkMsVTs7Ozs7QUFHbkIsc0JBQVlDLEtBQVosRUFBbUI7QUFBQTs7QUFBQTs7QUFDakIsOEJBQU1BLEtBQU47O0FBQ0osZUFBbUMsRUFFOUI7O0FBQ0QsUUFBSUMsUUFBUSxHQUFHLE1BQUtELEtBQXBCO0FBQ0EsVUFBS0UsS0FBTCxHQUFhO0FBQ1hDLFVBQUksRUFBR0YsUUFBUSxDQUFDRSxJQUFULENBQWNBLElBRFY7QUFFWEMsY0FBUSxFQUFFO0FBQ1JDLGtCQUFVLEVBQUUsQ0FBQztBQUFDLGtCQUFPLEVBQVI7QUFBVyxrQkFBUTtBQUFuQixTQUFEO0FBREosT0FGQztBQUtYQyxhQUFPLEVBQUUsTUFBS04sS0FBTCxDQUFXTyxLQUFYLENBQWlCQyxNQUFqQixDQUF3QkMsSUFMdEI7QUFNWEMsWUFBTSxFQUFFO0FBTkcsS0FBYjtBQVNBLFVBQUtDLFlBQUwsR0FBb0IsTUFBS0EsWUFBTCxDQUFrQkMsSUFBbEIseUlBQXBCO0FBZmlCO0FBaUJsQjs7Ozt3Q0FHbUI7QUFDbEIsV0FBS0QsWUFBTDs7QUFDQSxnQkFBK0I7QUFDN0JFLGNBQU0sQ0FBQ0MsZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0MsS0FBS0gsWUFBdkM7QUFDRDs7QUFDRCxXQUFLSSxZQUFMO0FBQ0Q7OzsyQ0FFc0I7QUFDckIsZ0JBQWlDO0FBQy9CRixjQUFNLENBQUNHLG1CQUFQLENBQTJCLFFBQTNCLEVBQXFDLEtBQUtMLFlBQTFDO0FBQ0Q7QUFDRixLLENBRUQ7Ozs7bUNBQ2M7QUFDWixVQUFHTSw4Q0FBQyxDQUFDLGNBQUQsQ0FBRCxDQUFrQkMsRUFBbEIsQ0FBcUIsVUFBckIsQ0FBSCxFQUFxQztBQUNuQ0Qsc0RBQUMsQ0FBQyxnQkFBRCxDQUFELENBQW9CRSxZQUFwQixDQUFpQ0YsOENBQUMsQ0FBQyxZQUFELENBQWxDO0FBQ0QsT0FGRCxNQUdLO0FBQ0hBLHNEQUFDLENBQUMsZ0JBQUQsQ0FBRCxDQUFvQkUsWUFBcEIsQ0FBaUNGLDhDQUFDLENBQUMsd0JBQUQsQ0FBbEM7QUFDRDtBQUNGLEssQ0FFRDs7OzttQ0FDYztBQUFBOztBQUNaLFVBQUlYLE9BQU8sR0FBRyxLQUFLSixLQUFMLENBQVdJLE9BQXpCO0FBQ0FjLHVEQUFBLENBQVVDLHFEQUFBLEdBQXVCLG1CQUFqQyxFQUFzRDtBQUFDYixjQUFNLEVBQUU7QUFBQ2Msa0JBQVEsRUFBRWhCO0FBQVg7QUFBVCxPQUF0RCxFQUNDaUIsSUFERCxDQUNNLFVBQUN0QixRQUFELEVBQWM7QUFDbEI7QUFDQSxZQUFNRyxRQUFRLEdBQUdILFFBQVEsQ0FBQ0UsSUFBVCxDQUFjQSxJQUEvQjs7QUFDQSxjQUFJLENBQUNxQixRQUFMLENBQWM7QUFDWnBCLGtCQUFRLEVBQUVBLFFBREU7QUFFWk0sZ0JBQU0sRUFBRTtBQUZJLFNBQWQ7QUFJRCxPQVJELFdBUVMsVUFBQWUsS0FBSyxFQUFHO0FBQ2ZDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixLQUFLLENBQUN4QixRQUFsQjtBQUNBMkIsZ0VBQUEsQ0FBWSx1QkFBWjtBQUNELE9BWEQ7QUFZRDs7OzZCQUdRO0FBQUE7O0FBQ1AsVUFBTUMsSUFBSSxHQUFHO0FBQ1hDLGFBQUssRUFBRSx5REFESTtBQUVYRCxZQUFJLEVBQUU7QUFDSkUsaUJBQU8sRUFBRSxPQURMO0FBRUZDLGNBQUksRUFBRTtBQUNKQyxvQkFBUSxFQUFFO0FBRE47QUFGSjtBQUZLLE9BQWI7O0FBVUEsVUFBTXZCLE1BQU0sZ0JBQUc7QUFBSyxpQkFBUyxFQUFDLFFBQWY7QUFBQSxnQ0FBd0I7QUFBSyxtQkFBUyxFQUFDLFNBQWY7QUFBQSxrQ0FBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBekIsZUFBb0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBcEMsZUFBK0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBL0MsZUFBMEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FBZjs7QUFYTyx3QkFZZ0IsS0FBS1IsS0FackI7QUFBQSxVQVlGRSxRQVpFLGVBWUZBLFFBWkU7QUFBQSxVQVlRRCxJQVpSLGVBWVFBLElBWlI7QUFhUHVCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZeEIsSUFBWjtBQUNBLDBCQUNFO0FBQUssaUJBQVMsRUFBQyxrQkFBZjtBQUFrQyxVQUFFLEVBQUMsa0JBQXJDO0FBQUEsZ0NBQ0UsOERBQUMseURBQUQsb0JBQWtCMEIsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFLDhEQUFDLGlFQUFEO0FBQVEsZUFBSyxFQUFFMUIsSUFBSSxDQUFDMkIsS0FBcEI7QUFBMkIscUJBQVcsRUFBRTNCLElBQUksQ0FBQytCLFdBQTdDO0FBQTBELGtCQUFRLEVBQUUvQixJQUFJLENBQUM4QjtBQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGLGVBSUU7QUFBUyxtQkFBTSxtQkFBZjtBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxxQ0FBZjtBQUFBLG1DQUNFO0FBQUssdUJBQVMsRUFBQyxrQkFBZjtBQUFBLHFDQUNFO0FBQUsseUJBQVMsRUFBQyxzQkFBZjtBQUFBLHVDQUNFO0FBQUssMkJBQVMsRUFBQyxZQUFmO0FBQUEseUNBQ0U7QUFBSyw2QkFBUyxFQUFDLDZEQUFmO0FBQUEsNENBQ0U7QUFBSywrQkFBUyxFQUFDLG9CQUFmO0FBQUEsNkNBQ0U7QUFBSSxpQ0FBUyxFQUFDLGFBQWQ7QUFBQSxnREFDRTtBQUFBLGlEQUFJLDhEQUFDLG1EQUFEO0FBQU0sZ0NBQUksRUFBQyxPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FERixlQUVFO0FBQUEsb0NBQUs3QixRQUFRLENBQUMwQjtBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFERixlQU9FO0FBQUssK0JBQVMsRUFBQyxpQ0FBZjtBQUFBLDZDQUNFO0FBQUcsaUNBQVMsRUFBQyx3Q0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQXNCRTtBQUFLLHFCQUFTLEVBQUMsY0FBZjtBQUFBLG1DQUNFO0FBQUssdUJBQVMsRUFBQyxXQUFmO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLGFBQWY7QUFBQSx3Q0FDRTtBQUFLLDJCQUFTLEVBQUMsb0NBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsV0FBZjtBQUFBLDJDQUNFO0FBQUssK0JBQVMsRUFBQyxXQUFmO0FBQUEsNkNBQ0U7QUFBSyxpQ0FBUyxFQUFDLE1BQWY7QUFBQSxrQ0FDSSxLQUFLNUIsS0FBTCxDQUFXUSxNQUFYLElBQXFCLElBQXRCLEdBQ0NBLE1BREQsZ0JBR0M7QUFBQSxrREFDRTtBQUFJLHFDQUFTLEVBQUMsc0NBQWQ7QUFBQSxzQ0FBc0ROLFFBQVEsQ0FBQzBCO0FBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBREYsZUFFRTtBQUFLLHFDQUFTLEVBQUMsV0FBZjtBQUFBLG1EQUNFO0FBQUEseUNBQ0kxQixRQUFRLENBQUMrQixTQUFULElBQXNCLElBQXZCLGlCQUNDO0FBQUEsd0RBQUk7QUFBRywyQ0FBUyxFQUFDLGVBQWI7QUFBNkIsaURBQVk7QUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx3Q0FBSixPQUEwRC9CLFFBQVEsQ0FBQytCLFNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQ0FGSixlQUlFO0FBQUEsd0RBQ0U7QUFBRywyQ0FBUyxFQUFDLGdCQUFiO0FBQThCLGlEQUFZO0FBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0NBREYsRUFFRy9CLFFBQVEsQ0FBQ0MsVUFBVCxDQUFvQitCLEdBQXBCLENBQXdCLFVBQUNDLEdBQUQsRUFBTUMsQ0FBTixFQUFZO0FBQ25DLHNEQUNFO0FBQUEsK0NBQWVELEdBQUcsQ0FBQ0wsSUFBbkIsT0FBMEJNLENBQUMsR0FBSWxDLFFBQVEsQ0FBQ0MsVUFBVixDQUFzQmtDLE1BQXRCLEdBQStCLENBQW5DLEdBQXVDLElBQXZDLEdBQThDLEVBQXhFO0FBQUEscUNBQVdELENBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSw0Q0FERjtBQUdELGlDQUpBLENBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNDQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBRkYsZUFpQkU7QUFBSyxxQ0FBUyxFQUFDLFVBQWY7QUFBQSxtREFDRTtBQUFLLHVDQUFTLEVBQUMsWUFBZjtBQUE0QixtQ0FBSyxFQUFFO0FBQUNFLCtDQUFlLEVBQUdwQyxRQUFRLENBQUNxQyxLQUFULElBQWtCLElBQW5CLEdBQTJCLHFDQUEzQixpQkFBMEVyQyxRQUFRLENBQUNxQyxLQUFuRjtBQUFsQjtBQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FqQkYsZUFzQkU7QUFBSyxxQ0FBUyxFQUFDLFdBQWY7QUFBQSxvREFDRTtBQUFPLHVDQUFTLEVBQUMsc0NBQWpCO0FBQUEsc0RBQ0U7QUFBRyx5Q0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQ0FERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBREYsZUFJRTtBQUFLLHVDQUFTLEVBQUMsNEJBQWY7QUFBNEMscURBQXVCLEVBQUU7QUFBQ0Msc0NBQU0sRUFBRXRDLFFBQVEsQ0FBQ3VDO0FBQWxCO0FBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQXRCRjtBQUFBO0FBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQStDRTtBQUFLLDJCQUFTLEVBQUMsb0NBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsY0FBZjtBQUFBLDJDQUNFO0FBQUEsOENBQ0UsOERBQUMsdUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFERixlQUVFLDhEQUFDLHlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSkYsZUF1RkU7QUFBSyxtQkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF2RkYsZUF3RkUsOERBQUMsa0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF4RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREY7QUE0RkQ7Ozs7RUEzS3FDOUMsNEMiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvYmxvZy9zaW5nbGUvW3NsdWddLjE0OTYxY2RmNzZmNTI4NDQyZjA0LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xyXG4vLyBpbXBvcnQgeyBIYXNoTGluayBhcyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWhhc2gtbGluayc7XHJcbi8vIGltcG9ydCB7IE5hdkhhc2hMaW5rIGFzIE5hdkxpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItaGFzaC1saW5rJztcclxuXHJcblxyXG5cclxuLy8gaW1wb3J0ICcuL3N0eWxlLmNzcyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBVbmRlcmNvbnN0cnVjdGlvbiBleHRlbmRzIENvbXBvbmVudCB7XHJcblxyXG5cclxuXHJcbiAgcmVuZGVyKCkge1xyXG4gICAgcmV0dXJuIChcclxuXHJcbiAgICAgIFxyXG5cclxuICAgXHJcbjxkaXYgY2xhc3NOYW1lPVwiY29uc3RydWN0aW9uLW1haW5cIiBpZD1cImNvbnN0cnVjdGlvbi1tYWluXCI+ICA8bWFpbj5cclxuICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHdpZHRoPXsxMDB9IGhlaWdodD17NzB9IHZpZXdCb3g9XCIwIDAgMTAwIDY4XCI+XHJcbiAgICAgICAgICAgIDxnIGlkPVwibGFyZ2VcIj5cclxuICAgICAgICAgICAgICA8cGF0aCBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiNGNDRcIiBkPVwiTTU1LjggMzguNWw2LjItMS4yYzAtMS44LS4xLTMuNS0uNC01LjNsLTYuMy0uMmMtLjUtMi0xLjItNC0yLjEtNmw0LjgtNGMtLjktMS42LTEuOS0zLTMtNC40bC01LjYgM2MtMS4zLTEuNi0zLTMtNC43LTQuMWwyLTZBMzAgMzAgMCAwIDAgNDIgOGwtMy4zIDUuNGMtMi0uNy00LjItMS02LjItMS4yTDMxLjMgNmMtMS44IDAtMy41LjEtNS4zLjRsLS4yIDYuM2MtMiAuNS00IDEuMi02IDIuMWwtNC00LjhjLTEuNi45LTMgMS45LTQuNCAzbDMgNS42Yy0xLjYgMS4zLTMgMy00LjEgNC43bC02LTJBMzIuNSAzMi41IDAgMCAwIDIgMjZsNS40IDMuM2MtLjcgMi0xIDQuMi0xLjIgNi4yTDAgMzYuN2MwIDEuOC4xIDMuNS40IDUuM2w2LjMuMmMuNSAyIDEuMiA0IDIuMSA2bC00LjggNGMuOSAxLjYgMS45IDMgMyA0LjRsNS42LTNjMS40IDEuNiAzIDMgNC43IDQuMWwtMiA2QTMwLjUgMzAuNSAwIDAgMCAyMCA2NmwzLjQtNS40YzIgLjcgNCAxIDYuMSAxLjJsMS4yIDYuMmMxLjggMCAzLjUtLjEgNS4zLS40bC4yLTYuM2MyLS41IDQtMS4yIDYtMi4xbDQgNC44YzEuNi0uOSAzLTEuOSA0LjQtM2wtMy01LjZjMS42LTEuMyAzLTMgNC4xLTQuN2w2IDJBMzIgMzIgMCAwIDAgNjAgNDhsLTUuNC0zLjNjLjctMiAxLTQuMiAxLjItNi4yem0tMTMuNSA0YTEyLjUgMTIuNSAwIDEgMS0yMi42LTExIDEyLjUgMTIuNSAwIDAgMSAyMi42IDExelwiIC8+XHJcbiAgICAgICAgICAgICAgPGFuaW1hdGVUcmFuc2Zvcm0gYXR0cmlidXRlTmFtZT1cInRyYW5zZm9ybVwiIGJlZ2luPVwiMHNcIiBkdXI9XCIzc1wiIGZyb209XCIwIDMxIDM3XCIgcmVwZWF0Q291bnQ9XCJpbmRlZmluaXRlXCIgdG89XCIzNjAgMzEgMzdcIiB0eXBlPVwicm90YXRlXCIgLz5cclxuICAgICAgICAgICAgPC9nPlxyXG4gICAgICAgICAgICA8ZyBpZD1cInNtYWxsXCI+XHJcbiAgICAgICAgICAgICAgPHBhdGggZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjRjQ0XCIgZD1cIk05MyAxOS4zbDYtM2MtLjQtMS42LTEtMy4yLTEuNy00LjhMOTAuOCAxM2MtLjktMS40LTItMi43LTMuNC0zLjhsMi4xLTYuM0EyMS44IDIxLjggMCAwIDAgODUgLjdsLTMuNiA1LjVjLTEuNy0uNC0zLjQtLjUtNS4xLS4zbC0zLTUuOWMtMS42LjQtMy4yIDEtNC43IDEuN0w3MCA4Yy0xLjUgMS0yLjggMi0zLjkgMy41TDYwIDkuNGEyMC42IDIwLjYgMCAwIDAtMi4yIDQuNmw1LjUgMy42YTE1IDE1IDAgMCAwLS4zIDUuMWwtNS45IDNjLjQgMS42IDEgMy4yIDEuNyA0LjdMNjUgMjljMSAxLjUgMi4xIDIuOCAzLjUgMy45bC0yLjEgNi4zYTIxIDIxIDAgMCAwIDQuNSAyLjJsMy42LTUuNmMxLjcuNCAzLjUuNSA1LjIuM2wyLjkgNS45YzEuNi0uNCAzLjItMSA0LjgtMS43TDg2IDM0YzEuNC0xIDIuNy0yLjEgMy44LTMuNWw2LjMgMi4xYTIxLjUgMjEuNSAwIDAgMCAyLjItNC41bC01LjYtMy42Yy40LTEuNy41LTMuNS4zLTUuMXpNODQuNSAyNGE3IDcgMCAxIDEtMTIuOC02LjIgNyA3IDAgMCAxIDEyLjggNi4yelwiIC8+XHJcbiAgICAgICAgICAgICAgPGFuaW1hdGVUcmFuc2Zvcm0gYXR0cmlidXRlTmFtZT1cInRyYW5zZm9ybVwiIGJlZ2luPVwiMHNcIiBkdXI9XCIyc1wiIGZyb209XCIwIDc4IDIxXCIgcmVwZWF0Q291bnQ9XCJpbmRlZmluaXRlXCIgdG89XCItMzYwIDc4IDIxXCIgdHlwZT1cInJvdGF0ZVwiIC8+XHJcbiAgICAgICAgICAgIDwvZz5cclxuICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgPGgxIGNsYXNzPVwibWFpbi10aXRsZSBiYW5uZXItbWFpbi10aXRsZSB0ZXh0LWNlbnRlclwiPjxzcGFuIGNsYXNzPVwibW9iaWxlLXdoaXRlIHRpdGxlLW9yYW5nZVwiPlVuZGVyIE1haW50ZW5hbmNlPC9zcGFuPjwvaDE+XHJcbiAgICAgICAgIFxyXG4gICAgICAgIDwvbWFpbj48L2Rpdj5cclxuXHJcbiAgICApXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBIZWFkZXIgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9oZWFkZXIvaW5kZXguanN4JztcclxuaW1wb3J0IEZvb3RlciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2Zvb3Rlci9pbmRleC5qc3gnO1xyXG5pbXBvcnQgVW5kZXJjb25zdHJ1Y3Rpb24gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91bmRlci1jb25zdHJ1Y3Rpb24vaW5kZXguanN4JztcclxuaW1wb3J0IEJsb2dDYXRlZ29yaWVzIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvcG9zdC1jYXRlZ29yeS9pbmRleC5qc3gnO1xyXG5pbXBvcnQgQmxvZ1JlY2VudFBvc3RzIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvcG9zdC1yZWNlbnQvaW5kZXguanN4JztcclxuaW1wb3J0IERvY3VtZW50TWV0YSBmcm9tICdyZWFjdC1kb2N1bWVudC1tZXRhJztcclxuaW1wb3J0IHsgVG9hc3RDb250YWluZXIsIHRvYXN0LCBTbGlkZSB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcclxuaW1wb3J0ICdyZWFjdC10b2FzdGlmeS9kaXN0L1JlYWN0VG9hc3RpZnkuY3NzJztcclxuaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcclxuaW1wb3J0IEF4aW9zIGZyb20gJ2F4aW9zJztcclxuaW1wb3J0IGh0dHBzIGZyb20gXCJodHRwc1wiO1xyXG5pbXBvcnQgKiBhcyBjb25maWcgZnJvbSAnLi4vLi4vLi4vY29uZmlnJztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5cclxucmVxdWlyZSgndHlwZWZhY2UtbW9udHNlcnJhdCcpXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKCkge1xyXG4gIGxldCBkYXRhID0gW107XHJcblxyXG4gIGNvbnN0IGluc3RhbmNlID0gQXhpb3MuY3JlYXRlKHtcclxuICAgIGh0dHBzQWdlbnQ6IG5ldyBodHRwcy5BZ2VudCh7XHJcbiAgICAgIHJlamVjdFVuYXV0aG9yaXplZDogZmFsc2UsXHJcbiAgICB9KSxcclxuICB9KTtcclxuXHJcbiAgYXdhaXQgaW5zdGFuY2VcclxuICAgIC5nZXQoXCJodHRwczovL2FwaS5oYXNodGFnLWNhLmNvbS9hcGkvdjEvbWV0YWRhdGFcIiwge1xyXG4gICAgICBwYXJhbXM6IHtcclxuICAgICAgICBwYWdlX3R5cGU6IFwic3RhdGljXCIsXHJcbiAgICAgICAgc2x1ZzogXCJzZXZpY2VzXCIsXHJcbiAgICAgIH0sXHJcbiAgICB9KVxyXG4gICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgIGRhdGEgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgfSk7XHJcbiAgcmV0dXJuIHtcclxuICAgIHByb3BzOiB7IGRhdGEgfSxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTaW5nbGVwb3N0IGV4dGVuZHMgQ29tcG9uZW50IHtcclxuXHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb3BzKSB7XHJcbiAgICBzdXBlcihwcm9wcyk7XHJcbmlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgZ2xvYmFsLndpbmRvdyA9IHt9O1xyXG4gICAgfVxyXG4gICAgbGV0IHJlc3BvbnNlID0gdGhpcy5wcm9wc1xyXG4gICAgdGhpcy5zdGF0ZSA9IHtcclxuICAgICAgZGF0YSA6IHJlc3BvbnNlLmRhdGEuZGF0YSxcclxuICAgICAgcG9zdERhdGE6IHtcclxuICAgICAgICBjYXRlZ29yaWVzOiBbe1wibmFtZVwiOlwiXCIsXCJzbHVnXCI6IFwiXCJ9XVxyXG4gICAgICB9LFxyXG4gICAgICBwb3N0VXJsOiB0aGlzLnByb3BzLm1hdGNoLnBhcmFtcy5zbHVnLFxyXG4gICAgICBsb2FkZXI6IHRydWVcclxuICAgIH07XHJcblxyXG4gICAgdGhpcy5zaGlmdENvbnRlbnQgPSB0aGlzLnNoaWZ0Q29udGVudC5iaW5kKHRoaXMpO1xyXG4gICAgXHJcbiAgfVxyXG5cclxuXHJcbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XHJcbiAgICB0aGlzLnNoaWZ0Q29udGVudCgpO1xyXG4gICAgaWYodHlwZW9mIHdpbmRvdyAhPT0gdW5kZWZpbmVkKXtcclxuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgdGhpcy5zaGlmdENvbnRlbnQpO1xyXG4gICAgfVxyXG4gICAgdGhpcy5nZXRfcG9zdERhdGEoKTtcclxuICB9XHJcblxyXG4gIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xyXG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCB0aGlzLnNoaWZ0Q29udGVudCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvL1NlYXJjaCBkaXYgc2hpZnRcclxuICBzaGlmdENvbnRlbnQoKXtcclxuICAgIGlmKCQoXCIubW9iLXZpc2libGVcIikuaXMoXCI6dmlzaWJsZVwiKSkgeyBcclxuICAgICAgJCgnLndpZGdldF9zZWFyY2gnKS5pbnNlcnRCZWZvcmUoJCgnLmJsb2ctbGlzdCcpKTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICAkKCcud2lkZ2V0X3NlYXJjaCcpLmluc2VydEJlZm9yZSgkKCcud2lkZ2V0X3JlY2VudF9lbnRyaWVzJykpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy9HZXQgcG9zdCBkYXRhXHJcbiAgZ2V0X3Bvc3REYXRhKCl7XHJcbiAgICBsZXQgcG9zdFVybCA9IHRoaXMuc3RhdGUucG9zdFVybDtcclxuICAgIEF4aW9zLmdldChjb25maWcubXlDb25maWcuYXBpVXJsKydibG9nL3Bvc3RzL3NpbmdsZScsIHtwYXJhbXM6IHtwb3N0X3VybDogcG9zdFVybH19KVxyXG4gICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBjb25zdCBwb3N0RGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuICAgICAgdGhpcy5zZXRTdGF0ZSh7IFxyXG4gICAgICAgIHBvc3REYXRhOiBwb3N0RGF0YSxcclxuICAgICAgICBsb2FkZXI6IGZhbHNlXHJcbiAgICAgIH0pXHJcbiAgICB9KS5jYXRjaChlcnJvciA9PntcclxuICAgICAgY29uc29sZS5sb2coZXJyb3IucmVzcG9uc2UpO1xyXG4gICAgICB0b2FzdC5lcnJvcihcIlNvbWV0aGluZyB3ZW50IHdyb25nLlwiKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcblxyXG4gIHJlbmRlcigpIHtcclxuICAgIGNvbnN0IG1ldGEgPSB7XHJcbiAgICAgIHRpdGxlOiAnQmxvZ3MgLSBGdWxsU3RhY2sgV2ViIERldmVsb3BtZW50fCBCYXkgYXJlYSwgQ2FsaWZvcm5pYScsXHJcbiAgICAgIG1ldGE6IHtcclxuICAgICAgICBjaGFyc2V0OiAndXRmLTgnLFxyXG4gICAgICAgICAgbmFtZToge1xyXG4gICAgICAgICAgICBrZXl3b3JkczogJ1dlYiBkZXZlbG9wbWVudCBjb21wYW55LHNvZnR3YXJlIGRldmVsb3BtZW50IGNvbXBhbnksd2ViIGRldmVsb3BtZW50IGtvY2hpLHdlYiBkZXZlbG9wbWVudCBjb21wYW55IGtvY2hpLHNvZnR3YXJlIGRldmVsb3BtZW50IGtvY2hpLHdlYiBkZXZlbG9wbWVudCBjb21wYW55IGtvY2hpLHNvZnR3YXJlIGRldmVsb3BtZW50IGtvY2hpLHdlYiBkZXNpZ24gYW5kIGRldmVsb3BtZW50IGtvY2hpLGZ1bGwgc3RhY2sgZGV2ZWxvcG1lbnQgY29tcGFueSx3b3JkcHJlc3MgY3VzdG9taXNhdGlvbiBjb21wYW55IGtlcmFsYSxzaG9waWZ5IHRoZW1lIGRldmVsb3BtZW50IGNvbXBhbnkga2VyYWxhLGVjb21tZXJjZSBkZXZlbG9wbWVudCBjb21wYW55IGtlcmFsYSx3b29jb21tZXJjZSBkZXZlbG9wbWVudCBjb21wYW55IGtlcmFsYSx3ZWIgZGV2ZWxvcG1lbnQgY29tcGFueSBDYWxpZm9ybmlhLHNvZnR3YXJlIGRldmVsb3BtZW50IGNhbGlmb3JuaWEsd29yZHByZXNzIGRldmVsb3BtZW50IGNhbGlmb3JuaWEsd29yZHByZXNzIGRldmVsb3BtZW50IGtvY2hpLHNob3BpZnkgZGV2ZWxvcG1lbnQga29jaGksc2hvcGlmeSBkZXZlbG9wbWVudCBjYWxpZm9ybmlhLHdvcmRwcmVzcyBjdXN0b21pc2F0aW9uIGNvbXBhbnksc2hvcGlmeSB0aGVtZSBkZXZlbG9wbWVudCBjb21wYW55LGVjb21tZXJjZSBkZXZlbG9wbWVudCBjb21wYW55IGtvY2hpLGVjb21tZXJjZSBkZXZlbG9wbWVudCBjb21wYW55IGNhbGlmb3JuaWEnXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGxvYWRlciA9IDxkaXYgY2xhc3NOYW1lPVwibG9hZGVyXCI+PGRpdiBjbGFzc05hbWU9XCJzcGlubmVyXCI+PGRpdj48L2Rpdj48ZGl2PjwvZGl2PjxkaXY+PC9kaXY+PGRpdj48L2Rpdj48L2Rpdj5Mb2FkaW5nPC9kaXY+O1xyXG4gICAgbGV0IHtwb3N0RGF0YSwgZGF0YX0gPSB0aGlzLnN0YXRlO1xyXG4gICAgY29uc29sZS5sb2coZGF0YSlcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2luZ2xlLWJsb2ctbWFpblwiIGlkPVwic2luZ2xlLWJsb2ctbWFpblwiPlxyXG4gICAgICAgIDxEb2N1bWVudE1ldGEgey4uLm1ldGF9IC8+XHJcbiAgICAgICAgPEhlYWRlciB0aXRsZT17ZGF0YS50aXRsZX0gZGVzY3JpcHRpb249e2RhdGEuZGVzY3JpcHRpb259IGtleXdvcmRzPXtkYXRhLmtleXdvcmRzfT48L0hlYWRlcj5cclxuXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3M9XCJjb250ZW50LWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItZmx1aWQgc2VydmljZS1iZyBwLTAgbS0wIFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmctcmlnaHRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmFubmVyLWZyYW1lXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cganVzdGlmeS1jb250ZW50LWNlbnRlciBzZXJ2aWNlLWJhbm5lci1jb250ZW50IHBsLTMgcHItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiYnJlYWRjcnVtYnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxMaW5rIGhyZWY9XCIvYmxvZ1wiPkJsb2dzPC9MaW5rPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT57cG9zdERhdGEudGl0bGV9PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbGctNiBjb2wtbWQtMTIgdGV4dC13aGl0ZSAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJib2xkLWNvbnRlbnRzIHNlcnZpY2UtY29udGVudC1ib3ggcGwtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgV2UgYXJlIHNlZWtpbmcgYnJpbGxpYW50IG1pbmRzIHRvIGpvaW4gb3VyIGR5bmFtaWMgdGVhbSBhbmQgbWFrZSBpdCBldmVuIGJldHRlci48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICBcclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj4gXHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiLXJvdy0xXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtc20tMTIgY29sLW1kLTggY29sLWxnLThcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsodGhpcy5zdGF0ZS5sb2FkZXIgPT0gdHJ1ZSk/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwiY2FyZC10aXRsZSB0ZXh0LWxldmVsLTQgdGl0bGUtb3JhbmdlXCI+e3Bvc3REYXRhLnRpdGxlfTwvaDU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhwb3N0RGF0YS5wdWJsaXNoZWQgIT0gbnVsbCkgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48aSBjbGFzc05hbWU9XCJmYSBmYS1jbG9jay1vXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPiB7cG9zdERhdGEucHVibGlzaGVkfTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLXRoLWxhcmdlXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Bvc3REYXRhLmNhdGVnb3JpZXMubWFwKChjYXQsIGkpID0+IHsgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2l9PntjYXQubmFtZX0ge2kgPCAocG9zdERhdGEuY2F0ZWdvcmllcykubGVuZ3RoIC0gMSA/ICcsICcgOiAnJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctaW1nXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy10aHVtYlwiIHN0eWxlPXt7YmFja2dyb3VuZEltYWdlOiAocG9zdERhdGEuaW1hZ2UgPT0gbnVsbCkgPyAnL2ltYWdlcy9ibG9ncy93cml0aW5nLWdvb2QtYmxvZy5qcGcnIDogYHVybCgke3Bvc3REYXRhLmltYWdlfSlgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qeyAocG9zdERhdGEuaW1hZ2UgPT0gbnVsbCkgPyA8aW1nIHNyYz1cIi9pbWFnZXMvYmxvZ3Mvd3JpdGluZy1nb29kLWJsb2cuanBnXCIgYWx0PXtwb3N0RGF0YS5pbWFnZV9hbHR9IC8+IDogPGltZyBzcmM9e3Bvc3REYXRhLmltYWdlfSBhbHQ9e3Bvc3REYXRhLmltYWdlX2FsdH0gLz4gfSovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c21hbGwgY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBjYXQgdGV4dC1hYm92ZS1tYWluLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXVzZXJzIHRleHQtaW5mb1wiPjwvaT4gSGFzaHRhZyBzeXN0ZW1zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc21hbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC10ZXh0IGJsb2ctZGV0YWlsLXBhZ2VcIiBkYW5nZXJvdXNseVNldElubmVySFRNTD17e19faHRtbDogcG9zdERhdGEuY29udGVudH19PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7Lyo8ZGl2IGNsYXNzTmFtZT1cImJsb2ctbmF2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInByZXZcIj48aSBjbGFzc05hbWU9XCJmYSBmYS1hbmdsZS1sZWZ0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPlByZXY8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cIm5leHRcIj5OZXh0PGkgY2xhc3NOYW1lPVwiZmEgZmEtYW5nbGUtcmlnaHRcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48L2k+PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PiovfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1zbS0xMiBjb2wtbWQtNCBjb2wtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctc2lkZWJhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhc2lkZT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCbG9nUmVjZW50UG9zdHM+PC9CbG9nUmVjZW50UG9zdHM+ICBcclxuICAgICAgICAgICAgICAgICAgICAgIDxCbG9nQ2F0ZWdvcmllcz48L0Jsb2dDYXRlZ29yaWVzPiAgICBcclxuICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vYi12aXNpYmxlXCI+PC9kaXY+XHJcbiAgICAgICAgPEZvb3Rlcj48L0Zvb3Rlcj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=