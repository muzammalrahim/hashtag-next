self["webpackHotUpdate_N_E"]("pages/blog/category/[slug]",{

/***/ "./pages/blog/category/[slug].jsx":
/*!****************************************!*\
  !*** ./pages/blog/category/[slug].jsx ***!
  \****************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ BlogCategory; }
/* harmony export */ });
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_header_index_jsx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/header/index.jsx */ "./components/header/index.jsx");
/* harmony import */ var _components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/footer/index.jsx */ "./components/footer/index.jsx");
/* harmony import */ var _components_under_construction_index_jsx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../components/under-construction/index.jsx */ "./components/under-construction/index.jsx");
/* harmony import */ var _components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../components/post-category/index.jsx */ "./components/post-category/index.jsx");
/* harmony import */ var _components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../components/post-recent/index.jsx */ "./components/post-recent/index.jsx");
/* harmony import */ var react_document_meta__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-document-meta */ "./node_modules/react-document-meta/dist/index.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react-infinite-scroller */ "./node_modules/react-infinite-scroller/index.js");
/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_infinite_scroller__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../config */ "./config.js");
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! query-string */ "./node_modules/query-string/index.js");
/* harmony import */ var react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! react-reveal/Reveal */ "./node_modules/react-reveal/Reveal.js");
/* harmony import */ var react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_23__);
/* module decorator */ module = __webpack_require__.hmd(module);










var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\pages\\blog\\category\\[slug].jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

















__webpack_require__(/*! typeface-montserrat */ "./node_modules/typeface-montserrat/index.css");

var __N_SSP = true;

var BlogCategory = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__.default)(BlogCategory, _Component);

  var _super = _createSuper(BlogCategory);

  function BlogCategory(props) {
    var _this;

    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_4__.default)(this, BlogCategory);

    _this = _super.call(this, props);

    if (false) {}

    var response = _this.props;
    _this.state = {
      allPosts: [],
      hasMoreItems: true,
      page: 1,
      no_items: '',
      category: _this.props.match.params.slug,
      search_val: '',
      keyword: '',
      data: response.data.data
    };
    _this.shiftContent = _this.shiftContent.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    _this.get_allPosts = _this.get_allPosts.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    _this.handleChange = _this.handleChange.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    _this.onSubmit = _this.onSubmit.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    return _this;
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__.default)(BlogCategory, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.shiftContent();

      if (true) {
        window.addEventListener("resize", this.shiftContent);
      }

      if (window.location.pathname) {
        var pathNames = window.location.pathname.split("/");
        console.log("path", pathNames);
        var singlePost = pathNames[3];
        this.setState({
          category: singlePost
        });
      }
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      if (this.props.location.search) {
        var values = query_string__WEBPACK_IMPORTED_MODULE_21__.parse(this.props.location.search);
        this.setState({
          keyword: values.keyword,
          search_val: values.keyword
        });
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (true) {
        window.removeEventListener("resize", this.shiftContent);
      }
    }
  }, {
    key: "handleChange",
    value: function handleChange(e) {
      this.setState({
        search_val: e.target.value
      });
    }
  }, {
    key: "onSubmit",
    value: function onSubmit(e) {
      e.preventDefault();
      var values = this.state.search_val;
      this.setState({
        keyword: values,
        page: 1,
        allPosts: [],
        hasMoreItems: true,
        no_items: ''
      });
      this.props.history.push('/blogs/category/' + this.state.category + '?keyword=' + this.state.search_val);
    } //Search div shift

  }, {
    key: "shiftContent",
    value: function shiftContent() {
      if (jquery__WEBPACK_IMPORTED_MODULE_19___default()(".mob-visible").is(":visible")) {
        jquery__WEBPACK_IMPORTED_MODULE_19___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_19___default()('.blog-list'));
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_19___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_19___default()('.widget_recent_entries'));
      }
    } //Get posts

  }, {
    key: "get_allPosts",
    value: function () {
      var _get_allPosts = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__.default)( /*#__PURE__*/E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee() {
        var _this2 = this;

        var url, page, category, keyword;
        return E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                url = _config__WEBPACK_IMPORTED_MODULE_20__.myConfig.apiUrl + 'blog/posts';
                page = this.state.page;
                category = this.state.category;
                keyword = this.state.keyword;
                axios.get(url, {
                  params: {
                    page: page,
                    category: category,
                    keyword: keyword
                  }
                }).then(function (response) {
                  var allPosts = _this2.state.allPosts;
                  response.data.data.posts.map(function (data) {
                    allPosts.push(data);
                  });

                  if (response.data.data.more_exists == true) {
                    _this2.setState({
                      allPosts: allPosts,
                      hasMoreItems: true,
                      page: page + 1
                    });
                  } else {
                    if (allPosts.length == 0) {
                      console.log('No posts found.');

                      _this2.setState({
                        hasMoreItems: false,
                        no_items: 'No posts found.'
                      });
                    } else {
                      _this2.setState({
                        hasMoreItems: false
                      });
                    }
                  }
                })["catch"](function (error) {
                  // console.log(error.response);
                  console.log('API error.');
                  react_toastify__WEBPACK_IMPORTED_MODULE_24__.toast.error("Something went wrong.");
                });

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function get_allPosts() {
        return _get_allPosts.apply(this, arguments);
      }

      return get_allPosts;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var meta = {
        title: 'Blogs - FullStack Web Development| Bay area, California',
        meta: {
          charset: 'utf-8',
          name: {
            keywords: 'Web development company,software development company,web development kochi,web development company kochi,software development kochi,web development company kochi,software development kochi,web design and development kochi,full stack development company,wordpress customisation company kerala,shopify theme development company kerala,ecommerce development company kerala,woocommerce development company kerala,web development company California,software development california,wordpress development california,wordpress development kochi,shopify development kochi,shopify development california,wordpress customisation company,shopify theme development company,ecommerce development company kochi,ecommerce development company california'
          }
        }
      };

      var loader = /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "loader",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "spinner",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 190,
            columnNumber: 69
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 190,
            columnNumber: 80
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 190,
            columnNumber: 91
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 190,
            columnNumber: 102
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 190,
          columnNumber: 44
        }, this), "Loading"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 190,
        columnNumber: 20
      }, this);

      var post_lists = [];
      this.state.allPosts.map(function (post, index) {
        post_lists.push( /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_22___default()), {
          bottom: true,
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
            className: "card",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h5", {
              className: "card-title text-level-4 title-orange",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), {
                href: "/blog/single/[slug]",
                as: "/blog/single/" + post.url,
                children: post.title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 198,
                columnNumber: 15
              }, _this3)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 197,
              columnNumber: 13
            }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "blog-img",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), {
                href: "/blog/single/[idex]",
                as: "/blog/single/" + post.url,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "blog-thumb",
                  style: {
                    backgroundImage: post.image == null ? "/images/blogs/writing-good-blog.jpg" : "url(".concat(post.image, ")")
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 210,
                  columnNumber: 17
                }, _this3)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 206,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                className: "card-img-overlay",
                children: post.categories.map(function (cat, i) {
                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), {
                    href: "/blog/category/[slug]",
                    as: "/blog/category/" + cat.slug,
                    className: "btn btn-light btn-sm",
                    children: cat.name
                  }, i, false, {
                    fileName: _jsxFileName,
                    lineNumber: 223,
                    columnNumber: 21
                  }, _this3);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 220,
                columnNumber: 15
              }, _this3)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 205,
              columnNumber: 13
            }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "card-body",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h4", {
                className: "card-title text-level-4 title-orange",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), {
                  href: "/blog/single/[slug]",
                  as: "/blog/single/" + post.url,
                  children: post.title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 237,
                  columnNumber: 17
                }, _this3)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 236,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("small", {
                className: "text-muted cat text-above-main-title author-blk",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("i", {
                  className: "fa fa-hashtag",
                  "aria-hidden": "true"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 245,
                  columnNumber: 17
                }, _this3), " ", post.author]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 244,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                className: "card-text",
                children: post.excerpt
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 248,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
                className: "cta-link",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_23___default()), {
                  href: "/blog/single/[slug]",
                  as: "/blog/single/" + post.url,
                  className: "shopify-sub-title",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("a", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
                      children: "Read More"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 256,
                      columnNumber: 21
                    }, _this3), " ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("i", {
                      className: "fa fa-chevron-right",
                      "aria-hidden": "true"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 257,
                      columnNumber: 21
                    }, _this3)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 255,
                    columnNumber: 19
                  }, _this3)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 250,
                  columnNumber: 17
                }, _this3)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 249,
                columnNumber: 15
              }, _this3)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 235,
              columnNumber: 13
            }, _this3)]
          }, index, true, {
            fileName: _jsxFileName,
            lineNumber: 196,
            columnNumber: 11
          }, _this3)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 195,
          columnNumber: 9
        }, _this3));
      });
      var data = this.state.data;
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "blog-main",
        id: "blog-main",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_toastify__WEBPACK_IMPORTED_MODULE_24__.ToastContainer, {
          transition: react_toastify__WEBPACK_IMPORTED_MODULE_24__.Slide
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 269,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_document_meta__WEBPACK_IMPORTED_MODULE_16__.default, _objectSpread({}, meta), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 270,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_header_index_jsx__WEBPACK_IMPORTED_MODULE_11__.default, {
          title: data.title,
          description: data.description,
          keywords: data.keywords
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 271,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("section", {
          "class": "content-container",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
            className: "container-fluid service-bg p-0 m-0 ",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "service-bg-right",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                className: "service-banner-frame",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "container ",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                    className: "row justify-content-center service-banner-content pl-3 pr-3",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                        className: "sub-text-above-main-title title-white",
                        children: "Blogs"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 279,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h1", {
                        className: "main-title title-white d-block",
                        style: {
                          textTransform: "capitalize"
                        },
                        children: this.state.category
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 282,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 278,
                      columnNumber: 21
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12 text-white  ",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                        className: "bold-contents service-content-box pl-4",
                        children: "We are seeking brilliant minds to join our dynamic team and make it even better."
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 290,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 289,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 277,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 276,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 275,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 274,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 273,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
            className: "blog-section",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "container",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                className: "row b-row-1",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-8 col-lg-8",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                    className: "blog-wrap",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                      className: "blog-list",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((react_infinite_scroller__WEBPACK_IMPORTED_MODULE_18___default()), {
                        initialLoad: true,
                        loadMore: this.get_allPosts,
                        hasMore: this.state.hasMoreItems,
                        loader: loader,
                        children: post_lists
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 307,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                        children: this.state.no_items
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 315,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 306,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 305,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 304,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-4 col-lg-4",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                    className: "blog-sidebar",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("aside", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                        id: "search-4",
                        className: "widget widget_search posts_holder",
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("form", {
                          role: "search",
                          id: "searchform",
                          className: "searchform",
                          onSubmit: this.onSubmit,
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("input", {
                              type: "text",
                              name: "s",
                              id: "blog-search",
                              placeholder: "Search",
                              className: "placeholder",
                              value: this.state.search_val,
                              onChange: this.handleChange
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 334,
                              columnNumber: 29
                            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("button", {
                              type: "submit",
                              name: "search-submit",
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("i", {
                                className: "fa fa-search",
                                "aria-hidden": "true"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 344,
                                columnNumber: 31
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 343,
                              columnNumber: 29
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 333,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 327,
                          columnNumber: 25
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 323,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_15__.default, {
                        category: this.state.category
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 352,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_14__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 355,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 322,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 321,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 320,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 303,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 302,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 301,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 272,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "mob-visible"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 363,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 364,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 268,
        columnNumber: 7
      }, this);
    }
  }]);

  return BlogCategory;
}(react__WEBPACK_IMPORTED_MODULE_10__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYmxvZy9jYXRlZ29yeS9bc2x1Z10uanN4Il0sIm5hbWVzIjpbInJlcXVpcmUiLCJCbG9nQ2F0ZWdvcnkiLCJwcm9wcyIsInJlc3BvbnNlIiwic3RhdGUiLCJhbGxQb3N0cyIsImhhc01vcmVJdGVtcyIsInBhZ2UiLCJub19pdGVtcyIsImNhdGVnb3J5IiwibWF0Y2giLCJwYXJhbXMiLCJzbHVnIiwic2VhcmNoX3ZhbCIsImtleXdvcmQiLCJkYXRhIiwic2hpZnRDb250ZW50IiwiYmluZCIsImdldF9hbGxQb3N0cyIsImhhbmRsZUNoYW5nZSIsIm9uU3VibWl0Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsImxvY2F0aW9uIiwicGF0aG5hbWUiLCJwYXRoTmFtZXMiLCJzcGxpdCIsImNvbnNvbGUiLCJsb2ciLCJzaW5nbGVQb3N0Iiwic2V0U3RhdGUiLCJzZWFyY2giLCJ2YWx1ZXMiLCJxdWVyeVN0cmluZyIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJwcmV2ZW50RGVmYXVsdCIsImhpc3RvcnkiLCJwdXNoIiwiJCIsImlzIiwiaW5zZXJ0QmVmb3JlIiwidXJsIiwiY29uZmlnIiwiYXhpb3MiLCJnZXQiLCJ0aGVuIiwicG9zdHMiLCJtYXAiLCJtb3JlX2V4aXN0cyIsImxlbmd0aCIsImVycm9yIiwidG9hc3QiLCJtZXRhIiwidGl0bGUiLCJjaGFyc2V0IiwibmFtZSIsImtleXdvcmRzIiwibG9hZGVyIiwicG9zdF9saXN0cyIsInBvc3QiLCJpbmRleCIsImJhY2tncm91bmRJbWFnZSIsImltYWdlIiwiY2F0ZWdvcmllcyIsImNhdCIsImkiLCJhdXRob3IiLCJleGNlcnB0IiwiU2xpZGUiLCJkZXNjcmlwdGlvbiIsInRleHRUcmFuc2Zvcm0iLCJDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUVBQSxtQkFBTyxDQUFDLHlFQUFELENBQVA7Ozs7SUF5QnFCQyxZOzs7OztBQUduQix3QkFBWUMsS0FBWixFQUFtQjtBQUFBOztBQUFBOztBQUNqQiw4QkFBTUEsS0FBTjs7QUFDSixlQUFtQyxFQUU5Qjs7QUFDRCxRQUFJQyxRQUFRLEdBQUcsTUFBS0QsS0FBcEI7QUFDQSxVQUFLRSxLQUFMLEdBQWE7QUFDWEMsY0FBUSxFQUFFLEVBREM7QUFFWEMsa0JBQVksRUFBRSxJQUZIO0FBR1hDLFVBQUksRUFBQyxDQUhNO0FBSVhDLGNBQVEsRUFBRSxFQUpDO0FBS1hDLGNBQVEsRUFBRSxNQUFLUCxLQUFMLENBQVdRLEtBQVgsQ0FBaUJDLE1BQWpCLENBQXdCQyxJQUx2QjtBQU1YQyxnQkFBVSxFQUFFLEVBTkQ7QUFPWEMsYUFBTyxFQUFFLEVBUEU7QUFRWEMsVUFBSSxFQUFFWixRQUFRLENBQUNZLElBQVQsQ0FBY0E7QUFSVCxLQUFiO0FBWUEsVUFBS0MsWUFBTCxHQUFvQixNQUFLQSxZQUFMLENBQWtCQyxJQUFsQix5SUFBcEI7QUFDQSxVQUFLQyxZQUFMLEdBQW9CLE1BQUtBLFlBQUwsQ0FBa0JELElBQWxCLHlJQUFwQjtBQUVBLFVBQUtFLFlBQUwsR0FBb0IsTUFBS0EsWUFBTCxDQUFrQkYsSUFBbEIseUlBQXBCO0FBQ0EsVUFBS0csUUFBTCxHQUFnQixNQUFLQSxRQUFMLENBQWNILElBQWQseUlBQWhCO0FBdEJpQjtBQXVCbEI7Ozs7d0NBRW1CO0FBQ2xCLFdBQUtELFlBQUw7O0FBQ0EsZ0JBQWlDO0FBQy9CSyxjQUFNLENBQUNDLGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDLEtBQUtOLFlBQXZDO0FBQ0Q7O0FBQ0QsVUFBSUssTUFBTSxDQUFDRSxRQUFQLENBQWdCQyxRQUFwQixFQUE4QjtBQUM1QixZQUFJQyxTQUFTLEdBQUdKLE1BQU0sQ0FBQ0UsUUFBUCxDQUFnQkMsUUFBaEIsQ0FBeUJFLEtBQXpCLENBQStCLEdBQS9CLENBQWhCO0FBQ0FDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBb0JILFNBQXBCO0FBQ0EsWUFBSUksVUFBVSxHQUFHSixTQUFTLENBQUMsQ0FBRCxDQUExQjtBQUNBLGFBQUtLLFFBQUwsQ0FBYztBQUFFckIsa0JBQVEsRUFBRW9CO0FBQVosU0FBZDtBQUVEO0FBQ0Y7Ozt5Q0FFbUI7QUFDbEIsVUFBRyxLQUFLM0IsS0FBTCxDQUFXcUIsUUFBWCxDQUFvQlEsTUFBdkIsRUFBOEI7QUFDNUIsWUFBTUMsTUFBTSxHQUFHQyxnREFBQSxDQUFrQixLQUFLL0IsS0FBTCxDQUFXcUIsUUFBWCxDQUFvQlEsTUFBdEMsQ0FBZjtBQUNBLGFBQUtELFFBQUwsQ0FBYztBQUNaaEIsaUJBQU8sRUFBRWtCLE1BQU0sQ0FBQ2xCLE9BREo7QUFFWkQsb0JBQVUsRUFBRW1CLE1BQU0sQ0FBQ2xCO0FBRlAsU0FBZDtBQUlEO0FBQ0Y7OzsyQ0FFc0I7QUFDckIsZ0JBQWlDO0FBQy9CTyxjQUFNLENBQUNhLG1CQUFQLENBQTJCLFFBQTNCLEVBQXFDLEtBQUtsQixZQUExQztBQUNEO0FBQ0Y7OztpQ0FFWW1CLEMsRUFBRztBQUNkLFdBQUtMLFFBQUwsQ0FBYztBQUNaakIsa0JBQVUsRUFBRXNCLENBQUMsQ0FBQ0MsTUFBRixDQUFTQztBQURULE9BQWQ7QUFJRDs7OzZCQUVRRixDLEVBQUc7QUFDUkEsT0FBQyxDQUFDRyxjQUFGO0FBQ0EsVUFBTU4sTUFBTSxHQUFHLEtBQUs1QixLQUFMLENBQVdTLFVBQTFCO0FBQ0EsV0FBS2lCLFFBQUwsQ0FBYztBQUNaaEIsZUFBTyxFQUFFa0IsTUFERztBQUVaekIsWUFBSSxFQUFFLENBRk07QUFHWkYsZ0JBQVEsRUFBRSxFQUhFO0FBSVpDLG9CQUFZLEVBQUUsSUFKRjtBQUtaRSxnQkFBUSxFQUFFO0FBTEUsT0FBZDtBQU9BLFdBQUtOLEtBQUwsQ0FBV3FDLE9BQVgsQ0FBbUJDLElBQW5CLENBQXdCLHFCQUFtQixLQUFLcEMsS0FBTCxDQUFXSyxRQUE5QixHQUF1QyxXQUF2QyxHQUFtRCxLQUFLTCxLQUFMLENBQVdTLFVBQXRGO0FBRUgsSyxDQUVEOzs7O21DQUNjO0FBQ1osVUFBRzRCLDhDQUFDLENBQUMsY0FBRCxDQUFELENBQWtCQyxFQUFsQixDQUFxQixVQUFyQixDQUFILEVBQXFDO0FBQ25DRCxzREFBQyxDQUFDLGdCQUFELENBQUQsQ0FBb0JFLFlBQXBCLENBQWlDRiw4Q0FBQyxDQUFDLFlBQUQsQ0FBbEM7QUFDRCxPQUZELE1BR0s7QUFDSEEsc0RBQUMsQ0FBQyxnQkFBRCxDQUFELENBQW9CRSxZQUFwQixDQUFpQ0YsOENBQUMsQ0FBQyx3QkFBRCxDQUFsQztBQUNEO0FBQ0YsSyxDQUdEOzs7Ozs7Ozs7Ozs7O0FBRU1HLG1CLEdBQU1DLHFEQUFBLEdBQXVCLFk7QUFDN0J0QyxvQixHQUFPLEtBQUtILEtBQUwsQ0FBV0csSTtBQUNsQkUsd0IsR0FBVyxLQUFLTCxLQUFMLENBQVdLLFE7QUFDdEJLLHVCLEdBQVUsS0FBS1YsS0FBTCxDQUFXVSxPO0FBRXpCZ0MscUJBQUssQ0FBQ0MsR0FBTixDQUFVSCxHQUFWLEVBQWU7QUFBQ2pDLHdCQUFNLEVBQUU7QUFBQ0osd0JBQUksRUFBRUEsSUFBUDtBQUFhRSw0QkFBUSxFQUFFQSxRQUF2QjtBQUFpQ0ssMkJBQU8sRUFBRUE7QUFBMUM7QUFBVCxpQkFBZixFQUNDa0MsSUFERCxDQUNNLFVBQUM3QyxRQUFELEVBQWM7QUFDbEIsc0JBQU1FLFFBQVEsR0FBRyxNQUFJLENBQUNELEtBQUwsQ0FBV0MsUUFBNUI7QUFFQUYsMEJBQVEsQ0FBQ1ksSUFBVCxDQUFjQSxJQUFkLENBQW1Ca0MsS0FBbkIsQ0FBeUJDLEdBQXpCLENBQTZCLFVBQUNuQyxJQUFELEVBQVU7QUFDbkNWLDRCQUFRLENBQUNtQyxJQUFULENBQWN6QixJQUFkO0FBQ0gsbUJBRkQ7O0FBSUEsc0JBQUdaLFFBQVEsQ0FBQ1ksSUFBVCxDQUFjQSxJQUFkLENBQW1Cb0MsV0FBbkIsSUFBa0MsSUFBckMsRUFBMkM7QUFDdkMsMEJBQUksQ0FBQ3JCLFFBQUwsQ0FBYztBQUNaekIsOEJBQVEsRUFBRUEsUUFERTtBQUVaQyxrQ0FBWSxFQUFFLElBRkY7QUFHWkMsMEJBQUksRUFBRUEsSUFBSSxHQUFDO0FBSEMscUJBQWQ7QUFLSCxtQkFORCxNQU1PO0FBQ0wsd0JBQUdGLFFBQVEsQ0FBQytDLE1BQVQsSUFBbUIsQ0FBdEIsRUFBeUI7QUFDdkJ6Qiw2QkFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7O0FBQ0EsNEJBQUksQ0FBQ0UsUUFBTCxDQUFjO0FBQ1p4QixvQ0FBWSxFQUFFLEtBREY7QUFFWkUsZ0NBQVEsRUFBRTtBQUZFLHVCQUFkO0FBSUQscUJBTkQsTUFNTztBQUNMLDRCQUFJLENBQUNzQixRQUFMLENBQWM7QUFDWnhCLG9DQUFZLEVBQUU7QUFERix1QkFBZDtBQUdEO0FBQ0Y7QUFFRixpQkE1QkQsV0E0QlMsVUFBQStDLEtBQUssRUFBRztBQUNmO0FBQ0ExQix5QkFBTyxDQUFDQyxHQUFSLENBQVksWUFBWjtBQUNBMEIsMEVBQUEsQ0FBWSx1QkFBWjtBQUNELGlCQWhDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzZCQXFDTztBQUFBOztBQUNQLFVBQU1DLElBQUksR0FBRztBQUNYQyxhQUFLLEVBQUUseURBREk7QUFFWEQsWUFBSSxFQUFFO0FBQ0pFLGlCQUFPLEVBQUUsT0FETDtBQUVGQyxjQUFJLEVBQUU7QUFDSkMsb0JBQVEsRUFBRTtBQUROO0FBRko7QUFGSyxPQUFiOztBQVdBLFVBQU1DLE1BQU0sZ0JBQUc7QUFBSyxpQkFBUyxFQUFDLFFBQWY7QUFBQSxnQ0FBd0I7QUFBSyxtQkFBUyxFQUFDLFNBQWY7QUFBQSxrQ0FBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBekIsZUFBb0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBcEMsZUFBK0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBL0MsZUFBMEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FBZjs7QUFFQSxVQUFJQyxVQUFVLEdBQUcsRUFBakI7QUFDQSxXQUFLekQsS0FBTCxDQUFXQyxRQUFYLENBQW9CNkMsR0FBcEIsQ0FBd0IsVUFBQ1ksSUFBRCxFQUFPQyxLQUFQLEVBQWlCO0FBQ3ZDRixrQkFBVSxDQUFDckIsSUFBWCxlQUNFLDhEQUFDLDZEQUFEO0FBQU0sZ0JBQU0sTUFBWjtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxNQUFmO0FBQUEsb0NBQ0U7QUFBSSx1QkFBUyxFQUFDLHNDQUFkO0FBQUEscUNBQ0UsOERBQUMsbURBQUQ7QUFDRSxvQkFBSSxFQUFFLHFCQURSO0FBRUUsa0JBQUUsRUFBRSxrQkFBa0JzQixJQUFJLENBQUNsQixHQUY3QjtBQUFBLDBCQUlHa0IsSUFBSSxDQUFDTjtBQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURGLGVBU0U7QUFBSyx1QkFBUyxFQUFDLFVBQWY7QUFBQSxzQ0FDRSw4REFBQyxtREFBRDtBQUNFLG9CQUFJLEVBQUUscUJBRFI7QUFFRSxrQkFBRSxFQUFFLGtCQUFrQk0sSUFBSSxDQUFDbEIsR0FGN0I7QUFBQSx1Q0FJRTtBQUNFLDJCQUFTLEVBQUMsWUFEWjtBQUVFLHVCQUFLLEVBQUU7QUFDTG9CLG1DQUFlLEVBQ2JGLElBQUksQ0FBQ0csS0FBTCxJQUFjLElBQWQsR0FDSSxxQ0FESixpQkFFV0gsSUFBSSxDQUFDRyxLQUZoQjtBQUZHO0FBRlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFlRTtBQUFLLHlCQUFTLEVBQUMsa0JBQWY7QUFBQSwwQkFDR0gsSUFBSSxDQUFDSSxVQUFMLENBQWdCaEIsR0FBaEIsQ0FBb0IsVUFBQ2lCLEdBQUQsRUFBTUMsQ0FBTixFQUFZO0FBQy9CLHNDQUNFLDhEQUFDLG1EQUFEO0FBQ0Usd0JBQUksRUFBRSx1QkFEUjtBQUVFLHNCQUFFLEVBQUUsb0JBQW9CRCxHQUFHLENBQUN2RCxJQUY5QjtBQUdFLDZCQUFTLEVBQUMsc0JBSFo7QUFBQSw4QkFNR3VELEdBQUcsQ0FBQ1Q7QUFOUCxxQkFJT1UsQ0FKUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQURGO0FBVUQsaUJBWEE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFURixlQXVDRTtBQUFLLHVCQUFTLEVBQUMsV0FBZjtBQUFBLHNDQUNFO0FBQUkseUJBQVMsRUFBQyxzQ0FBZDtBQUFBLHVDQUNFLDhEQUFDLG1EQUFEO0FBQ0Usc0JBQUksRUFBRSxxQkFEUjtBQUVFLG9CQUFFLEVBQUUsa0JBQWtCTixJQUFJLENBQUNsQixHQUY3QjtBQUFBLDRCQUlHa0IsSUFBSSxDQUFDTjtBQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBU0U7QUFBTyx5QkFBUyxFQUFDLGlEQUFqQjtBQUFBLHdDQUNFO0FBQUcsMkJBQVMsRUFBQyxlQUFiO0FBQTZCLGlDQUFZO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsRUFDdUQsR0FEdkQsRUFFR00sSUFBSSxDQUFDTyxNQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFURixlQWFFO0FBQUcseUJBQVMsRUFBQyxXQUFiO0FBQUEsMEJBQTBCUCxJQUFJLENBQUNRO0FBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBYkYsZUFjRTtBQUFNLHlCQUFTLEVBQUMsVUFBaEI7QUFBQSx1Q0FDRSw4REFBQyxtREFBRDtBQUNFLHNCQUFJLEVBQUUscUJBRFI7QUFFRSxvQkFBRSxFQUFFLGtCQUFrQlIsSUFBSSxDQUFDbEIsR0FGN0I7QUFHRSwyQkFBUyxFQUFDLG1CQUhaO0FBQUEseUNBS0U7QUFBQSw0Q0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFERixFQUN5QixHQUR6QixlQUVFO0FBQUcsK0JBQVMsRUFBQyxxQkFBYjtBQUFtQyxxQ0FBWTtBQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkF2Q0Y7QUFBQSxhQUEyQm1CLEtBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGO0FBdUVELE9BeEVEO0FBZk8sVUF3RkpoRCxJQXhGSSxHQXdGSSxLQUFLWCxLQXhGVCxDQXdGSlcsSUF4Rkk7QUF5RlAsMEJBQ0U7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBMkIsVUFBRSxFQUFDLFdBQTlCO0FBQUEsZ0NBQ0UsOERBQUMsMkRBQUQ7QUFBZ0Isb0JBQVUsRUFBRXdELGtEQUFLQTtBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUsOERBQUMseURBQUQsb0JBQWtCaEIsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRixlQUdFLDhEQUFDLGtFQUFEO0FBQVEsZUFBSyxFQUFFeEMsSUFBSSxDQUFDeUMsS0FBcEI7QUFBMkIscUJBQVcsRUFBRXpDLElBQUksQ0FBQ3lELFdBQTdDO0FBQTBELGtCQUFRLEVBQUV6RCxJQUFJLENBQUM0QztBQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUhGLGVBSUU7QUFBUyxtQkFBTSxtQkFBZjtBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxxQ0FBZjtBQUFBLG1DQUNFO0FBQUssdUJBQVMsRUFBQyxrQkFBZjtBQUFBLHFDQUNFO0FBQUsseUJBQVMsRUFBQyxzQkFBZjtBQUFBLHVDQUNFO0FBQUssMkJBQVMsRUFBQyxZQUFmO0FBQUEseUNBQ0U7QUFBSyw2QkFBUyxFQUFDLDZEQUFmO0FBQUEsNENBQ0U7QUFBSywrQkFBUyxFQUFDLG9CQUFmO0FBQUEsOENBQ0U7QUFBRyxpQ0FBUyxFQUFDLHVDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURGLGVBSUU7QUFDRSxpQ0FBUyxFQUFDLGdDQURaO0FBRUUsNkJBQUssRUFBRTtBQUFFYyx1Q0FBYSxFQUFFO0FBQWpCLHlCQUZUO0FBQUEsa0NBSUcsS0FBS3JFLEtBQUwsQ0FBV0s7QUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFERixlQVlFO0FBQUssK0JBQVMsRUFBQyxpQ0FBZjtBQUFBLDZDQUNFO0FBQUcsaUNBQVMsRUFBQyx3Q0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQTZCRTtBQUFLLHFCQUFTLEVBQUMsY0FBZjtBQUFBLG1DQUNFO0FBQUssdUJBQVMsRUFBQyxXQUFmO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLGFBQWY7QUFBQSx3Q0FDRTtBQUFLLDJCQUFTLEVBQUMsb0NBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsV0FBZjtBQUFBLDJDQUNFO0FBQUssK0JBQVMsRUFBQyxXQUFmO0FBQUEsOENBQ0UsOERBQUMsaUVBQUQ7QUFDRSxtQ0FBVyxFQUFFLElBRGY7QUFFRSxnQ0FBUSxFQUFFLEtBQUtTLFlBRmpCO0FBR0UsK0JBQU8sRUFBRSxLQUFLZCxLQUFMLENBQVdFLFlBSHRCO0FBSUUsOEJBQU0sRUFBRXNELE1BSlY7QUFBQSxrQ0FNR0M7QUFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURGLGVBU0U7QUFBQSxrQ0FBSSxLQUFLekQsS0FBTCxDQUFXSTtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFpQkU7QUFBSywyQkFBUyxFQUFDLG9DQUFmO0FBQUEseUNBQ0U7QUFBSyw2QkFBUyxFQUFDLGNBQWY7QUFBQSwyQ0FDRTtBQUFBLDhDQUNFO0FBQ0UsMEJBQUUsRUFBQyxVQURMO0FBRUUsaUNBQVMsRUFBQyxtQ0FGWjtBQUFBLCtDQUlFO0FBQ0UsOEJBQUksRUFBQyxRQURQO0FBRUUsNEJBQUUsRUFBQyxZQUZMO0FBR0UsbUNBQVMsRUFBQyxZQUhaO0FBSUUsa0NBQVEsRUFBRSxLQUFLWSxRQUpqQjtBQUFBLGlEQU1FO0FBQUEsb0RBQ0U7QUFDRSxrQ0FBSSxFQUFDLE1BRFA7QUFFRSxrQ0FBSSxFQUFDLEdBRlA7QUFHRSxnQ0FBRSxFQUFDLGFBSEw7QUFJRSx5Q0FBVyxFQUFDLFFBSmQ7QUFLRSx1Q0FBUyxFQUFDLGFBTFo7QUFNRSxtQ0FBSyxFQUFFLEtBQUtoQixLQUFMLENBQVdTLFVBTnBCO0FBT0Usc0NBQVEsRUFBRSxLQUFLTTtBQVBqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQURGLGVBVUU7QUFBUSxrQ0FBSSxFQUFDLFFBQWI7QUFBc0Isa0NBQUksRUFBQyxlQUEzQjtBQUFBLHFEQUNFO0FBQ0UseUNBQVMsRUFBQyxjQURaO0FBRUUsK0NBQVk7QUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFERixlQThCRSw4REFBQyx1RUFBRDtBQUNFLGdDQUFRLEVBQUUsS0FBS2YsS0FBTCxDQUFXSztBQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQTlCRixlQWlDRSw4REFBQyx5RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRixlQStGRTtBQUFLLG1CQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQS9GRixlQWdHRSw4REFBQyxrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWhHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERjtBQW9HRDs7OztFQW5VdUNpRSw2QyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9ibG9nL2NhdGVnb3J5L1tzbHVnXS41YzExMTRlMzgyMmFkNmU3MjdiOS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEhlYWRlciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2hlYWRlci9pbmRleC5qc3gnO1xyXG5pbXBvcnQgRm9vdGVyIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvZm9vdGVyL2luZGV4LmpzeCc7XHJcbmltcG9ydCBVbmRlcmNvbnN0cnVjdGlvbiBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VuZGVyLWNvbnN0cnVjdGlvbi9pbmRleC5qc3gnO1xyXG5pbXBvcnQgQmxvZ0NhdGVnb3JpZXMgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9wb3N0LWNhdGVnb3J5L2luZGV4LmpzeCc7XHJcbmltcG9ydCBCbG9nUmVjZW50UG9zdHMgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9wb3N0LXJlY2VudC9pbmRleC5qc3gnO1xyXG5pbXBvcnQgRG9jdW1lbnRNZXRhIGZyb20gJ3JlYWN0LWRvY3VtZW50LW1ldGEnO1xyXG5pbXBvcnQgeyBUb2FzdENvbnRhaW5lciwgdG9hc3QsIFNsaWRlIH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xyXG5pbXBvcnQgJ3JlYWN0LXRvYXN0aWZ5L2Rpc3QvUmVhY3RUb2FzdGlmeS5jc3MnO1xyXG5pbXBvcnQgSW5maW5pdGVTY3JvbGwgZnJvbSAncmVhY3QtaW5maW5pdGUtc2Nyb2xsZXInO1xyXG5pbXBvcnQgJCBmcm9tICdqcXVlcnknO1xyXG5pbXBvcnQgQXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBodHRwcyBmcm9tIFwiaHR0cHNcIjtcclxuaW1wb3J0ICogYXMgY29uZmlnIGZyb20gJy4uLy4uLy4uL2NvbmZpZyc7XHJcbmltcG9ydCBxdWVyeVN0cmluZyBmcm9tICdxdWVyeS1zdHJpbmcnO1xyXG5pbXBvcnQgRmxpcCBmcm9tICdyZWFjdC1yZXZlYWwvUmV2ZWFsJztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5cclxucmVxdWlyZSgndHlwZWZhY2UtbW9udHNlcnJhdCcpXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoKSB7XHJcbiAgbGV0IGRhdGEgPSBbXTtcclxuXHJcbiAgY29uc3QgaW5zdGFuY2UgPSBBeGlvcy5jcmVhdGUoe1xyXG4gICAgaHR0cHNBZ2VudDogbmV3IGh0dHBzLkFnZW50KHtcclxuICAgICAgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZSxcclxuICAgIH0pLFxyXG4gIH0pO1xyXG5cclxuICBhd2FpdCBpbnN0YW5jZVxyXG4gICAgLmdldChcImh0dHBzOi8vYXBpLmhhc2h0YWctY2EuY29tL2FwaS92MS9tZXRhZGF0YVwiLCB7XHJcbiAgICAgIHBhcmFtczoge1xyXG4gICAgICAgIHBhZ2VfdHlwZTogXCJzdGF0aWNcIixcclxuICAgICAgICBzbHVnOiBcInNldmljZXNcIixcclxuICAgICAgfSxcclxuICAgIH0pXHJcbiAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgZGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgICB9KTtcclxuICByZXR1cm4ge1xyXG4gICAgcHJvcHM6IHsgZGF0YSB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEJsb2dDYXRlZ29yeSBleHRlbmRzIENvbXBvbmVudCB7XHJcblxyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9wcykge1xyXG4gICAgc3VwZXIocHJvcHMpO1xyXG5pZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG4gIGdsb2JhbC53aW5kb3cgPSB7fTtcclxuICAgIH1cclxuICAgIGxldCByZXNwb25zZSA9IHRoaXMucHJvcHNcclxuICAgIHRoaXMuc3RhdGUgPSB7XHJcbiAgICAgIGFsbFBvc3RzOiBbXSxcclxuICAgICAgaGFzTW9yZUl0ZW1zOiB0cnVlLFxyXG4gICAgICBwYWdlOjEsXHJcbiAgICAgIG5vX2l0ZW1zOiAnJyxcclxuICAgICAgY2F0ZWdvcnk6IHRoaXMucHJvcHMubWF0Y2gucGFyYW1zLnNsdWcsXHJcbiAgICAgIHNlYXJjaF92YWw6ICcnLFxyXG4gICAgICBrZXl3b3JkOiAnJyxcclxuICAgICAgZGF0YTogcmVzcG9uc2UuZGF0YS5kYXRhLFxyXG4gICAgfTtcclxuXHJcblxyXG4gICAgdGhpcy5zaGlmdENvbnRlbnQgPSB0aGlzLnNoaWZ0Q29udGVudC5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5nZXRfYWxsUG9zdHMgPSB0aGlzLmdldF9hbGxQb3N0cy5iaW5kKHRoaXMpO1xyXG5cclxuICAgIHRoaXMuaGFuZGxlQ2hhbmdlID0gdGhpcy5oYW5kbGVDaGFuZ2UuYmluZCh0aGlzKTtcclxuICAgIHRoaXMub25TdWJtaXQgPSB0aGlzLm9uU3VibWl0LmJpbmQodGhpcyk7XHJcbiAgfVxyXG5cclxuICBjb21wb25lbnREaWRNb3VudCgpIHtcclxuICAgIHRoaXMuc2hpZnRDb250ZW50KCk7XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHRoaXMuc2hpZnRDb250ZW50KTtcclxuICAgIH1cclxuICAgIGlmICh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUpIHtcclxuICAgICAgbGV0IHBhdGhOYW1lcyA9IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5zcGxpdChcIi9cIik7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwicGF0aFwiLCBwYXRoTmFtZXMpO1xyXG4gICAgICBsZXQgc2luZ2xlUG9zdCA9IHBhdGhOYW1lc1szXTtcclxuICAgICAgdGhpcy5zZXRTdGF0ZSh7IGNhdGVnb3J5OiBzaW5nbGVQb3N0IH0pO1xyXG4gICAgICBcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbXBvbmVudFdpbGxNb3VudCgpe1xyXG4gICAgaWYodGhpcy5wcm9wcy5sb2NhdGlvbi5zZWFyY2gpe1xyXG4gICAgICBjb25zdCB2YWx1ZXMgPSBxdWVyeVN0cmluZy5wYXJzZSh0aGlzLnByb3BzLmxvY2F0aW9uLnNlYXJjaCk7XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgIGtleXdvcmQ6IHZhbHVlcy5rZXl3b3JkLFxyXG4gICAgICAgIHNlYXJjaF92YWw6IHZhbHVlcy5rZXl3b3JkXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHRoaXMuc2hpZnRDb250ZW50KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGhhbmRsZUNoYW5nZShlKSB7XHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgc2VhcmNoX3ZhbDogZS50YXJnZXQudmFsdWVcclxuICAgIH0pO1xyXG5cclxuICB9XHJcblxyXG4gIG9uU3VibWl0KGUpIHtcclxuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICBjb25zdCB2YWx1ZXMgPSB0aGlzLnN0YXRlLnNlYXJjaF92YWw7XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgIGtleXdvcmQ6IHZhbHVlcyxcclxuICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgIGFsbFBvc3RzOiBbXSxcclxuICAgICAgICBoYXNNb3JlSXRlbXM6IHRydWUsXHJcbiAgICAgICAgbm9faXRlbXM6ICcnXHJcbiAgICAgIH0pO1xyXG4gICAgICB0aGlzLnByb3BzLmhpc3RvcnkucHVzaCgnL2Jsb2dzL2NhdGVnb3J5LycrdGhpcy5zdGF0ZS5jYXRlZ29yeSsnP2tleXdvcmQ9Jyt0aGlzLnN0YXRlLnNlYXJjaF92YWwpO1xyXG4gICAgICBcclxuICB9XHJcblxyXG4gIC8vU2VhcmNoIGRpdiBzaGlmdFxyXG4gIHNoaWZ0Q29udGVudCgpe1xyXG4gICAgaWYoJChcIi5tb2ItdmlzaWJsZVwiKS5pcyhcIjp2aXNpYmxlXCIpKSB7IFxyXG4gICAgICAkKCcud2lkZ2V0X3NlYXJjaCcpLmluc2VydEJlZm9yZSgkKCcuYmxvZy1saXN0JykpO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgICQoJy53aWRnZXRfc2VhcmNoJykuaW5zZXJ0QmVmb3JlKCQoJy53aWRnZXRfcmVjZW50X2VudHJpZXMnKSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuXHJcbiAgLy9HZXQgcG9zdHNcclxuICBhc3luYyBnZXRfYWxsUG9zdHMoKXtcclxuICAgIHZhciB1cmwgPSBjb25maWcubXlDb25maWcuYXBpVXJsKydibG9nL3Bvc3RzJztcclxuICAgIHZhciBwYWdlID0gdGhpcy5zdGF0ZS5wYWdlO1xyXG4gICAgdmFyIGNhdGVnb3J5ID0gdGhpcy5zdGF0ZS5jYXRlZ29yeTtcclxuICAgIHZhciBrZXl3b3JkID0gdGhpcy5zdGF0ZS5rZXl3b3JkO1xyXG5cclxuICAgIGF4aW9zLmdldCh1cmwsIHtwYXJhbXM6IHtwYWdlOiBwYWdlLCBjYXRlZ29yeTogY2F0ZWdvcnksIGtleXdvcmQ6IGtleXdvcmR9fSlcclxuICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICBjb25zdCBhbGxQb3N0cyA9IHRoaXMuc3RhdGUuYWxsUG9zdHM7XHJcblxyXG4gICAgICByZXNwb25zZS5kYXRhLmRhdGEucG9zdHMubWFwKChkYXRhKSA9PiB7XHJcbiAgICAgICAgICBhbGxQb3N0cy5wdXNoKGRhdGEpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmKHJlc3BvbnNlLmRhdGEuZGF0YS5tb3JlX2V4aXN0cyA9PSB0cnVlKSB7XHJcbiAgICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgICAgYWxsUG9zdHM6IGFsbFBvc3RzLFxyXG4gICAgICAgICAgICBoYXNNb3JlSXRlbXM6IHRydWUsXHJcbiAgICAgICAgICAgIHBhZ2U6IHBhZ2UrMVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYoYWxsUG9zdHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKCdObyBwb3N0cyBmb3VuZC4nKTtcclxuICAgICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICBoYXNNb3JlSXRlbXM6IGZhbHNlLFxyXG4gICAgICAgICAgICBub19pdGVtczogJ05vIHBvc3RzIGZvdW5kLidcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgICAgaGFzTW9yZUl0ZW1zOiBmYWxzZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBcclxuICAgIH0pLmNhdGNoKGVycm9yID0+e1xyXG4gICAgICAvLyBjb25zb2xlLmxvZyhlcnJvci5yZXNwb25zZSk7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdBUEkgZXJyb3IuJyk7XHJcbiAgICAgIHRvYXN0LmVycm9yKFwiU29tZXRoaW5nIHdlbnQgd3JvbmcuXCIpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuXHJcblxyXG4gIHJlbmRlcigpIHtcclxuICAgIGNvbnN0IG1ldGEgPSB7XHJcbiAgICAgIHRpdGxlOiAnQmxvZ3MgLSBGdWxsU3RhY2sgV2ViIERldmVsb3BtZW50fCBCYXkgYXJlYSwgQ2FsaWZvcm5pYScsXHJcbiAgICAgIG1ldGE6IHtcclxuICAgICAgICBjaGFyc2V0OiAndXRmLTgnLFxyXG4gICAgICAgICAgbmFtZToge1xyXG4gICAgICAgICAgICBrZXl3b3JkczogJ1dlYiBkZXZlbG9wbWVudCBjb21wYW55LHNvZnR3YXJlIGRldmVsb3BtZW50IGNvbXBhbnksd2ViIGRldmVsb3BtZW50IGtvY2hpLHdlYiBkZXZlbG9wbWVudCBjb21wYW55IGtvY2hpLHNvZnR3YXJlIGRldmVsb3BtZW50IGtvY2hpLHdlYiBkZXZlbG9wbWVudCBjb21wYW55IGtvY2hpLHNvZnR3YXJlIGRldmVsb3BtZW50IGtvY2hpLHdlYiBkZXNpZ24gYW5kIGRldmVsb3BtZW50IGtvY2hpLGZ1bGwgc3RhY2sgZGV2ZWxvcG1lbnQgY29tcGFueSx3b3JkcHJlc3MgY3VzdG9taXNhdGlvbiBjb21wYW55IGtlcmFsYSxzaG9waWZ5IHRoZW1lIGRldmVsb3BtZW50IGNvbXBhbnkga2VyYWxhLGVjb21tZXJjZSBkZXZlbG9wbWVudCBjb21wYW55IGtlcmFsYSx3b29jb21tZXJjZSBkZXZlbG9wbWVudCBjb21wYW55IGtlcmFsYSx3ZWIgZGV2ZWxvcG1lbnQgY29tcGFueSBDYWxpZm9ybmlhLHNvZnR3YXJlIGRldmVsb3BtZW50IGNhbGlmb3JuaWEsd29yZHByZXNzIGRldmVsb3BtZW50IGNhbGlmb3JuaWEsd29yZHByZXNzIGRldmVsb3BtZW50IGtvY2hpLHNob3BpZnkgZGV2ZWxvcG1lbnQga29jaGksc2hvcGlmeSBkZXZlbG9wbWVudCBjYWxpZm9ybmlhLHdvcmRwcmVzcyBjdXN0b21pc2F0aW9uIGNvbXBhbnksc2hvcGlmeSB0aGVtZSBkZXZlbG9wbWVudCBjb21wYW55LGVjb21tZXJjZSBkZXZlbG9wbWVudCBjb21wYW55IGtvY2hpLGVjb21tZXJjZSBkZXZlbG9wbWVudCBjb21wYW55IGNhbGlmb3JuaWEnXHJcbiAgICAgICAgfVxyXG4gICAgICAgXHJcbiAgICAgICBcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGNvbnN0IGxvYWRlciA9IDxkaXYgY2xhc3NOYW1lPVwibG9hZGVyXCI+PGRpdiBjbGFzc05hbWU9XCJzcGlubmVyXCI+PGRpdj48L2Rpdj48ZGl2PjwvZGl2PjxkaXY+PC9kaXY+PGRpdj48L2Rpdj48L2Rpdj5Mb2FkaW5nPC9kaXY+O1xyXG5cclxuICAgIHZhciBwb3N0X2xpc3RzID0gW107XHJcbiAgICB0aGlzLnN0YXRlLmFsbFBvc3RzLm1hcCgocG9zdCwgaW5kZXgpID0+IHtcclxuICAgICAgcG9zdF9saXN0cy5wdXNoKFxyXG4gICAgICAgIDxGbGlwIGJvdHRvbT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZFwiIGtleT17aW5kZXh9PlxyXG4gICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwiY2FyZC10aXRsZSB0ZXh0LWxldmVsLTQgdGl0bGUtb3JhbmdlXCI+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvc2luZ2xlL1tzbHVnXVwifVxyXG4gICAgICAgICAgICAgICAgYXM9e1wiL2Jsb2cvc2luZ2xlL1wiICsgcG9zdC51cmx9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3Bvc3QudGl0bGV9XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2g1PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctaW1nXCI+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvc2luZ2xlL1tpZGV4XVwifVxyXG4gICAgICAgICAgICAgICAgYXM9e1wiL2Jsb2cvc2luZ2xlL1wiICsgcG9zdC51cmx9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9nLXRodW1iXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6XHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3N0LmltYWdlID09IG51bGxcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcIi9pbWFnZXMvYmxvZ3Mvd3JpdGluZy1nb29kLWJsb2cuanBnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBgdXJsKCR7cG9zdC5pbWFnZX0pYCxcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWltZy1vdmVybGF5XCI+XHJcbiAgICAgICAgICAgICAgICB7cG9zdC5jYXRlZ29yaWVzLm1hcCgoY2F0LCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvY2F0ZWdvcnkvW3NsdWddXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBhcz17XCIvYmxvZy9jYXRlZ29yeS9cIiArIGNhdC5zbHVnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi1saWdodCBidG4tc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjYXQubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImNhcmQtdGl0bGUgdGV4dC1sZXZlbC00IHRpdGxlLW9yYW5nZVwiPlxyXG4gICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgaHJlZj17XCIvYmxvZy9zaW5nbGUvW3NsdWddXCJ9XHJcbiAgICAgICAgICAgICAgICAgIGFzPXtcIi9ibG9nL3NpbmdsZS9cIiArIHBvc3QudXJsfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7cG9zdC50aXRsZX1cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgIDxzbWFsbCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkIGNhdCB0ZXh0LWFib3ZlLW1haW4tdGl0bGUgYXV0aG9yLWJsa1wiPlxyXG4gICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtaGFzaHRhZ1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICB7cG9zdC5hdXRob3J9XHJcbiAgICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJjYXJkLXRleHRcIj57cG9zdC5leGNlcnB0fTwvcD5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjdGEtbGlua1wiPlxyXG4gICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgaHJlZj17XCIvYmxvZy9zaW5nbGUvW3NsdWddXCJ9XHJcbiAgICAgICAgICAgICAgICAgIGFzPXtcIi9ibG9nL3NpbmdsZS9cIiArIHBvc3QudXJsfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaG9waWZ5LXN1Yi10aXRsZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxhPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlYWQgTW9yZTwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtY2hldnJvbi1yaWdodFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0ZsaXA+XHJcbiAgICAgICk7XHJcbiAgICB9KTtcclxuY29uc3Qge2RhdGF9ID0gdGhpcy5zdGF0ZVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLW1haW5cIiBpZD1cImJsb2ctbWFpblwiPlxyXG4gICAgICAgIDxUb2FzdENvbnRhaW5lciB0cmFuc2l0aW9uPXtTbGlkZX0gLz5cclxuICAgICAgICA8RG9jdW1lbnRNZXRhIHsuLi5tZXRhfSAvPlxyXG4gICAgICAgIDxIZWFkZXIgdGl0bGU9e2RhdGEudGl0bGV9IGRlc2NyaXB0aW9uPXtkYXRhLmRlc2NyaXB0aW9ufSBrZXl3b3Jkcz17ZGF0YS5rZXl3b3Jkc30+PC9IZWFkZXI+XHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3M9XCJjb250ZW50LWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItZmx1aWQgc2VydmljZS1iZyBwLTAgbS0wIFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmctcmlnaHRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtYmFubmVyLWZyYW1lXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cganVzdGlmeS1jb250ZW50LWNlbnRlciBzZXJ2aWNlLWJhbm5lci1jb250ZW50IHBsLTMgcHItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzdWItdGV4dC1hYm92ZS1tYWluLXRpdGxlIHRpdGxlLXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEJsb2dzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDFcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWFpbi10aXRsZSB0aXRsZS13aGl0ZSBkLWJsb2NrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgdGV4dFRyYW5zZm9ybTogXCJjYXBpdGFsaXplXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3RoaXMuc3RhdGUuY2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLWxnLTYgY29sLW1kLTEyIHRleHQtd2hpdGUgIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYm9sZC1jb250ZW50cyBzZXJ2aWNlLWNvbnRlbnQtYm94IHBsLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgV2UgYXJlIHNlZWtpbmcgYnJpbGxpYW50IG1pbmRzIHRvIGpvaW4gb3VyIGR5bmFtaWMgdGVhbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmQgbWFrZSBpdCBldmVuIGJldHRlci5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGItcm93LTFcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1zbS0xMiBjb2wtbWQtOCBjb2wtbGctOFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5maW5pdGVTY3JvbGxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW5pdGlhbExvYWQ9e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRNb3JlPXt0aGlzLmdldF9hbGxQb3N0c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFzTW9yZT17dGhpcy5zdGF0ZS5oYXNNb3JlSXRlbXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRlcj17bG9hZGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cG9zdF9saXN0c31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvSW5maW5pdGVTY3JvbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cD57dGhpcy5zdGF0ZS5ub19pdGVtc308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLXNtLTEyIGNvbC1tZC00IGNvbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1zaWRlYmFyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGFzaWRlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInNlYXJjaC00XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwid2lkZ2V0IHdpZGdldF9zZWFyY2ggcG9zdHNfaG9sZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlPVwic2VhcmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInNlYXJjaGZvcm1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNlYXJjaGZvcm1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uU3VibWl0PXt0aGlzLm9uU3VibWl0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJibG9nLXNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicGxhY2Vob2xkZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGhpcy5zdGF0ZS5zZWFyY2hfdmFsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgbmFtZT1cInNlYXJjaC1zdWJtaXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmYSBmYS1zZWFyY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QmxvZ1JlY2VudFBvc3RzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5PXt0aGlzLnN0YXRlLmNhdGVnb3J5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPjwvQmxvZ1JlY2VudFBvc3RzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJsb2dDYXRlZ29yaWVzPjwvQmxvZ0NhdGVnb3JpZXM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2ItdmlzaWJsZVwiPjwvZGl2PlxyXG4gICAgICAgIDxGb290ZXI+PC9Gb290ZXI+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==