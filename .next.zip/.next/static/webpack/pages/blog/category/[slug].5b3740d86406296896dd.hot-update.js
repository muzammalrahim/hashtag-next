self["webpackHotUpdate_N_E"]("pages/blog/category/[slug]",{

/***/ "./pages/blog/category/[slug].jsx":
/*!****************************************!*\
  !*** ./pages/blog/category/[slug].jsx ***!
  \****************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ BlogCategory; }
/* harmony export */ });
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_header_index_jsx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../components/header/index.jsx */ "./components/header/index.jsx");
/* harmony import */ var _components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/footer/index.jsx */ "./components/footer/index.jsx");
/* harmony import */ var _components_under_construction_index_jsx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../components/under-construction/index.jsx */ "./components/under-construction/index.jsx");
/* harmony import */ var _components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../components/post-category/index.jsx */ "./components/post-category/index.jsx");
/* harmony import */ var _components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../components/post-recent/index.jsx */ "./components/post-recent/index.jsx");
/* harmony import */ var react_document_meta__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-document-meta */ "./node_modules/react-document-meta/dist/index.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react-infinite-scroller */ "./node_modules/react-infinite-scroller/index.js");
/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_infinite_scroller__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../config */ "./config.js");
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! query-string */ "./node_modules/query-string/index.js");
/* harmony import */ var react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! react-reveal/Reveal */ "./node_modules/react-reveal/Reveal.js");
/* harmony import */ var react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_24__);
/* module decorator */ module = __webpack_require__.hmd(module);










var _jsxFileName = "E:\\Projects\\hashtag\\hashtag\\pages\\blog\\category\\[slug].jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }


















__webpack_require__(/*! typeface-montserrat */ "./node_modules/typeface-montserrat/index.css");

var __N_SSP = true;

var BlogCategory = /*#__PURE__*/function (_Component) {
  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__.default)(BlogCategory, _Component);

  var _super = _createSuper(BlogCategory);

  function BlogCategory(props) {
    var _this$props, _this$props$match, _this$props$match$par;

    var _this;

    (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_4__.default)(this, BlogCategory);

    _this = _super.call(this, props);

    if (false) {}

    var response = _this.props;
    _this.state = {
      allPosts: [],
      hasMoreItems: true,
      page: 1,
      no_items: '',
      category: (_this$props = _this.props) === null || _this$props === void 0 ? void 0 : (_this$props$match = _this$props.match) === null || _this$props$match === void 0 ? void 0 : (_this$props$match$par = _this$props$match.params) === null || _this$props$match$par === void 0 ? void 0 : _this$props$match$par.slug,
      search_val: '',
      keyword: '',
      data: response.data.data
    };
    _this.shiftContent = _this.shiftContent.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    _this.get_allPosts = _this.get_allPosts.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    _this.handleChange = _this.handleChange.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    _this.onSubmit = _this.onSubmit.bind((0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__.default)(_this));
    return _this;
  }

  (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__.default)(BlogCategory, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.shiftContent();

      if (true) {
        window.addEventListener("resize", this.shiftContent);
      }

      if (window.location.pathname) {
        var pathNames = window.location.pathname.split("/");
        console.log("path", pathNames);
        var singlePost = pathNames[3];
        console.log(singlePost);
        this.setState({
          category: singlePost
        });
      }
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      if (this.props.location && this.props.location.search) {
        var values = query_string__WEBPACK_IMPORTED_MODULE_22__.parse(this.props.location.search);
        this.setState({
          keyword: values.keyword,
          search_val: values.keyword
        });
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (true) {
        window.removeEventListener("resize", this.shiftContent);
      }
    }
  }, {
    key: "handleChange",
    value: function handleChange(e) {
      this.setState({
        search_val: e.target.value
      });
    }
  }, {
    key: "onSubmit",
    value: function onSubmit(e) {
      e.preventDefault();
      var values = this.state.search_val;
      this.setState({
        keyword: values,
        page: 1,
        allPosts: [],
        hasMoreItems: true,
        no_items: ''
      });
      this.props.history.push('/blogs/category/' + this.state.category + '?keyword=' + this.state.search_val);
    } //Search div shift

  }, {
    key: "shiftContent",
    value: function shiftContent() {
      if (jquery__WEBPACK_IMPORTED_MODULE_19___default()(".mob-visible").is(":visible")) {
        jquery__WEBPACK_IMPORTED_MODULE_19___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_19___default()('.blog-list'));
      } else {
        jquery__WEBPACK_IMPORTED_MODULE_19___default()('.widget_search').insertBefore(jquery__WEBPACK_IMPORTED_MODULE_19___default()('.widget_recent_entries'));
      }
    } //Get posts

  }, {
    key: "get_allPosts",
    value: function () {
      var _get_allPosts = (0,E_Projects_hashtag_hashtag_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__.default)( /*#__PURE__*/E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee() {
        var _this2 = this;

        var url, page, category, keyword;
        return E_Projects_hashtag_hashtag_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                url = _config__WEBPACK_IMPORTED_MODULE_21__.myConfig.apiUrl + 'blog/posts';
                page = this.state.page;
                category = this.state.category;
                keyword = this.state.keyword;
                axios__WEBPACK_IMPORTED_MODULE_20___default().get(url, {
                  params: {
                    page: page,
                    category: category,
                    keyword: keyword
                  }
                }).then(function (response) {
                  var allPosts = _this2.state.allPosts;
                  response.data.data.posts.map(function (data) {
                    allPosts.push(data);
                  });

                  if (response.data.data.more_exists == true) {
                    _this2.setState({
                      allPosts: allPosts,
                      hasMoreItems: true,
                      page: page + 1
                    });
                  } else {
                    if (allPosts.length == 0) {
                      console.log('No posts found.');

                      _this2.setState({
                        hasMoreItems: false,
                        no_items: 'No posts found.'
                      });
                    } else {
                      _this2.setState({
                        hasMoreItems: false
                      });
                    }
                  }
                })["catch"](function (error) {
                  // console.log(error.response);
                  console.log('API error.');
                  react_toastify__WEBPACK_IMPORTED_MODULE_25__.toast.error("Something went wrong.");
                });

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function get_allPosts() {
        return _get_allPosts.apply(this, arguments);
      }

      return get_allPosts;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var meta = {
        title: 'Blogs - FullStack Web Development| Bay area, California',
        meta: {
          charset: 'utf-8',
          name: {
            keywords: 'Web development company,software development company,web development kochi,web development company kochi,software development kochi,web development company kochi,software development kochi,web design and development kochi,full stack development company,wordpress customisation company kerala,shopify theme development company kerala,ecommerce development company kerala,woocommerce development company kerala,web development company California,software development california,wordpress development california,wordpress development kochi,shopify development kochi,shopify development california,wordpress customisation company,shopify theme development company,ecommerce development company kochi,ecommerce development company california'
          }
        }
      };

      var loader = /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "loader",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "spinner",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 191,
            columnNumber: 69
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 191,
            columnNumber: 80
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 191,
            columnNumber: 91
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 191,
            columnNumber: 102
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 191,
          columnNumber: 44
        }, this), "Loading"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 191,
        columnNumber: 20
      }, this);

      var post_lists = [];
      this.state.allPosts.map(function (post, index) {
        post_lists.push( /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((react_reveal_Reveal__WEBPACK_IMPORTED_MODULE_23___default()), {
          bottom: true,
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
            className: "card",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h5", {
              className: "card-title text-level-4 title-orange",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_24___default()), {
                href: "/blog/single/[slug]",
                as: "/blog/single/" + post.url,
                children: post.title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 199,
                columnNumber: 15
              }, _this3)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 198,
              columnNumber: 13
            }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "blog-img",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_24___default()), {
                href: "/blog/single/[idex]",
                as: "/blog/single/" + post.url,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "blog-thumb",
                  style: {
                    backgroundImage: post.image == null ? "/images/blogs/writing-good-blog.jpg" : "url(".concat(post.image, ")")
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 211,
                  columnNumber: 17
                }, _this3)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 207,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                className: "card-img-overlay",
                children: post.categories.map(function (cat, i) {
                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_24___default()), {
                    href: "/blog/category/[slug]",
                    as: "/blog/category/" + cat.slug,
                    className: "btn btn-light btn-sm",
                    children: cat.name
                  }, i, false, {
                    fileName: _jsxFileName,
                    lineNumber: 224,
                    columnNumber: 21
                  }, _this3);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 221,
                columnNumber: 15
              }, _this3)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 206,
              columnNumber: 13
            }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "card-body",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h4", {
                className: "card-title text-level-4 title-orange",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_24___default()), {
                  href: "/blog/single/[slug]",
                  as: "/blog/single/" + post.url,
                  children: post.title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 238,
                  columnNumber: 17
                }, _this3)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 237,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("small", {
                className: "text-muted cat text-above-main-title author-blk",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("i", {
                  className: "fa fa-hashtag",
                  "aria-hidden": "true"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 246,
                  columnNumber: 17
                }, _this3), " ", post.author]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 245,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                className: "card-text",
                children: post.excerpt
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 249,
                columnNumber: 15
              }, _this3), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
                className: "cta-link",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_24___default()), {
                  href: "/blog/single/[slug]",
                  as: "/blog/single/" + post.url,
                  className: "shopify-sub-title",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("a", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
                      children: "Read More"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 257,
                      columnNumber: 21
                    }, _this3), " ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("i", {
                      className: "fa fa-chevron-right",
                      "aria-hidden": "true"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 258,
                      columnNumber: 21
                    }, _this3)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 256,
                    columnNumber: 19
                  }, _this3)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 251,
                  columnNumber: 17
                }, _this3)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 250,
                columnNumber: 15
              }, _this3)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 236,
              columnNumber: 13
            }, _this3)]
          }, index, true, {
            fileName: _jsxFileName,
            lineNumber: 197,
            columnNumber: 11
          }, _this3)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 196,
          columnNumber: 9
        }, _this3));
      });
      var data = this.state.data;
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "blog-main",
        id: "blog-main",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_toastify__WEBPACK_IMPORTED_MODULE_25__.ToastContainer, {
          transition: react_toastify__WEBPACK_IMPORTED_MODULE_25__.Slide
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 270,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_document_meta__WEBPACK_IMPORTED_MODULE_16__.default, _objectSpread({}, meta), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 271,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_header_index_jsx__WEBPACK_IMPORTED_MODULE_11__.default, {
          title: data.title,
          description: data.description,
          keywords: data.keywords
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 272,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("section", {
          "class": "content-container",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
            className: "container-fluid service-bg p-0 m-0 ",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "service-bg-right",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                className: "service-banner-frame",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "container ",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                    className: "row justify-content-center service-banner-content pl-3 pr-3",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                        className: "sub-text-above-main-title title-white",
                        children: "Blogs"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 280,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h1", {
                        className: "main-title title-white d-block",
                        style: {
                          textTransform: "capitalize"
                        },
                        children: this.state.category
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 283,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 279,
                      columnNumber: 21
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                      className: "col-lg-6 col-md-12 text-white  ",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                        className: "bold-contents service-content-box pl-4",
                        children: "We are seeking brilliant minds to join our dynamic team and make it even better."
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 291,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 290,
                      columnNumber: 21
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 278,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 277,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 276,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 275,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 274,
            columnNumber: 11
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
            className: "blog-section",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
              className: "container",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                className: "row b-row-1",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-8 col-lg-8",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                    className: "blog-wrap",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                      className: "blog-list",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((react_infinite_scroller__WEBPACK_IMPORTED_MODULE_18___default()), {
                        initialLoad: true,
                        loadMore: this.get_allPosts,
                        hasMore: this.state.hasMoreItems,
                        loader: loader,
                        children: post_lists
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 308,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
                        children: this.state.no_items
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 316,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 307,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 306,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 305,
                  columnNumber: 17
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                  className: "col-12 col-sm-12 col-md-4 col-lg-4",
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                    className: "blog-sidebar",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("aside", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                        id: "search-4",
                        className: "widget widget_search posts_holder",
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("form", {
                          role: "search",
                          id: "searchform",
                          className: "searchform",
                          onSubmit: this.onSubmit,
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
                            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("input", {
                              type: "text",
                              name: "s",
                              id: "blog-search",
                              placeholder: "Search",
                              className: "placeholder",
                              value: this.state.search_val,
                              onChange: this.handleChange
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 335,
                              columnNumber: 29
                            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("button", {
                              type: "submit",
                              name: "search-submit",
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("i", {
                                className: "fa fa-search",
                                "aria-hidden": "true"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 345,
                                columnNumber: 31
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 344,
                              columnNumber: 29
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 334,
                            columnNumber: 27
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 328,
                          columnNumber: 25
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 324,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_post_recent_index_jsx__WEBPACK_IMPORTED_MODULE_15__.default, {
                        category: this.state.category
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 353,
                        columnNumber: 23
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_post_category_index_jsx__WEBPACK_IMPORTED_MODULE_14__.default, {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 356,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 323,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 322,
                    columnNumber: 19
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 321,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 304,
                columnNumber: 15
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 303,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 302,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 273,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
          className: "mob-visible"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 364,
          columnNumber: 9
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_components_footer_index_jsx__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 365,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 269,
        columnNumber: 7
      }, this);
    }
  }]);

  return BlogCategory;
}(react__WEBPACK_IMPORTED_MODULE_10__.Component);



;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYmxvZy9jYXRlZ29yeS9bc2x1Z10uanN4Il0sIm5hbWVzIjpbInJlcXVpcmUiLCJCbG9nQ2F0ZWdvcnkiLCJwcm9wcyIsInJlc3BvbnNlIiwic3RhdGUiLCJhbGxQb3N0cyIsImhhc01vcmVJdGVtcyIsInBhZ2UiLCJub19pdGVtcyIsImNhdGVnb3J5IiwibWF0Y2giLCJwYXJhbXMiLCJzbHVnIiwic2VhcmNoX3ZhbCIsImtleXdvcmQiLCJkYXRhIiwic2hpZnRDb250ZW50IiwiYmluZCIsImdldF9hbGxQb3N0cyIsImhhbmRsZUNoYW5nZSIsIm9uU3VibWl0Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsImxvY2F0aW9uIiwicGF0aG5hbWUiLCJwYXRoTmFtZXMiLCJzcGxpdCIsImNvbnNvbGUiLCJsb2ciLCJzaW5nbGVQb3N0Iiwic2V0U3RhdGUiLCJzZWFyY2giLCJ2YWx1ZXMiLCJxdWVyeVN0cmluZyIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJwcmV2ZW50RGVmYXVsdCIsImhpc3RvcnkiLCJwdXNoIiwiJCIsImlzIiwiaW5zZXJ0QmVmb3JlIiwidXJsIiwiY29uZmlnIiwiQXhpb3MiLCJ0aGVuIiwicG9zdHMiLCJtYXAiLCJtb3JlX2V4aXN0cyIsImxlbmd0aCIsImVycm9yIiwidG9hc3QiLCJtZXRhIiwidGl0bGUiLCJjaGFyc2V0IiwibmFtZSIsImtleXdvcmRzIiwibG9hZGVyIiwicG9zdF9saXN0cyIsInBvc3QiLCJpbmRleCIsImJhY2tncm91bmRJbWFnZSIsImltYWdlIiwiY2F0ZWdvcmllcyIsImNhdCIsImkiLCJhdXRob3IiLCJleGNlcnB0IiwiU2xpZGUiLCJkZXNjcmlwdGlvbiIsInRleHRUcmFuc2Zvcm0iLCJDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQUEsbUJBQU8sQ0FBQyx5RUFBRCxDQUFQOzs7O0lBeUJxQkMsWTs7Ozs7QUFHbkIsd0JBQVlDLEtBQVosRUFBbUI7QUFBQTs7QUFBQTs7QUFBQTs7QUFDakIsOEJBQU1BLEtBQU47O0FBQ0osZUFBbUMsRUFFOUI7O0FBQ0QsUUFBSUMsUUFBUSxHQUFHLE1BQUtELEtBQXBCO0FBQ0EsVUFBS0UsS0FBTCxHQUFhO0FBQ1hDLGNBQVEsRUFBRSxFQURDO0FBRVhDLGtCQUFZLEVBQUUsSUFGSDtBQUdYQyxVQUFJLEVBQUMsQ0FITTtBQUlYQyxjQUFRLEVBQUUsRUFKQztBQUtYQyxjQUFRLGlCQUFFLE1BQUtQLEtBQVAscUVBQUUsWUFBWVEsS0FBZCwrRUFBRSxrQkFBbUJDLE1BQXJCLDBEQUFFLHNCQUEyQkMsSUFMMUI7QUFNWEMsZ0JBQVUsRUFBRSxFQU5EO0FBT1hDLGFBQU8sRUFBRSxFQVBFO0FBUVhDLFVBQUksRUFBRVosUUFBUSxDQUFDWSxJQUFULENBQWNBO0FBUlQsS0FBYjtBQVlBLFVBQUtDLFlBQUwsR0FBb0IsTUFBS0EsWUFBTCxDQUFrQkMsSUFBbEIseUlBQXBCO0FBQ0EsVUFBS0MsWUFBTCxHQUFvQixNQUFLQSxZQUFMLENBQWtCRCxJQUFsQix5SUFBcEI7QUFFQSxVQUFLRSxZQUFMLEdBQW9CLE1BQUtBLFlBQUwsQ0FBa0JGLElBQWxCLHlJQUFwQjtBQUNBLFVBQUtHLFFBQUwsR0FBZ0IsTUFBS0EsUUFBTCxDQUFjSCxJQUFkLHlJQUFoQjtBQXRCaUI7QUF1QmxCOzs7O3dDQUVtQjtBQUNsQixXQUFLRCxZQUFMOztBQUNBLGdCQUFpQztBQUMvQkssY0FBTSxDQUFDQyxnQkFBUCxDQUF3QixRQUF4QixFQUFrQyxLQUFLTixZQUF2QztBQUNEOztBQUNELFVBQUlLLE1BQU0sQ0FBQ0UsUUFBUCxDQUFnQkMsUUFBcEIsRUFBOEI7QUFDNUIsWUFBSUMsU0FBUyxHQUFHSixNQUFNLENBQUNFLFFBQVAsQ0FBZ0JDLFFBQWhCLENBQXlCRSxLQUF6QixDQUErQixHQUEvQixDQUFoQjtBQUNBQyxlQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW9CSCxTQUFwQjtBQUNBLFlBQUlJLFVBQVUsR0FBR0osU0FBUyxDQUFDLENBQUQsQ0FBMUI7QUFDQUUsZUFBTyxDQUFDQyxHQUFSLENBQVlDLFVBQVo7QUFDQSxhQUFLQyxRQUFMLENBQWM7QUFBRXJCLGtCQUFRLEVBQUVvQjtBQUFaLFNBQWQ7QUFFRDtBQUNGOzs7eUNBRW1CO0FBQ2xCLFVBQUksS0FBSzNCLEtBQUwsQ0FBV3FCLFFBQVgsSUFBdUIsS0FBS3JCLEtBQUwsQ0FBV3FCLFFBQVgsQ0FBb0JRLE1BQS9DLEVBQXVEO0FBQ3JELFlBQU1DLE1BQU0sR0FBR0MsZ0RBQUEsQ0FBa0IsS0FBSy9CLEtBQUwsQ0FBV3FCLFFBQVgsQ0FBb0JRLE1BQXRDLENBQWY7QUFDQSxhQUFLRCxRQUFMLENBQWM7QUFDWmhCLGlCQUFPLEVBQUVrQixNQUFNLENBQUNsQixPQURKO0FBRVpELG9CQUFVLEVBQUVtQixNQUFNLENBQUNsQjtBQUZQLFNBQWQ7QUFJRDtBQUNGOzs7MkNBRXNCO0FBQ3JCLGdCQUFpQztBQUMvQk8sY0FBTSxDQUFDYSxtQkFBUCxDQUEyQixRQUEzQixFQUFxQyxLQUFLbEIsWUFBMUM7QUFDRDtBQUNGOzs7aUNBRVltQixDLEVBQUc7QUFDZCxXQUFLTCxRQUFMLENBQWM7QUFDWmpCLGtCQUFVLEVBQUVzQixDQUFDLENBQUNDLE1BQUYsQ0FBU0M7QUFEVCxPQUFkO0FBSUQ7Ozs2QkFFUUYsQyxFQUFHO0FBQ1JBLE9BQUMsQ0FBQ0csY0FBRjtBQUNBLFVBQU1OLE1BQU0sR0FBRyxLQUFLNUIsS0FBTCxDQUFXUyxVQUExQjtBQUNBLFdBQUtpQixRQUFMLENBQWM7QUFDWmhCLGVBQU8sRUFBRWtCLE1BREc7QUFFWnpCLFlBQUksRUFBRSxDQUZNO0FBR1pGLGdCQUFRLEVBQUUsRUFIRTtBQUlaQyxvQkFBWSxFQUFFLElBSkY7QUFLWkUsZ0JBQVEsRUFBRTtBQUxFLE9BQWQ7QUFPQSxXQUFLTixLQUFMLENBQVdxQyxPQUFYLENBQW1CQyxJQUFuQixDQUF3QixxQkFBbUIsS0FBS3BDLEtBQUwsQ0FBV0ssUUFBOUIsR0FBdUMsV0FBdkMsR0FBbUQsS0FBS0wsS0FBTCxDQUFXUyxVQUF0RjtBQUVILEssQ0FFRDs7OzttQ0FDYztBQUNaLFVBQUc0Qiw4Q0FBQyxDQUFDLGNBQUQsQ0FBRCxDQUFrQkMsRUFBbEIsQ0FBcUIsVUFBckIsQ0FBSCxFQUFxQztBQUNuQ0Qsc0RBQUMsQ0FBQyxnQkFBRCxDQUFELENBQW9CRSxZQUFwQixDQUFpQ0YsOENBQUMsQ0FBQyxZQUFELENBQWxDO0FBQ0QsT0FGRCxNQUdLO0FBQ0hBLHNEQUFDLENBQUMsZ0JBQUQsQ0FBRCxDQUFvQkUsWUFBcEIsQ0FBaUNGLDhDQUFDLENBQUMsd0JBQUQsQ0FBbEM7QUFDRDtBQUNGLEssQ0FHRDs7Ozs7Ozs7Ozs7OztBQUVNRyxtQixHQUFNQyxxREFBQSxHQUF1QixZO0FBQzdCdEMsb0IsR0FBTyxLQUFLSCxLQUFMLENBQVdHLEk7QUFDbEJFLHdCLEdBQVcsS0FBS0wsS0FBTCxDQUFXSyxRO0FBQ3RCSyx1QixHQUFVLEtBQUtWLEtBQUwsQ0FBV1UsTztBQUV6QmdDLGlFQUFBLENBQVVGLEdBQVYsRUFBZTtBQUFDakMsd0JBQU0sRUFBRTtBQUFDSix3QkFBSSxFQUFFQSxJQUFQO0FBQWFFLDRCQUFRLEVBQUVBLFFBQXZCO0FBQWlDSywyQkFBTyxFQUFFQTtBQUExQztBQUFULGlCQUFmLEVBQ0NpQyxJQURELENBQ00sVUFBQzVDLFFBQUQsRUFBYztBQUNsQixzQkFBTUUsUUFBUSxHQUFHLE1BQUksQ0FBQ0QsS0FBTCxDQUFXQyxRQUE1QjtBQUVBRiwwQkFBUSxDQUFDWSxJQUFULENBQWNBLElBQWQsQ0FBbUJpQyxLQUFuQixDQUF5QkMsR0FBekIsQ0FBNkIsVUFBQ2xDLElBQUQsRUFBVTtBQUNuQ1YsNEJBQVEsQ0FBQ21DLElBQVQsQ0FBY3pCLElBQWQ7QUFDSCxtQkFGRDs7QUFJQSxzQkFBR1osUUFBUSxDQUFDWSxJQUFULENBQWNBLElBQWQsQ0FBbUJtQyxXQUFuQixJQUFrQyxJQUFyQyxFQUEyQztBQUN2QywwQkFBSSxDQUFDcEIsUUFBTCxDQUFjO0FBQ1p6Qiw4QkFBUSxFQUFFQSxRQURFO0FBRVpDLGtDQUFZLEVBQUUsSUFGRjtBQUdaQywwQkFBSSxFQUFFQSxJQUFJLEdBQUM7QUFIQyxxQkFBZDtBQUtILG1CQU5ELE1BTU87QUFDTCx3QkFBR0YsUUFBUSxDQUFDOEMsTUFBVCxJQUFtQixDQUF0QixFQUF5QjtBQUN2QnhCLDZCQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjs7QUFDQSw0QkFBSSxDQUFDRSxRQUFMLENBQWM7QUFDWnhCLG9DQUFZLEVBQUUsS0FERjtBQUVaRSxnQ0FBUSxFQUFFO0FBRkUsdUJBQWQ7QUFJRCxxQkFORCxNQU1PO0FBQ0wsNEJBQUksQ0FBQ3NCLFFBQUwsQ0FBYztBQUNaeEIsb0NBQVksRUFBRTtBQURGLHVCQUFkO0FBR0Q7QUFDRjtBQUVGLGlCQTVCRCxXQTRCUyxVQUFBOEMsS0FBSyxFQUFHO0FBQ2Y7QUFDQXpCLHlCQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaO0FBQ0F5QiwwRUFBQSxDQUFZLHVCQUFaO0FBQ0QsaUJBaENEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7NkJBcUNPO0FBQUE7O0FBQ1AsVUFBTUMsSUFBSSxHQUFHO0FBQ1hDLGFBQUssRUFBRSx5REFESTtBQUVYRCxZQUFJLEVBQUU7QUFDSkUsaUJBQU8sRUFBRSxPQURMO0FBRUZDLGNBQUksRUFBRTtBQUNKQyxvQkFBUSxFQUFFO0FBRE47QUFGSjtBQUZLLE9BQWI7O0FBV0EsVUFBTUMsTUFBTSxnQkFBRztBQUFLLGlCQUFTLEVBQUMsUUFBZjtBQUFBLGdDQUF3QjtBQUFLLG1CQUFTLEVBQUMsU0FBZjtBQUFBLGtDQUF5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUF6QixlQUFvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUFwQyxlQUErQztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUEvQyxlQUEwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUFmOztBQUVBLFVBQUlDLFVBQVUsR0FBRyxFQUFqQjtBQUNBLFdBQUt4RCxLQUFMLENBQVdDLFFBQVgsQ0FBb0I0QyxHQUFwQixDQUF3QixVQUFDWSxJQUFELEVBQU9DLEtBQVAsRUFBaUI7QUFDdkNGLGtCQUFVLENBQUNwQixJQUFYLGVBQ0UsOERBQUMsNkRBQUQ7QUFBTSxnQkFBTSxNQUFaO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLE1BQWY7QUFBQSxvQ0FDRTtBQUFJLHVCQUFTLEVBQUMsc0NBQWQ7QUFBQSxxQ0FDRSw4REFBQyxtREFBRDtBQUNFLG9CQUFJLEVBQUUscUJBRFI7QUFFRSxrQkFBRSxFQUFFLGtCQUFrQnFCLElBQUksQ0FBQ2pCLEdBRjdCO0FBQUEsMEJBSUdpQixJQUFJLENBQUNOO0FBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUFTRTtBQUFLLHVCQUFTLEVBQUMsVUFBZjtBQUFBLHNDQUNFLDhEQUFDLG1EQUFEO0FBQ0Usb0JBQUksRUFBRSxxQkFEUjtBQUVFLGtCQUFFLEVBQUUsa0JBQWtCTSxJQUFJLENBQUNqQixHQUY3QjtBQUFBLHVDQUlFO0FBQ0UsMkJBQVMsRUFBQyxZQURaO0FBRUUsdUJBQUssRUFBRTtBQUNMbUIsbUNBQWUsRUFDYkYsSUFBSSxDQUFDRyxLQUFMLElBQWMsSUFBZCxHQUNJLHFDQURKLGlCQUVXSCxJQUFJLENBQUNHLEtBRmhCO0FBRkc7QUFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQWVFO0FBQUsseUJBQVMsRUFBQyxrQkFBZjtBQUFBLDBCQUNHSCxJQUFJLENBQUNJLFVBQUwsQ0FBZ0JoQixHQUFoQixDQUFvQixVQUFDaUIsR0FBRCxFQUFNQyxDQUFOLEVBQVk7QUFDL0Isc0NBQ0UsOERBQUMsbURBQUQ7QUFDRSx3QkFBSSxFQUFFLHVCQURSO0FBRUUsc0JBQUUsRUFBRSxvQkFBb0JELEdBQUcsQ0FBQ3RELElBRjlCO0FBR0UsNkJBQVMsRUFBQyxzQkFIWjtBQUFBLDhCQU1Hc0QsR0FBRyxDQUFDVDtBQU5QLHFCQUlPVSxDQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBREY7QUFVRCxpQkFYQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVRGLGVBdUNFO0FBQUssdUJBQVMsRUFBQyxXQUFmO0FBQUEsc0NBQ0U7QUFBSSx5QkFBUyxFQUFDLHNDQUFkO0FBQUEsdUNBQ0UsOERBQUMsbURBQUQ7QUFDRSxzQkFBSSxFQUFFLHFCQURSO0FBRUUsb0JBQUUsRUFBRSxrQkFBa0JOLElBQUksQ0FBQ2pCLEdBRjdCO0FBQUEsNEJBSUdpQixJQUFJLENBQUNOO0FBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFTRTtBQUFPLHlCQUFTLEVBQUMsaURBQWpCO0FBQUEsd0NBQ0U7QUFBRywyQkFBUyxFQUFDLGVBQWI7QUFBNkIsaUNBQVk7QUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFERixFQUN1RCxHQUR2RCxFQUVHTSxJQUFJLENBQUNPLE1BRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVRGLGVBYUU7QUFBRyx5QkFBUyxFQUFDLFdBQWI7QUFBQSwwQkFBMEJQLElBQUksQ0FBQ1E7QUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFiRixlQWNFO0FBQU0seUJBQVMsRUFBQyxVQUFoQjtBQUFBLHVDQUNFLDhEQUFDLG1EQUFEO0FBQ0Usc0JBQUksRUFBRSxxQkFEUjtBQUVFLG9CQUFFLEVBQUUsa0JBQWtCUixJQUFJLENBQUNqQixHQUY3QjtBQUdFLDJCQUFTLEVBQUMsbUJBSFo7QUFBQSx5Q0FLRTtBQUFBLDRDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURGLEVBQ3lCLEdBRHpCLGVBRUU7QUFBRywrQkFBUyxFQUFDLHFCQUFiO0FBQW1DLHFDQUFZO0FBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXZDRjtBQUFBLGFBQTJCa0IsS0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREY7QUF1RUQsT0F4RUQ7QUFmTyxVQXdGSi9DLElBeEZJLEdBd0ZJLEtBQUtYLEtBeEZULENBd0ZKVyxJQXhGSTtBQXlGUCwwQkFDRTtBQUFLLGlCQUFTLEVBQUMsV0FBZjtBQUEyQixVQUFFLEVBQUMsV0FBOUI7QUFBQSxnQ0FDRSw4REFBQywyREFBRDtBQUFnQixvQkFBVSxFQUFFdUQsa0RBQUtBO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFFRSw4REFBQyx5REFBRCxvQkFBa0JoQixJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGLGVBR0UsOERBQUMsa0VBQUQ7QUFBUSxlQUFLLEVBQUV2QyxJQUFJLENBQUN3QyxLQUFwQjtBQUEyQixxQkFBVyxFQUFFeEMsSUFBSSxDQUFDd0QsV0FBN0M7QUFBMEQsa0JBQVEsRUFBRXhELElBQUksQ0FBQzJDO0FBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSEYsZUFJRTtBQUFTLG1CQUFNLG1CQUFmO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLHFDQUFmO0FBQUEsbUNBQ0U7QUFBSyx1QkFBUyxFQUFDLGtCQUFmO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLHNCQUFmO0FBQUEsdUNBQ0U7QUFBSywyQkFBUyxFQUFDLFlBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsNkRBQWY7QUFBQSw0Q0FDRTtBQUFLLCtCQUFTLEVBQUMsb0JBQWY7QUFBQSw4Q0FDRTtBQUFHLGlDQUFTLEVBQUMsdUNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBREYsZUFJRTtBQUNFLGlDQUFTLEVBQUMsZ0NBRFo7QUFFRSw2QkFBSyxFQUFFO0FBQUVjLHVDQUFhLEVBQUU7QUFBakIseUJBRlQ7QUFBQSxrQ0FJRyxLQUFLcEUsS0FBTCxDQUFXSztBQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQURGLGVBWUU7QUFBSywrQkFBUyxFQUFDLGlDQUFmO0FBQUEsNkNBQ0U7QUFBRyxpQ0FBUyxFQUFDLHdDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBNkJFO0FBQUsscUJBQVMsRUFBQyxjQUFmO0FBQUEsbUNBQ0U7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSxxQ0FDRTtBQUFLLHlCQUFTLEVBQUMsYUFBZjtBQUFBLHdDQUNFO0FBQUssMkJBQVMsRUFBQyxvQ0FBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxXQUFmO0FBQUEsMkNBQ0U7QUFBSywrQkFBUyxFQUFDLFdBQWY7QUFBQSw4Q0FDRSw4REFBQyxpRUFBRDtBQUNFLG1DQUFXLEVBQUUsSUFEZjtBQUVFLGdDQUFRLEVBQUUsS0FBS1MsWUFGakI7QUFHRSwrQkFBTyxFQUFFLEtBQUtkLEtBQUwsQ0FBV0UsWUFIdEI7QUFJRSw4QkFBTSxFQUFFcUQsTUFKVjtBQUFBLGtDQU1HQztBQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBREYsZUFTRTtBQUFBLGtDQUFJLEtBQUt4RCxLQUFMLENBQVdJO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixlQWlCRTtBQUFLLDJCQUFTLEVBQUMsb0NBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsY0FBZjtBQUFBLDJDQUNFO0FBQUEsOENBQ0U7QUFDRSwwQkFBRSxFQUFDLFVBREw7QUFFRSxpQ0FBUyxFQUFDLG1DQUZaO0FBQUEsK0NBSUU7QUFDRSw4QkFBSSxFQUFDLFFBRFA7QUFFRSw0QkFBRSxFQUFDLFlBRkw7QUFHRSxtQ0FBUyxFQUFDLFlBSFo7QUFJRSxrQ0FBUSxFQUFFLEtBQUtZLFFBSmpCO0FBQUEsaURBTUU7QUFBQSxvREFDRTtBQUNFLGtDQUFJLEVBQUMsTUFEUDtBQUVFLGtDQUFJLEVBQUMsR0FGUDtBQUdFLGdDQUFFLEVBQUMsYUFITDtBQUlFLHlDQUFXLEVBQUMsUUFKZDtBQUtFLHVDQUFTLEVBQUMsYUFMWjtBQU1FLG1DQUFLLEVBQUUsS0FBS2hCLEtBQUwsQ0FBV1MsVUFOcEI7QUFPRSxzQ0FBUSxFQUFFLEtBQUtNO0FBUGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBREYsZUFVRTtBQUFRLGtDQUFJLEVBQUMsUUFBYjtBQUFzQixrQ0FBSSxFQUFDLGVBQTNCO0FBQUEscURBQ0U7QUFDRSx5Q0FBUyxFQUFDLGNBRFo7QUFFRSwrQ0FBWTtBQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURGLGVBOEJFLDhEQUFDLHVFQUFEO0FBQ0UsZ0NBQVEsRUFBRSxLQUFLZixLQUFMLENBQVdLO0FBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBOUJGLGVBaUNFLDhEQUFDLHlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGLGVBK0ZFO0FBQUssbUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBL0ZGLGVBZ0dFLDhEQUFDLGtFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGO0FBb0dEOzs7O0VBcFV1Q2dFLDZDIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2Jsb2cvY2F0ZWdvcnkvW3NsdWddLjViMzc0MGQ4NjQwNjI5Njg5NmRkLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSGVhZGVyIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvaGVhZGVyL2luZGV4LmpzeCc7XHJcbmltcG9ydCBGb290ZXIgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9mb290ZXIvaW5kZXguanN4JztcclxuaW1wb3J0IFVuZGVyY29uc3RydWN0aW9uIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdW5kZXItY29uc3RydWN0aW9uL2luZGV4LmpzeCc7XHJcbmltcG9ydCBCbG9nQ2F0ZWdvcmllcyBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3Bvc3QtY2F0ZWdvcnkvaW5kZXguanN4JztcclxuaW1wb3J0IEJsb2dSZWNlbnRQb3N0cyBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3Bvc3QtcmVjZW50L2luZGV4LmpzeCc7XHJcbmltcG9ydCBEb2N1bWVudE1ldGEgZnJvbSAncmVhY3QtZG9jdW1lbnQtbWV0YSc7XHJcbmltcG9ydCB7IFRvYXN0Q29udGFpbmVyLCB0b2FzdCwgU2xpZGUgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XHJcbmltcG9ydCAncmVhY3QtdG9hc3RpZnkvZGlzdC9SZWFjdFRvYXN0aWZ5LmNzcyc7XHJcbmltcG9ydCBJbmZpbml0ZVNjcm9sbCBmcm9tICdyZWFjdC1pbmZpbml0ZS1zY3JvbGxlcic7XHJcbmltcG9ydCAkIGZyb20gJ2pxdWVyeSc7XHJcbmltcG9ydCBBeGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IGh0dHBzIGZyb20gXCJodHRwc1wiO1xyXG5pbXBvcnQgKiBhcyBjb25maWcgZnJvbSAnLi4vLi4vLi4vY29uZmlnJztcclxuaW1wb3J0IHF1ZXJ5U3RyaW5nIGZyb20gJ3F1ZXJ5LXN0cmluZyc7XHJcbmltcG9ydCBGbGlwIGZyb20gJ3JlYWN0LXJldmVhbC9SZXZlYWwnO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcblxyXG5yZXF1aXJlKCd0eXBlZmFjZS1tb250c2VycmF0JylcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcygpIHtcclxuICBsZXQgZGF0YSA9IFtdO1xyXG5cclxuICBjb25zdCBpbnN0YW5jZSA9IEF4aW9zLmNyZWF0ZSh7XHJcbiAgICBodHRwc0FnZW50OiBuZXcgaHR0cHMuQWdlbnQoe1xyXG4gICAgICByZWplY3RVbmF1dGhvcml6ZWQ6IGZhbHNlLFxyXG4gICAgfSksXHJcbiAgfSk7XHJcblxyXG4gIGF3YWl0IGluc3RhbmNlXHJcbiAgICAuZ2V0KFwiaHR0cHM6Ly9hcGkuaGFzaHRhZy1jYS5jb20vYXBpL3YxL21ldGFkYXRhXCIsIHtcclxuICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgcGFnZV90eXBlOiBcInN0YXRpY1wiLFxyXG4gICAgICAgIHNsdWc6IFwic2V2aWNlc1wiLFxyXG4gICAgICB9LFxyXG4gICAgfSlcclxuICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICBkYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuICAgIH0pO1xyXG4gIHJldHVybiB7XHJcbiAgICBwcm9wczogeyBkYXRhIH0sXHJcbiAgfTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQmxvZ0NhdGVnb3J5IGV4dGVuZHMgQ29tcG9uZW50IHtcclxuXHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb3BzKSB7XHJcbiAgICBzdXBlcihwcm9wcyk7XHJcbmlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgZ2xvYmFsLndpbmRvdyA9IHt9O1xyXG4gICAgfVxyXG4gICAgbGV0IHJlc3BvbnNlID0gdGhpcy5wcm9wc1xyXG4gICAgdGhpcy5zdGF0ZSA9IHtcclxuICAgICAgYWxsUG9zdHM6IFtdLFxyXG4gICAgICBoYXNNb3JlSXRlbXM6IHRydWUsXHJcbiAgICAgIHBhZ2U6MSxcclxuICAgICAgbm9faXRlbXM6ICcnLFxyXG4gICAgICBjYXRlZ29yeTogdGhpcy5wcm9wcz8ubWF0Y2g/LnBhcmFtcz8uc2x1ZyxcclxuICAgICAgc2VhcmNoX3ZhbDogJycsXHJcbiAgICAgIGtleXdvcmQ6ICcnLFxyXG4gICAgICBkYXRhOiByZXNwb25zZS5kYXRhLmRhdGEsXHJcbiAgICB9O1xyXG5cclxuXHJcbiAgICB0aGlzLnNoaWZ0Q29udGVudCA9IHRoaXMuc2hpZnRDb250ZW50LmJpbmQodGhpcyk7XHJcbiAgICB0aGlzLmdldF9hbGxQb3N0cyA9IHRoaXMuZ2V0X2FsbFBvc3RzLmJpbmQodGhpcyk7XHJcblxyXG4gICAgdGhpcy5oYW5kbGVDaGFuZ2UgPSB0aGlzLmhhbmRsZUNoYW5nZS5iaW5kKHRoaXMpO1xyXG4gICAgdGhpcy5vblN1Ym1pdCA9IHRoaXMub25TdWJtaXQuYmluZCh0aGlzKTtcclxuICB9XHJcblxyXG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xyXG4gICAgdGhpcy5zaGlmdENvbnRlbnQoKTtcclxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgdGhpcy5zaGlmdENvbnRlbnQpO1xyXG4gICAgfVxyXG4gICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSkge1xyXG4gICAgICBsZXQgcGF0aE5hbWVzID0gd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLnNwbGl0KFwiL1wiKTtcclxuICAgICAgY29uc29sZS5sb2coXCJwYXRoXCIsIHBhdGhOYW1lcyk7XHJcbiAgICAgIGxldCBzaW5nbGVQb3N0ID0gcGF0aE5hbWVzWzNdO1xyXG4gICAgICBjb25zb2xlLmxvZyhzaW5nbGVQb3N0KVxyXG4gICAgICB0aGlzLnNldFN0YXRlKHsgY2F0ZWdvcnk6IHNpbmdsZVBvc3QgfSk7XHJcbiAgICAgIFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29tcG9uZW50V2lsbE1vdW50KCl7XHJcbiAgICBpZiAodGhpcy5wcm9wcy5sb2NhdGlvbiAmJiB0aGlzLnByb3BzLmxvY2F0aW9uLnNlYXJjaCkge1xyXG4gICAgICBjb25zdCB2YWx1ZXMgPSBxdWVyeVN0cmluZy5wYXJzZSh0aGlzLnByb3BzLmxvY2F0aW9uLnNlYXJjaCk7XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgIGtleXdvcmQ6IHZhbHVlcy5rZXl3b3JkLFxyXG4gICAgICAgIHNlYXJjaF92YWw6IHZhbHVlcy5rZXl3b3JkLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xyXG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCB0aGlzLnNoaWZ0Q29udGVudCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBoYW5kbGVDaGFuZ2UoZSkge1xyXG4gICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgIHNlYXJjaF92YWw6IGUudGFyZ2V0LnZhbHVlXHJcbiAgICB9KTtcclxuXHJcbiAgfVxyXG5cclxuICBvblN1Ym1pdChlKSB7XHJcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgY29uc3QgdmFsdWVzID0gdGhpcy5zdGF0ZS5zZWFyY2hfdmFsO1xyXG4gICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICBrZXl3b3JkOiB2YWx1ZXMsXHJcbiAgICAgICAgcGFnZTogMSxcclxuICAgICAgICBhbGxQb3N0czogW10sXHJcbiAgICAgICAgaGFzTW9yZUl0ZW1zOiB0cnVlLFxyXG4gICAgICAgIG5vX2l0ZW1zOiAnJ1xyXG4gICAgICB9KTtcclxuICAgICAgdGhpcy5wcm9wcy5oaXN0b3J5LnB1c2goJy9ibG9ncy9jYXRlZ29yeS8nK3RoaXMuc3RhdGUuY2F0ZWdvcnkrJz9rZXl3b3JkPScrdGhpcy5zdGF0ZS5zZWFyY2hfdmFsKTtcclxuICAgICAgXHJcbiAgfVxyXG5cclxuICAvL1NlYXJjaCBkaXYgc2hpZnRcclxuICBzaGlmdENvbnRlbnQoKXtcclxuICAgIGlmKCQoXCIubW9iLXZpc2libGVcIikuaXMoXCI6dmlzaWJsZVwiKSkgeyBcclxuICAgICAgJCgnLndpZGdldF9zZWFyY2gnKS5pbnNlcnRCZWZvcmUoJCgnLmJsb2ctbGlzdCcpKTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICAkKCcud2lkZ2V0X3NlYXJjaCcpLmluc2VydEJlZm9yZSgkKCcud2lkZ2V0X3JlY2VudF9lbnRyaWVzJykpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcblxyXG4gIC8vR2V0IHBvc3RzXHJcbiAgYXN5bmMgZ2V0X2FsbFBvc3RzKCl7XHJcbiAgICB2YXIgdXJsID0gY29uZmlnLm15Q29uZmlnLmFwaVVybCsnYmxvZy9wb3N0cyc7XHJcbiAgICB2YXIgcGFnZSA9IHRoaXMuc3RhdGUucGFnZTtcclxuICAgIHZhciBjYXRlZ29yeSA9IHRoaXMuc3RhdGUuY2F0ZWdvcnk7XHJcbiAgICB2YXIga2V5d29yZCA9IHRoaXMuc3RhdGUua2V5d29yZDtcclxuXHJcbiAgICBBeGlvcy5nZXQodXJsLCB7cGFyYW1zOiB7cGFnZTogcGFnZSwgY2F0ZWdvcnk6IGNhdGVnb3J5LCBrZXl3b3JkOiBrZXl3b3JkfX0pXHJcbiAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgY29uc3QgYWxsUG9zdHMgPSB0aGlzLnN0YXRlLmFsbFBvc3RzO1xyXG5cclxuICAgICAgcmVzcG9uc2UuZGF0YS5kYXRhLnBvc3RzLm1hcCgoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgYWxsUG9zdHMucHVzaChkYXRhKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZihyZXNwb25zZS5kYXRhLmRhdGEubW9yZV9leGlzdHMgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgICAgICAgIGFsbFBvc3RzOiBhbGxQb3N0cyxcclxuICAgICAgICAgICAgaGFzTW9yZUl0ZW1zOiB0cnVlLFxyXG4gICAgICAgICAgICBwYWdlOiBwYWdlKzFcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGlmKGFsbFBvc3RzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnTm8gcG9zdHMgZm91bmQuJyk7XHJcbiAgICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgICAgaGFzTW9yZUl0ZW1zOiBmYWxzZSxcclxuICAgICAgICAgICAgbm9faXRlbXM6ICdObyBwb3N0cyBmb3VuZC4nXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgICAgICAgIGhhc01vcmVJdGVtczogZmFsc2UsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICB9KS5jYXRjaChlcnJvciA9PntcclxuICAgICAgLy8gY29uc29sZS5sb2coZXJyb3IucmVzcG9uc2UpO1xyXG4gICAgICBjb25zb2xlLmxvZygnQVBJIGVycm9yLicpO1xyXG4gICAgICB0b2FzdC5lcnJvcihcIlNvbWV0aGluZyB3ZW50IHdyb25nLlwiKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcblxyXG5cclxuICByZW5kZXIoKSB7XHJcbiAgICBjb25zdCBtZXRhID0ge1xyXG4gICAgICB0aXRsZTogJ0Jsb2dzIC0gRnVsbFN0YWNrIFdlYiBEZXZlbG9wbWVudHwgQmF5IGFyZWEsIENhbGlmb3JuaWEnLFxyXG4gICAgICBtZXRhOiB7XHJcbiAgICAgICAgY2hhcnNldDogJ3V0Zi04JyxcclxuICAgICAgICAgIG5hbWU6IHtcclxuICAgICAgICAgICAga2V5d29yZHM6ICdXZWIgZGV2ZWxvcG1lbnQgY29tcGFueSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBjb21wYW55LHdlYiBkZXZlbG9wbWVudCBrb2NoaSx3ZWIgZGV2ZWxvcG1lbnQgY29tcGFueSBrb2NoaSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBrb2NoaSx3ZWIgZGV2ZWxvcG1lbnQgY29tcGFueSBrb2NoaSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBrb2NoaSx3ZWIgZGVzaWduIGFuZCBkZXZlbG9wbWVudCBrb2NoaSxmdWxsIHN0YWNrIGRldmVsb3BtZW50IGNvbXBhbnksd29yZHByZXNzIGN1c3RvbWlzYXRpb24gY29tcGFueSBrZXJhbGEsc2hvcGlmeSB0aGVtZSBkZXZlbG9wbWVudCBjb21wYW55IGtlcmFsYSxlY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBrZXJhbGEsd29vY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBrZXJhbGEsd2ViIGRldmVsb3BtZW50IGNvbXBhbnkgQ2FsaWZvcm5pYSxzb2Z0d2FyZSBkZXZlbG9wbWVudCBjYWxpZm9ybmlhLHdvcmRwcmVzcyBkZXZlbG9wbWVudCBjYWxpZm9ybmlhLHdvcmRwcmVzcyBkZXZlbG9wbWVudCBrb2NoaSxzaG9waWZ5IGRldmVsb3BtZW50IGtvY2hpLHNob3BpZnkgZGV2ZWxvcG1lbnQgY2FsaWZvcm5pYSx3b3JkcHJlc3MgY3VzdG9taXNhdGlvbiBjb21wYW55LHNob3BpZnkgdGhlbWUgZGV2ZWxvcG1lbnQgY29tcGFueSxlY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBrb2NoaSxlY29tbWVyY2UgZGV2ZWxvcG1lbnQgY29tcGFueSBjYWxpZm9ybmlhJ1xyXG4gICAgICAgIH1cclxuICAgICAgIFxyXG4gICAgICAgXHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBjb25zdCBsb2FkZXIgPSA8ZGl2IGNsYXNzTmFtZT1cImxvYWRlclwiPjxkaXYgY2xhc3NOYW1lPVwic3Bpbm5lclwiPjxkaXY+PC9kaXY+PGRpdj48L2Rpdj48ZGl2PjwvZGl2PjxkaXY+PC9kaXY+PC9kaXY+TG9hZGluZzwvZGl2PjtcclxuXHJcbiAgICB2YXIgcG9zdF9saXN0cyA9IFtdO1xyXG4gICAgdGhpcy5zdGF0ZS5hbGxQb3N0cy5tYXAoKHBvc3QsIGluZGV4KSA9PiB7XHJcbiAgICAgIHBvc3RfbGlzdHMucHVzaChcclxuICAgICAgICA8RmxpcCBib3R0b20+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmRcIiBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cImNhcmQtdGl0bGUgdGV4dC1sZXZlbC00IHRpdGxlLW9yYW5nZVwiPlxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICBocmVmPXtcIi9ibG9nL3NpbmdsZS9bc2x1Z11cIn1cclxuICAgICAgICAgICAgICAgIGFzPXtcIi9ibG9nL3NpbmdsZS9cIiArIHBvc3QudXJsfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtwb3N0LnRpdGxlfVxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPC9oNT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWltZ1wiPlxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICBocmVmPXtcIi9ibG9nL3NpbmdsZS9baWRleF1cIn1cclxuICAgICAgICAgICAgICAgIGFzPXtcIi9ibG9nL3NpbmdsZS9cIiArIHBvc3QudXJsfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvZy10aHVtYlwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZEltYWdlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9zdC5pbWFnZSA9PSBudWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCIvaW1hZ2VzL2Jsb2dzL3dyaXRpbmctZ29vZC1ibG9nLmpwZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogYHVybCgke3Bvc3QuaW1hZ2V9KWAsXHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1pbWctb3ZlcmxheVwiPlxyXG4gICAgICAgICAgICAgICAge3Bvc3QuY2F0ZWdvcmllcy5tYXAoKGNhdCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPXtcIi9ibG9nL2NhdGVnb3J5L1tzbHVnXVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgYXM9e1wiL2Jsb2cvY2F0ZWdvcnkvXCIgKyBjYXQuc2x1Z31cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0biBidG4tbGlnaHQgYnRuLXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y2F0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keVwiPlxyXG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJjYXJkLXRpdGxlIHRleHQtbGV2ZWwtNCB0aXRsZS1vcmFuZ2VcIj5cclxuICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvc2luZ2xlL1tzbHVnXVwifVxyXG4gICAgICAgICAgICAgICAgICBhcz17XCIvYmxvZy9zaW5nbGUvXCIgKyBwb3N0LnVybH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3Bvc3QudGl0bGV9XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICA8c21hbGwgY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBjYXQgdGV4dC1hYm92ZS1tYWluLXRpdGxlIGF1dGhvci1ibGtcIj5cclxuICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLWhhc2h0YWdcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48L2k+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAge3Bvc3QuYXV0aG9yfVxyXG4gICAgICAgICAgICAgIDwvc21hbGw+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY2FyZC10ZXh0XCI+e3Bvc3QuZXhjZXJwdH08L3A+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY3RhLWxpbmtcIj5cclxuICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgIGhyZWY9e1wiL2Jsb2cvc2luZ2xlL1tzbHVnXVwifVxyXG4gICAgICAgICAgICAgICAgICBhcz17XCIvYmxvZy9zaW5nbGUvXCIgKyBwb3N0LnVybH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2hvcGlmeS1zdWItdGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8YT5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SZWFkIE1vcmU8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLWNoZXZyb24tcmlnaHRcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9GbGlwPlxyXG4gICAgICApO1xyXG4gICAgfSk7XHJcbmNvbnN0IHtkYXRhfSA9IHRoaXMuc3RhdGVcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1tYWluXCIgaWQ9XCJibG9nLW1haW5cIj5cclxuICAgICAgICA8VG9hc3RDb250YWluZXIgdHJhbnNpdGlvbj17U2xpZGV9IC8+XHJcbiAgICAgICAgPERvY3VtZW50TWV0YSB7Li4ubWV0YX0gLz5cclxuICAgICAgICA8SGVhZGVyIHRpdGxlPXtkYXRhLnRpdGxlfSBkZXNjcmlwdGlvbj17ZGF0YS5kZXNjcmlwdGlvbn0ga2V5d29yZHM9e2RhdGEua2V5d29yZHN9PjwvSGVhZGVyPlxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzPVwiY29udGVudC1jb250YWluZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLWZsdWlkIHNlcnZpY2UtYmcgcC0wIG0tMCBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXJ2aWNlLWJnLXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXJ2aWNlLWJhbm5lci1mcmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGp1c3RpZnktY29udGVudC1jZW50ZXIgc2VydmljZS1iYW5uZXItY29udGVudCBwbC0zIHByLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1sZy02IGNvbC1tZC0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic3ViLXRleHQtYWJvdmUtbWFpbi10aXRsZSB0aXRsZS13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBCbG9nc1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1haW4tdGl0bGUgdGl0bGUtd2hpdGUgZC1ibG9ja1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHRleHRUcmFuc2Zvcm06IFwiY2FwaXRhbGl6ZVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0aGlzLnN0YXRlLmNhdGVnb3J5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1sZy02IGNvbC1tZC0xMiB0ZXh0LXdoaXRlICBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImJvbGQtY29udGVudHMgc2VydmljZS1jb250ZW50LWJveCBwbC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFdlIGFyZSBzZWVraW5nIGJyaWxsaWFudCBtaW5kcyB0byBqb2luIG91ciBkeW5hbWljIHRlYW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYW5kIG1ha2UgaXQgZXZlbiBiZXR0ZXIuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBiLXJvdy0xXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtc20tMTIgY29sLW1kLTggY29sLWxnLThcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEluZmluaXRlU2Nyb2xsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGluaXRpYWxMb2FkPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkTW9yZT17dGhpcy5nZXRfYWxsUG9zdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhc01vcmU9e3RoaXMuc3RhdGUuaGFzTW9yZUl0ZW1zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkZXI9e2xvYWRlcn1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Bvc3RfbGlzdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0luZmluaXRlU2Nyb2xsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHA+e3RoaXMuc3RhdGUubm9faXRlbXN9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1zbS0xMiBjb2wtbWQtNCBjb2wtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctc2lkZWJhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhc2lkZT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJzZWFyY2gtNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIndpZGdldCB3aWRnZXRfc2VhcmNoIHBvc3RzX2hvbGRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcm9sZT1cInNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJzZWFyY2hmb3JtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZWFyY2hmb3JtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvblN1Ym1pdD17dGhpcy5vblN1Ym1pdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYmxvZy1zZWFyY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBsYWNlaG9sZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RoaXMuc3RhdGUuc2VhcmNoX3ZhbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIG5hbWU9XCJzZWFyY2gtc3VibWl0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmEgZmEtc2VhcmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJsb2dSZWNlbnRQb3N0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXRlZ29yeT17dGhpcy5zdGF0ZS5jYXRlZ29yeX1cclxuICAgICAgICAgICAgICAgICAgICAgID48L0Jsb2dSZWNlbnRQb3N0cz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCbG9nQ2F0ZWdvcmllcz48L0Jsb2dDYXRlZ29yaWVzPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9iLXZpc2libGVcIj48L2Rpdj5cclxuICAgICAgICA8Rm9vdGVyPjwvRm9vdGVyPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=